"""
Market Tags — v3.8
CDN / US designation for each ticker, plus display helpers.
v3.8: Added 21 Strategy tickers (TSLA, MSTR, COIN, CRWD, etc.)
"""

MARKET_MAP = {
    # -- Canadian Focus List (28) --
    "DLMAF":"CA","ANCTF":"CA","LBLCF":"CA","PBA":"CA","SU":"CA","TRP":"CA",
    "BMO":"CA","BN":"CA","CM":"CA","IFCZF":"CA","MFC":"CA","NTIOF":"CA",
    "RY":"CA","SLF":"CA","TD":"CA","SNCAF":"CA","BDRBF":"CA","CP":"CA",
    "ELEEF":"CA","GFL":"CA","RBA":"CA","TMTNF":"CA","WSPOF":"CA","CNSWF":"CA",
    "SHOP":"CA","CCDBF":"CA","FCXXF":"CA","BIP":"CA",
    # -- US Focus List (28) --
    "GOOG":"US","META":"US","AMZN":"US","HD":"US","TJX":"US","COST":"US",
    "CVX":"US","AON":"US","BAC":"US","JPM":"US","MA":"US","SPGI":"US",
    "JNJ":"US","SYK":"US","UNH":"US","HON":"US","RTX":"US","UNP":"US",
    "XYL":"US","APH":"US","AAPL":"US","AVGO":"US","MSFT":"US","NVDA":"US",
    "PANW":"US","NOW":"US","ECL":"US","NEE":"US",
    # -- v3.8: Strategy-only tickers (21 new) --
    "TSLA":"US","MSTR":"US","COIN":"US","CRWD":"US","GOOGL":"US",
    "MELI":"US","PLTR":"US","AMD":"US","TSM":"US","ISRG":"US",
    "DELL":"US","SOFI":"US","HOOD":"US","VST":"US","ORCL":"US",
    "FSLR":"US","CELH":"US","NFLX":"US",
    "IAU":"US","ICOP":"US","XLE":"US",
}

FLAG_CA = "\U0001F1E8\U0001F1E6"
FLAG_US = "\U0001F1FA\U0001F1F8"
TAG_CA  = "[CDN]"
TAG_US  = "[US]"

def get_market(ticker):
    return MARKET_MAP.get(ticker.upper(), "US")

def get_flag(ticker):
    return FLAG_CA if get_market(ticker) == "CA" else FLAG_US

def get_tag(ticker):
    return TAG_CA if get_market(ticker) == "CA" else TAG_US

def get_html_badge(ticker):
    mkt = get_market(ticker)
    if mkt == "CA":
        return '<span style="background:#dc3545;color:#fff;padding:1px 6px;border-radius:3px;font-size:11px;font-weight:bold;">CDN</span>'
    else:
        return '<span style="background:#0d6efd;color:#fff;padding:1px 6px;border-radius:3px;font-size:11px;font-weight:bold;">US</span>'
