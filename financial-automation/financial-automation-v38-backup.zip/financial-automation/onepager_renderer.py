"""
One-Pager Renderer -- v3.5

Generates per-ticker company one-pagers following Valentine's equity research
best practices (ADViCE™, TIER™, EPIC™, ENTER™ frameworks).

Structure (conclusion-first per ADViCE™):
  1. Verdict & Price Target (lead with the answer)
  2. Company Snapshot (business overview, lines, mission)
  3. Competitive Position (moat, peer context)
  4. Critical Factors (EPIC™ filtered, with catalysts)
  5. Financial Profile (trailing + forward estimates)
  6. Valuation Detail (DCF assumptions, sensitivity, scenarios)
  7. Where We Could Be Wrong (key risks)

Outputs:
  - render_onepager_html(ticker_data, analysis, profile) -> HTML string
  - add_onepager_sheet(wb, ticker_data, analysis, profile) -> Excel tab
"""

import datetime
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side


def _smart_cagr(realized, estimate, n):
    if not realized or not estimate or realized <= 0 or n <= 0 or estimate <= 0:
        return None
    try:
        return (estimate / realized) ** (1.0 / n) - 1
    except:
        return None


def _fmt(v, fmt="${:.2f}", default="--"):
    if v is None: return default
    try: return fmt.format(v)
    except: return default


def _pct(v, default="--"):
    if v is None: return default
    return f"{v:+.1%}"


def _val_detail_rows(dcf, n):
    """Generate method-specific detail rows for the valuation section."""
    method = dcf.get("method", "FCF_DCF")
    if method in ("DDM_BANK", "DDM_INSURER", "DDM_REIT"):
        rows = f"""
        <tr><td style="padding:4px 8px;color:#636E72;">Starting DPS</td><td style="padding:4px 8px;text-align:right;">${dcf.get('starting_dps',0):.2f}</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;color:#636E72;">Div Growth (t+{n})</td><td style="padding:4px 8px;text-align:right;">{dcf.get('dividend_growth',0):.1%}</td></tr>
        <tr><td style="padding:4px 8px;color:#636E72;">Terminal Growth</td><td style="padding:4px 8px;text-align:right;">{dcf.get('terminal_growth',0):.1%}</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;color:#636E72;">Cost of Equity</td><td style="padding:4px 8px;text-align:right;">{dcf.get('cost_of_equity',0):.1%}</td></tr>
        <tr><td style="padding:4px 8px;color:#636E72;">Current Yield</td><td style="padding:4px 8px;text-align:right;">{(dcf.get('current_yield') or 0):.1%}</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;color:#636E72;">Implied Yield</td><td style="padding:4px 8px;text-align:right;">{(dcf.get('implied_yield') or 0):.1%}</td></tr>"""
        pe = dcf.get("pe_crosscheck")
        if pe:
            rows += f"""
        <tr><td colspan="2" style="padding:6px 8px;font-weight:600;color:#2D4A5E;border-top:1px solid #DEE2E6;font-size:12px;">P/E Cross-Check</td></tr>
        <tr><td style="padding:4px 8px;color:#636E72;">Current P/E</td><td style="padding:4px 8px;text-align:right;">{pe['current_pe']:.1f}x</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;color:#636E72;">Sector Avg P/E</td><td style="padding:4px 8px;text-align:right;">{pe['target_pe']:.1f}x</td></tr>
        <tr><td style="padding:4px 8px;color:#636E72;">P/E Implied</td><td style="padding:4px 8px;text-align:right;font-weight:600;">${pe['pe_implied_price']:.2f}</td></tr>"""
        return rows
    else:
        return f"""
        <tr><td style="padding:4px 8px;color:#636E72;">Starting FCF</td><td style="padding:4px 8px;text-align:right;">${dcf.get('starting_fcf',0):.3f}B</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;color:#636E72;">Rev Growth (t+{n})</td><td style="padding:4px 8px;text-align:right;">{dcf.get('revenue_growth',0):.1%}</td></tr>
        <tr><td style="padding:4px 8px;color:#636E72;">Terminal Growth</td><td style="padding:4px 8px;text-align:right;">{dcf.get('terminal_growth',0):.1%}</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;color:#636E72;">WACC</td><td style="padding:4px 8px;text-align:right;">{dcf.get('wacc',0):.1%}</td></tr>"""


def _render_onepager_optionality(optionality):
    """Render optionality premium section for one-pager HTML."""
    if not optionality:
        return ""
    ventures_rows = ""
    for name, desc, conviction, timing in optionality.get("ventures", []):
        conv_color = {"High": "#155724", "Medium": "#856404", "Low": "#636E72"}.get(conviction, "#636E72")
        conv_bg = {"High": "#D4EDDA", "Medium": "#FFF3CD", "Low": "#F8F9FA"}.get(conviction, "#F8F9FA")
        ventures_rows += f"""<tr>
          <td style="padding:5px 8px;font-weight:600;font-size:12px;border-bottom:1px solid #EEE;">{name}</td>
          <td style="padding:5px 8px;font-size:11px;color:#636E72;border-bottom:1px solid #EEE;">{desc}</td>
          <td style="padding:5px 8px;text-align:center;border-bottom:1px solid #EEE;"><span style="background:{conv_bg};color:{conv_color};padding:2px 6px;border-radius:3px;font-size:10px;font-weight:600;">{conviction}</span></td>
          <td style="padding:5px 8px;text-align:center;font-size:11px;color:#636E72;border-bottom:1px solid #EEE;">{timing}</td>
        </tr>"""

    return f"""
    <!-- SECTION 6b: OPTIONALITY PREMIUM -->
    <h2 style="color:#7C3AED;font-size:15px;margin:16px 0 8px;border-bottom:2px solid #7C3AED;padding-bottom:4px;">
      Optionality Premium (+{optionality['premium_pct']:.0%})
    </h2>
    <p style="font-size:12px;color:#636E72;margin:4px 0 8px;">
      Base DCF: ${optionality['base_implied_price']:.2f} &rarr;
      <b style="color:#7C3AED;">Adjusted: ${optionality['adjusted_implied_price']:.2f}</b>
      (premium: +${optionality['premium_value']:.2f})
    </p>
    <p style="font-size:12px;color:#2D3436;margin:4px 0 8px;line-height:1.4;">
      Reflects embedded real options from AI infrastructure, moonshot ventures, and
      platform-scale investments whose value is not fully captured in a standard FCF DCF.
    </p>
    <table style="width:100%;border-collapse:collapse;font-size:13px;margin:8px 0;">
      <tr style="background:#7C3AED;">
        <th style="padding:5px 8px;color:#FFF;text-align:left;font-size:11px;">Venture</th>
        <th style="padding:5px 8px;color:#FFF;text-align:left;font-size:11px;">Description</th>
        <th style="padding:5px 8px;color:#FFF;text-align:center;font-size:11px;">Conviction</th>
        <th style="padding:5px 8px;color:#FFF;text-align:center;font-size:11px;">Timing</th>
      </tr>
      {ventures_rows}
    </table>"""


# ============================================================================
#  HTML ONE-PAGER
# ============================================================================

def render_onepager_html(ticker_data: dict, analysis: dict, profile: dict) -> str:
    """Generate a professional HTML one-pager for a single ticker."""
    td = ticker_data
    dcf = analysis.get("dcf", {})
    sc = analysis.get("scenarios", {})
    vd = analysis.get("verdict", {})
    optionality = analysis.get("optionality")
    p = td.get("price_usd", 0) or 0
    pc = td.get("price_cad")
    ip = dcf.get("implied_price", 0) or 0
    n = dcf.get("est_horizon", 3) or 3

    # Verdict colors
    vc = {"Undervalued": ("#155724", "#D4EDDA", "#28A745"),
          "Overvalued": ("#721C24", "#F8D7DA", "#DC3545"),
          "Fairly Valued": ("#856404", "#FFF3CD", "#FFC107")}
    tc, bgc, bc = vc.get(vd.get("rating", ""), ("#2D3436", "#F8F9FA", "#6C757D"))

    today = datetime.date.today().strftime("%B %d, %Y")

    # ---- Business Lines table ----
    biz_rows = ""
    for seg_name, pct_val, desc in profile.get("business_lines", []):
        biz_rows += f"""<tr>
          <td style="padding:5px 8px;font-weight:600;border-bottom:1px solid #EEE;">{seg_name}</td>
          <td style="padding:5px 8px;text-align:center;border-bottom:1px solid #EEE;">{pct_val}%</td>
          <td style="padding:5px 8px;font-size:12px;color:#636E72;border-bottom:1px solid #EEE;">{desc}</td>
        </tr>"""

    # ---- Critical Factors ----
    cf_items = ""
    for cf in profile.get("critical_factors", []):
        cf_items += f'<li style="margin:4px 0;font-size:13px;">{cf}</li>'

    # ---- Catalysts ----
    cat_items = ""
    for cat_name, cat_timing in profile.get("catalysts", []):
        cat_items += f'<li style="margin:3px 0;font-size:12px;"><b>{cat_name}</b> <span style="color:#636E72;">({cat_timing})</span></li>'

    # ---- Key Risks ----
    risk_items = ""
    for risk in profile.get("key_risks", []):
        risk_items += f'<li style="margin:4px 0;font-size:13px;">{risk}</li>'

    # ---- Financial metrics table ----
    rev_n = td.get("rev_est_horizon") or n
    eps_n = td.get("eps_est_horizon") or n
    ebitda_n = td.get("ebitda_est_horizon") or n
    div_n = td.get("div_est_horizon") or n

    rev_g = _smart_cagr(td.get("rev_realized"), td.get("rev_estimate"), rev_n)
    if rev_g is None: rev_g = td.get("precomp_rev_growth")
    eps_g = _smart_cagr(td.get("eps_realized"), td.get("eps_estimate"), eps_n)
    if eps_g is None: eps_g = td.get("precomp_eps_growth")
    ebitda_g = _smart_cagr(td.get("ebitda_realized"), td.get("ebitda_estimate"), ebitda_n)
    div_g = _smart_cagr(td.get("div_realized"), td.get("div_estimate"), div_n)
    if div_g is None: div_g = td.get("precomp_div_growth")

    # Premium/Discount vs GF Fair Value
    gf_fv = td.get("price_target")
    gf_pd = (p / gf_fv - 1) if gf_fv and gf_fv > 0 and p else None
    # DCF upside
    dcf_up = (ip / p - 1) if ip and p and p > 0 else None

    # ---- Sensitivity table ----
    sens_rows = ""
    for w in dcf.get("wacc_range", []):
        cells = ""
        for tg in dcf.get("tg_range", []):
            v = dcf.get("sensitivity", {}).get((w, tg))
            st = ""
            if v and p:
                if v > p * 1.1: st = "background:#D4EDDA;"
                elif v < p * 0.9: st = "background:#F8D7DA;"
            cells += f'<td style="padding:6px;text-align:center;font-size:12px;{st}">{_fmt(v)}</td>'
        sens_rows += f'<tr><td style="padding:6px;font-weight:600;font-size:12px;">{w:.1%}</td>{cells}</tr>'
    sens_headers = "".join(
        f'<th style="padding:6px;background:#2D4A5E;color:#FFF;font-size:11px;">{t:.1%}</th>'
        for t in dcf.get("tg_range", []))

    # ---- Scenario table ----
    def sc_row(name, s, bg):
        u = s.get("upside")
        us = f"{u:+.1%}" if u is not None else "--"
        return f"""<tr style="background:{bg};">
          <td style="padding:6px 8px;font-weight:600;">{name}</td>
          <td style="padding:6px 8px;text-align:right;">{_fmt(s.get('price'))}</td>
          <td style="padding:6px 8px;text-align:right;">{us}</td>
          <td style="padding:6px 8px;font-size:12px;color:#636E72;">{s.get('assumption','')}</td>
        </tr>"""

    peers = ", ".join(profile.get("peer_group", [])) or "N/A"

    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"></head>
<body style="margin:0;padding:20px;font-family:Calibri,'Segoe UI',Arial,sans-serif;background:#F0F2F5;">
<div style="max-width:900px;margin:0 auto;background:#FFF;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">

  <!-- HEADER -->
  <div style="background:#1B2838;padding:18px 24px;">
    <h1 style="margin:0;color:#FFF;font-size:20px;">{td.get('company','')} ({td.get('ticker','')})</h1>
    <p style="margin:4px 0 0;color:#ADB5BD;font-size:12px;">
      {td.get('sector','')} &bull; Mkt Cap: {_fmt(td.get('mktcap_b'), '${:.1f}B')} &bull; {today}
    </p>
  </div>

  <!-- SECTION 1: VERDICT (conclusion-first per ADViCE) -->
  <div style="padding:16px 24px;background:{bgc};border-left:4px solid {bc};display:flex;justify-content:space-between;align-items:center;">
    <div>
      <span style="font-size:22px;font-weight:700;color:{tc};">{vd.get('rating','')}</span>
      <span style="font-size:14px;color:{tc};margin-left:12px;">by {vd.get('magnitude','')} | Confidence: {vd.get('confidence','')}</span>
    </div>
    <div style="text-align:right;">
      <div style="font-size:11px;color:#636E72;">DCF Implied Price</div>
      <div style="font-size:24px;font-weight:700;color:{tc};">{_fmt(ip)}</div>
      <div style="font-size:12px;color:{tc};">vs Current {_fmt(p)} ({_pct(dcf_up)})</div>
    </div>
  </div>

  <div style="padding:20px 24px;">

    <!-- SECTION 2: COMPANY SNAPSHOT -->
    <h2 style="color:#1B2838;font-size:15px;margin:0 0 8px;border-bottom:2px solid #DEE2E6;padding-bottom:4px;">Company Snapshot</h2>
    <p style="margin:4px 0 10px;font-size:13px;color:#2D3436;line-height:1.5;">{profile.get('description','')}</p>

    <table style="width:100%;border-collapse:collapse;font-size:13px;margin:8px 0 16px;">
      <tr style="background:#F8F9FA;">
        <th style="padding:5px 8px;text-align:left;font-size:11px;color:#636E72;">Segment</th>
        <th style="padding:5px 8px;text-align:center;font-size:11px;color:#636E72;">Rev %</th>
        <th style="padding:5px 8px;text-align:left;font-size:11px;color:#636E72;">Description</th>
      </tr>
      {biz_rows}
    </table>

    <p style="font-size:12px;color:#636E72;margin:4px 0;"><b>Mission:</b> <i>{profile.get('mission','')}</i></p>

    <!-- SECTION 3: COMPETITIVE POSITION -->
    <h2 style="color:#1B2838;font-size:15px;margin:16px 0 8px;border-bottom:2px solid #DEE2E6;padding-bottom:4px;">Competitive Position</h2>
    <p style="margin:4px 0 8px;font-size:13px;color:#2D3436;line-height:1.5;">{profile.get('competitive_advantage','')}</p>
    <p style="font-size:12px;color:#636E72;margin:2px 0;"><b>Peer Group:</b> {peers}</p>

    <!-- SECTION 4: CRITICAL FACTORS (EPIC filtered) -->
    <h2 style="color:#1B2838;font-size:15px;margin:16px 0 8px;border-bottom:2px solid #DEE2E6;padding-bottom:4px;">Critical Factors</h2>
    <ul style="margin:4px 0 8px;padding-left:20px;">{cf_items}</ul>
    <div style="margin:4px 0 16px;">
      <span style="font-size:12px;color:#636E72;font-weight:600;">Catalysts & Timing:</span>
      <ul style="margin:2px 0;padding-left:20px;">{cat_items}</ul>
    </div>

    <!-- SECTION 5: FINANCIAL PROFILE -->
    <h2 style="color:#1B2838;font-size:15px;margin:16px 0 8px;border-bottom:2px solid #DEE2E6;padding-bottom:4px;">Financial Profile</h2>
    <div style="display:flex;gap:24px;flex-wrap:wrap;">
      <table style="border-collapse:collapse;font-size:13px;flex:1;min-width:280px;">
        <tr style="background:#2D4A5E;"><th colspan="2" style="padding:6px 8px;color:#FFF;text-align:left;font-size:12px;">Prices & Scores</th></tr>
        <tr><td style="padding:4px 8px;color:#636E72;">Price (USD / CAD)</td><td style="padding:4px 8px;text-align:right;font-weight:600;">{_fmt(p)} / {_fmt(pc)}</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;color:#636E72;">GF Fair Value</td><td style="padding:4px 8px;text-align:right;">{_fmt(gf_fv)} ({_pct(gf_pd)})</td></tr>
        <tr><td style="padding:4px 8px;color:#636E72;">GF Score</td><td style="padding:4px 8px;text-align:right;">{_fmt(td.get('gf_score'), '{:.0f}')}</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;color:#636E72;">Beta (5Y)</td><td style="padding:4px 8px;text-align:right;">{_fmt(td.get('beta'), '{:.2f}')}</td></tr>
        <tr><td style="padding:4px 8px;color:#636E72;">Altman Z-Score</td><td style="padding:4px 8px;text-align:right;">{_fmt(td.get('altman_z'), '{:.1f}')}</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;color:#636E72;">Piotroski F-Score</td><td style="padding:4px 8px;text-align:right;">{_fmt(td.get('piotroski'), '{:.0f}')}</td></tr>
        <tr><td style="padding:4px 8px;color:#636E72;">Momentum Rank</td><td style="padding:4px 8px;text-align:right;">{_fmt(td.get('momentum_rank'), '{:.0f}')}</td></tr>
      </table>

      <table style="border-collapse:collapse;font-size:13px;flex:1;min-width:320px;">
        <tr style="background:#4A4A2D;"><th style="padding:6px 8px;color:#FFF;text-align:left;font-size:12px;">Metric</th>
            <th style="padding:6px 8px;color:#FFF;text-align:right;font-size:12px;">Trailing</th>
            <th style="padding:6px 8px;color:#FFF;text-align:right;font-size:12px;">Fwd Est</th>
            <th style="padding:6px 8px;color:#FFF;text-align:right;font-size:12px;">CAGR</th></tr>
        <tr><td style="padding:4px 8px;">Revenue</td>
            <td style="padding:4px 8px;text-align:right;">{_fmt(td.get('rev_realized'), '{:,.0f}')}</td>
            <td style="padding:4px 8px;text-align:right;">{_fmt(td.get('rev_estimate'), '{:,.0f}')}</td>
            <td style="padding:4px 8px;text-align:right;font-weight:600;">{_pct(rev_g)}</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;">EBITDA</td>
            <td style="padding:4px 8px;text-align:right;">{_fmt(td.get('ebitda_realized'), '{:,.0f}')}</td>
            <td style="padding:4px 8px;text-align:right;">{_fmt(td.get('ebitda_estimate'), '{:,.0f}')}</td>
            <td style="padding:4px 8px;text-align:right;font-weight:600;">{_pct(ebitda_g)}</td></tr>
        <tr><td style="padding:4px 8px;">EPS</td>
            <td style="padding:4px 8px;text-align:right;">{_fmt(td.get('eps_realized'), '{:.2f}')}</td>
            <td style="padding:4px 8px;text-align:right;">{_fmt(td.get('eps_estimate'), '{:.2f}')}</td>
            <td style="padding:4px 8px;text-align:right;font-weight:600;">{_pct(eps_g)}</td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;">DPS</td>
            <td style="padding:4px 8px;text-align:right;">{_fmt(td.get('div_realized'), '{:.2f}')}</td>
            <td style="padding:4px 8px;text-align:right;">{_fmt(td.get('div_estimate'), '{:.2f}')}</td>
            <td style="padding:4px 8px;text-align:right;font-weight:600;">{_pct(div_g)}</td></tr>
        <tr><td style="padding:4px 8px;">CFO ($B)</td>
            <td colspan="2" style="padding:4px 8px;text-align:right;">{_fmt(td.get('cfo_b'), '{:.3f}')}</td>
            <td></td></tr>
        <tr style="background:#F8F9FA;"><td style="padding:4px 8px;">FCF ($B)</td>
            <td colspan="2" style="padding:4px 8px;text-align:right;">{_fmt(td.get('fcf_b'), '{:.3f}')}</td>
            <td></td></tr>
      </table>
    </div>

    <!-- SECTION 6: VALUATION DETAIL -->
    <h2 style="color:#1B2838;font-size:15px;margin:20px 0 8px;border-bottom:2px solid #DEE2E6;padding-bottom:4px;">Valuation</h2>
    <p style="font-size:12px;color:#636E72;margin:2px 0 8px;"><b>Primary Method:</b> {dcf.get('method_label', profile.get('valuation_method','FCF DCF'))}</p>

    <div style="display:flex;gap:24px;flex-wrap:wrap;">
      <table style="border-collapse:collapse;font-size:13px;flex:1;min-width:200px;">
        <tr style="background:#4A2D5A;"><th colspan="2" style="padding:6px 8px;color:#FFF;text-align:left;font-size:12px;">{dcf.get('method_label','FCF DCF')} Assumptions</th></tr>
        {_val_detail_rows(dcf, n)}
        <tr style="border-top:2px solid #DEE2E6;"><td style="padding:6px 8px;font-weight:700;">Implied Price</td>
            <td style="padding:6px 8px;text-align:right;font-weight:700;font-size:15px;color:{tc};">{_fmt(ip)}</td></tr>
      </table>

      <table style="border-collapse:collapse;font-size:13px;flex:1;min-width:240px;">
        <tr><th style="padding:6px;background:#1B2838;color:#FFF;font-size:11px;">{"CoE" if dcf.get("method","").startswith("DDM") else "WACC"} \\ Tg</th>{sens_headers}</tr>
        {sens_rows}
      </table>
    </div>

    <!-- Scenarios -->
    <table style="width:100%;border-collapse:collapse;font-size:13px;margin:12px 0;">
      <tr style="background:#2D4A5E;">
        <th style="padding:6px 8px;color:#FFF;text-align:left;">Scenario</th>
        <th style="padding:6px 8px;color:#FFF;text-align:right;">Fair Value</th>
        <th style="padding:6px 8px;color:#FFF;text-align:right;">vs Current</th>
        <th style="padding:6px 8px;color:#FFF;text-align:left;">Assumptions</th>
      </tr>
      {sc_row("Bull", sc.get("bull",{}), "#D4EDDA")}
      {sc_row("Base", sc.get("base",{}), "#F8F9FA")}
      {sc_row("Bear", sc.get("bear",{}), "#F8D7DA")}
    </table>

    {_render_onepager_optionality(optionality)}

    <!-- SECTION 7: WHERE WE COULD BE WRONG -->
    <h2 style="color:#721C24;font-size:15px;margin:16px 0 8px;border-bottom:2px solid #F8D7DA;padding-bottom:4px;">Where We Could Be Wrong</h2>
    <ul style="margin:4px 0;padding-left:20px;">{risk_items}</ul>

  </div>

  <!-- FOOTER -->
  <div style="padding:10px 24px;background:#F8F9FA;border-top:1px solid #DEE2E6;">
    <p style="margin:0;font-size:10px;color:#636E72;">
      Sources: GuruFocus API, analyst consensus estimates, company filings. Not investment advice. | Est. horizon: t+{n}
    </p>
  </div>
</div></body></html>"""


# ============================================================================
#  EXCEL ONE-PAGER TAB
# ============================================================================

def add_onepager_sheet(wb, ticker_data: dict, analysis: dict, profile: dict):
    """Add a one-pager tab to the workbook for a single ticker."""
    td = ticker_data
    dcf = analysis.get("dcf", {})
    sc = analysis.get("scenarios", {})
    vd = analysis.get("verdict", {})
    optionality = analysis.get("optionality")
    p = td.get("price_usd", 0) or 0
    ip = dcf.get("implied_price", 0) or 0
    n = dcf.get("est_horizon", 3) or 3

    ticker = td.get("ticker", "")
    ws = wb.create_sheet(title=f"1P_{ticker}"[:31])

    # Styles
    hf = PatternFill(start_color="1B2838", end_color="1B2838", fill_type="solid")
    hfont = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
    lf = Font(name="Calibri", size=10, color="636E72")
    vf = Font(name="Calibri", size=10, color="2D3436", bold=True)
    tf = Font(name="Calibri", size=14, color="FFFFFF", bold=True)
    sf = Font(name="Calibri", size=11, color="1B2838", bold=True)  # section header
    thin = Border(
        bottom=Side(style="thin", color="DEE2E6"))

    r = 1
    # Title
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    c = ws.cell(row=r, column=1, value=f"{td.get('company','')} ({ticker}) -- One-Pager")
    c.font = tf; c.fill = hf
    r += 1
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    c = ws.cell(row=r, column=1, value=f"{td.get('sector','')} | Mkt Cap: ${(td.get('mktcap_b') or 0):.1f}B | {datetime.date.today().strftime('%B %d, %Y')}")
    c.font = Font(name="Calibri", size=10, color="ADB5BD"); c.fill = hf
    r += 2

    # VERDICT
    ws.cell(row=r, column=1, value="VERDICT:").font = Font(name="Calibri", bold=True, size=12)
    vc = ws.cell(row=r, column=2, value=f"{vd.get('rating','')} by {vd.get('magnitude','')} | Confidence: {vd.get('confidence','')}")
    vc.font = Font(name="Calibri", bold=True, size=12)
    rating = vd.get("rating", "")
    if "Under" in rating: vc.fill = PatternFill(start_color="D4EDDA", end_color="D4EDDA", fill_type="solid")
    elif "Over" in rating: vc.fill = PatternFill(start_color="F8D7DA", end_color="F8D7DA", fill_type="solid")
    else: vc.fill = PatternFill(start_color="FFF3CD", end_color="FFF3CD", fill_type="solid")
    r += 1
    ws.cell(row=r, column=1, value="DCF Implied Price:").font = lf
    c = ws.cell(row=r, column=2, value=ip); c.number_format = "$#,##0.00"; c.font = vf
    ws.cell(row=r, column=3, value="Current:").font = lf
    c = ws.cell(row=r, column=4, value=p); c.number_format = "$#,##0.00"; c.font = vf
    dcf_up = (ip / p - 1) if ip and p and p > 0 else None
    ws.cell(row=r, column=5, value="Upside:").font = lf
    c = ws.cell(row=r, column=6, value=dcf_up); c.number_format = "0.0%"; c.font = vf
    r += 2

    # COMPANY SNAPSHOT
    ws.cell(row=r, column=1, value="COMPANY SNAPSHOT").font = sf; ws.cell(row=r, column=1).border = thin; r += 1
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    ws.cell(row=r, column=1, value=profile.get("description", "")).font = Font(name="Calibri", size=10, color="2D3436")
    ws.row_dimensions[r].height = 40
    r += 1

    # Business lines
    for seg_name, pct_val, desc in profile.get("business_lines", []):
        ws.cell(row=r, column=1, value=seg_name).font = vf
        c = ws.cell(row=r, column=2, value=pct_val / 100); c.number_format = "0%"; c.font = lf
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=6)
        ws.cell(row=r, column=3, value=desc).font = Font(name="Calibri", size=9, color="636E72")
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="Mission:").font = Font(name="Calibri", size=9, color="636E72", italic=True)
    ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=6)
    ws.cell(row=r, column=2, value=profile.get("mission", "")).font = Font(name="Calibri", size=9, color="636E72", italic=True)
    r += 2

    # COMPETITIVE POSITION
    ws.cell(row=r, column=1, value="COMPETITIVE POSITION").font = sf; ws.cell(row=r, column=1).border = thin; r += 1
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    ws.cell(row=r, column=1, value=profile.get("competitive_advantage", "")).font = Font(name="Calibri", size=10)
    ws.row_dimensions[r].height = 40
    r += 1
    ws.cell(row=r, column=1, value="Peers:").font = lf
    ws.cell(row=r, column=2, value=", ".join(profile.get("peer_group", []))).font = vf
    r += 2

    # CRITICAL FACTORS
    ws.cell(row=r, column=1, value="CRITICAL FACTORS").font = sf; ws.cell(row=r, column=1).border = thin; r += 1
    for i, cf in enumerate(profile.get("critical_factors", []), 1):
        ws.cell(row=r, column=1, value=f"{i}.").font = vf
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=6)
        ws.cell(row=r, column=2, value=cf).font = Font(name="Calibri", size=10)
        r += 1
    r += 1

    # Catalysts
    ws.cell(row=r, column=1, value="Catalysts:").font = Font(name="Calibri", size=10, bold=True, color="636E72")
    r += 1
    for cat_name, cat_timing in profile.get("catalysts", []):
        ws.cell(row=r, column=1, value=cat_name).font = Font(name="Calibri", size=9)
        ws.cell(row=r, column=3, value=cat_timing).font = Font(name="Calibri", size=9, color="636E72")
        r += 1
    r += 1

    # FINANCIAL PROFILE
    ws.cell(row=r, column=1, value="FINANCIAL PROFILE").font = sf; ws.cell(row=r, column=1).border = thin; r += 1

    # Scores row
    for label, key, fmt in [("GF Score", "gf_score", "0"), ("Beta", "beta", "0.00"),
                             ("Altman Z", "altman_z", "0.0"), ("Piotroski F", "piotroski", "0"),
                             ("Momentum", "momentum_rank", "0")]:
        ws.cell(row=r, column=1, value=label).font = lf
        c = ws.cell(row=r, column=2, value=td.get(key)); c.number_format = fmt; c.font = vf
        r += 1

    r += 1
    # Growth table header
    for ci, h in enumerate(["Metric", "Trailing", "Fwd Est", "CAGR", "Horizon"], 1):
        c = ws.cell(row=r, column=ci, value=h); c.font = hfont; c.fill = hf
    r += 1

    rev_n = td.get("rev_est_horizon") or n
    eps_n = td.get("eps_est_horizon") or n
    ebitda_n = td.get("ebitda_est_horizon") or n
    div_n = td.get("div_est_horizon") or n
    rev_g = _smart_cagr(td.get("rev_realized"), td.get("rev_estimate"), rev_n)
    eps_g = _smart_cagr(td.get("eps_realized"), td.get("eps_estimate"), eps_n)
    ebitda_g = _smart_cagr(td.get("ebitda_realized"), td.get("ebitda_estimate"), ebitda_n)
    div_g = _smart_cagr(td.get("div_realized"), td.get("div_estimate"), div_n)

    for label, trail, fwd, growth, hor, trail_fmt, fwd_fmt in [
        ("Revenue", td.get("rev_realized"), td.get("rev_estimate"), rev_g, rev_n, "#,##0", "#,##0"),
        ("EBITDA", td.get("ebitda_realized"), td.get("ebitda_estimate"), ebitda_g, ebitda_n, "#,##0", "#,##0"),
        ("EPS", td.get("eps_realized"), td.get("eps_estimate"), eps_g, eps_n, "#,##0.00", "#,##0.00"),
        ("DPS", td.get("div_realized"), td.get("div_estimate"), div_g, div_n, "#,##0.00", "#,##0.00"),
    ]:
        ws.cell(row=r, column=1, value=label).font = vf
        c = ws.cell(row=r, column=2, value=trail); c.number_format = trail_fmt if trail else "General"
        c = ws.cell(row=r, column=3, value=fwd); c.number_format = fwd_fmt if fwd else "General"
        c = ws.cell(row=r, column=4, value=growth); c.number_format = "0.0%"
        ws.cell(row=r, column=5, value=f"t+{hor}").font = lf
        r += 1

    # CFO/FCF
    ws.cell(row=r, column=1, value="CFO ($B)").font = vf
    c = ws.cell(row=r, column=2, value=td.get("cfo_b")); c.number_format = "#,##0.000"
    r += 1
    ws.cell(row=r, column=1, value="FCF ($B)").font = vf
    c = ws.cell(row=r, column=2, value=td.get("fcf_b")); c.number_format = "#,##0.000"
    r += 2

    # VALUATION
    method = dcf.get("method", "FCF_DCF")
    method_label = dcf.get("method_label", "FCF DCF")
    ws.cell(row=r, column=1, value="VALUATION").font = sf; ws.cell(row=r, column=1).border = thin; r += 1
    ws.cell(row=r, column=1, value="Method:").font = lf
    ws.cell(row=r, column=2, value=method_label).font = vf; r += 1

    if method in ("DDM_BANK", "DDM_INSURER", "DDM_REIT"):
        val_rows = [("Starting DPS", dcf.get("starting_dps"), "$#,##0.00"),
                     ("Dividend Growth", dcf.get("dividend_growth"), "0.0%"),
                     ("Terminal Growth", dcf.get("terminal_growth"), "0.0%"),
                     ("Cost of Equity", dcf.get("cost_of_equity"), "0.0%"),
                     ("Current Yield", dcf.get("current_yield"), "0.0%"),
                     ("Implied Yield", dcf.get("implied_yield"), "0.0%"),
                     ("DDM Implied Price", ip, "$#,##0.00")]
    else:
        val_rows = [("Starting FCF ($B)", dcf.get("starting_fcf"), "#,##0.000"),
                     ("Revenue Growth", dcf.get("revenue_growth"), "0.0%"),
                     ("Terminal Growth", dcf.get("terminal_growth"), "0.0%"),
                     ("WACC", dcf.get("wacc"), "0.0%"),
                     ("Implied Price", ip, "$#,##0.00")]

    for label, val, fmt in val_rows:
        ws.cell(row=r, column=1, value=label).font = lf
        c = ws.cell(row=r, column=2, value=val); c.number_format = fmt; c.font = vf
        r += 1
    r += 1

    # Scenarios
    for ci, h in enumerate(["Scenario", "Fair Value", "vs Current", "Assumptions"], 1):
        c = ws.cell(row=r, column=ci, value=h); c.font = hfont; c.fill = hf
    r += 1
    for nm, s, color in [("Bull", sc.get("bull", {}), "D4EDDA"),
                          ("Base", sc.get("base", {}), "F8F9FA"),
                          ("Bear", sc.get("bear", {}), "F8D7DA")]:
        fill = PatternFill(start_color=color, end_color=color, fill_type="solid")
        ws.cell(row=r, column=1, value=nm).fill = fill; ws.cell(row=r, column=1).font = vf
        c = ws.cell(row=r, column=2, value=s.get("price")); c.number_format = "$#,##0.00"; c.fill = fill
        c = ws.cell(row=r, column=3, value=s.get("upside")); c.number_format = "+0.0%;-0.0%"; c.fill = fill
        ws.merge_cells(start_row=r, start_column=4, end_row=r, end_column=6)
        ws.cell(row=r, column=4, value=s.get("assumption", "")).fill = fill
        r += 1
    r += 1

    # OPTIONALITY PREMIUM (hyperscalers only)
    if optionality:
        opt_hf = PatternFill(start_color="7C3AED", end_color="7C3AED", fill_type="solid")
        opt_font = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
        c = ws.cell(row=r, column=1, value=f"OPTIONALITY PREMIUM (+{optionality['premium_pct']:.0%})")
        c.font = Font(name="Calibri", size=11, bold=True, color="7C3AED"); c.border = thin; r += 1
        ws.cell(row=r, column=1, value="Base DCF:").font = lf
        c = ws.cell(row=r, column=2, value=optionality["base_implied_price"]); c.number_format = "$#,##0.00"; c.font = vf
        ws.cell(row=r, column=3, value="Adjusted:").font = lf
        c = ws.cell(row=r, column=4, value=optionality["adjusted_implied_price"]); c.number_format = "$#,##0.00"
        c.font = Font(name="Calibri", bold=True, size=10, color="7C3AED"); r += 1

        for ci, h in enumerate(["Venture", "Description", "Conviction", "Timing"], 1):
            c = ws.cell(row=r, column=ci, value=h); c.font = opt_font; c.fill = opt_hf
        r += 1
        for v_name, v_desc, v_conv, v_time in optionality.get("ventures", []):
            ws.cell(row=r, column=1, value=v_name).font = vf
            ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=2)
            ws.cell(row=r, column=2, value=v_desc).font = Font(name="Calibri", size=9, color="636E72")
            conv_cell = ws.cell(row=r, column=3, value=v_conv)
            if v_conv == "High":
                conv_cell.fill = PatternFill(start_color="D4EDDA", end_color="D4EDDA", fill_type="solid")
                conv_cell.font = Font(name="Calibri", size=9, color="155724", bold=True)
            elif v_conv == "Medium":
                conv_cell.fill = PatternFill(start_color="FFF3CD", end_color="FFF3CD", fill_type="solid")
                conv_cell.font = Font(name="Calibri", size=9, color="856404")
            ws.cell(row=r, column=4, value=v_time).font = Font(name="Calibri", size=9, color="636E72")
            r += 1
        r += 1

    # RISKS
    ws.cell(row=r, column=1, value="WHERE WE COULD BE WRONG").font = Font(name="Calibri", size=11, bold=True, color="721C24")
    ws.cell(row=r, column=1).border = thin; r += 1
    for i, risk in enumerate(profile.get("key_risks", []), 1):
        ws.cell(row=r, column=1, value=f"{i}.").font = Font(name="Calibri", size=10, color="721C24")
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=6)
        ws.cell(row=r, column=2, value=risk).font = Font(name="Calibri", size=10)
        r += 1

    # Column widths
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 16
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 10
    ws.column_dimensions["F"].width = 30

