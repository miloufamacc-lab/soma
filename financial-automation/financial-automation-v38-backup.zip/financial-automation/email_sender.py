"""
Email Sender -- Gmail SMTP with per-recipient HTML themes.
  Work (RBC):  clean professional + .xlsx
  Personal:    Bloomberg dark theme + .xlsx
"""

import smtplib, os, logging, datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from config.settings import GMAIL_SENDER, GMAIL_APP_PASSWORD, EMAIL_RECIPIENTS

logger = logging.getLogger(__name__)


def _build_message(sender, recipient, subject, html_body, xlsx_path=None, attach_excel=True):
    msg = MIMEMultipart("mixed")
    msg["From"] = sender; msg["To"] = recipient; msg["Subject"] = subject
    msg.attach(MIMEText(html_body, "html"))
    if attach_excel and xlsx_path and os.path.exists(xlsx_path):
        with open(xlsx_path, "rb") as f:
            att = MIMEBase("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            att.set_payload(f.read())
            encoders.encode_base64(att)
            fn = os.path.basename(xlsx_path)
            att.add_header("Content-Disposition", f"attachment; filename={fn}")
            msg.attach(att)
        logger.info(f"Attached {fn} ({os.path.getsize(xlsx_path)/1024:.0f} KB)")
    return msg


def send_daily_email(html_body, xlsx_path, recipients=None,
                     sender=GMAIL_SENDER, app_password=GMAIL_APP_PASSWORD,
                     subject=None, bloomberg_html=None):
    if subject is None:
        subject = f"Equity Ranking Dashboard -- {datetime.date.today().strftime('%b %d, %Y')}"
    if recipients is None:
        recipients = EMAIL_RECIPIENTS
    all_ok = True
    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.ehlo(); server.starttls(); server.ehlo()
            server.login(sender, app_password)
            for entry in recipients:
                addr = entry["email"]
                attach = entry.get("attach_excel", True)
                is_personal = not addr.endswith("@rbc.com")
                body = bloomberg_html if (is_personal and bloomberg_html) else html_body
                msg = _build_message(sender, addr, subject, body, xlsx_path, attach)
                try:
                    server.sendmail(sender, addr, msg.as_string())
                    theme = "Bloomberg" if (is_personal and bloomberg_html) else "Standard"
                    logger.info(f"Sent to {addr} ({theme}, {'with .xlsx' if attach else 'HTML only'})")
                except Exception as e:
                    logger.error(f"Failed {addr}: {e}"); all_ok = False
    except smtplib.SMTPAuthenticationError:
        logger.error("Gmail auth failed -- check App Password"); return False
    except Exception as e:
        logger.error(f"SMTP error: {e}"); return False
    return all_ok


def send_valuation_email(html_body, ticker, xlsx_path=None, recipients=None):
    subject = f"Valuation Model: {ticker} -- {datetime.date.today().strftime('%b %d, %Y')}"
    return send_daily_email(html_body, xlsx_path, recipients=recipients, subject=subject)

