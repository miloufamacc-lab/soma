"""
HTML Email Renderer -- v3.8
  - render_html_email()           -> clean professional (work/RBC)
  - render_bloomberg_html_email() -> Bloomberg Terminal dark theme (personal)

v3.4: DCF Fair Value + DCF Upside + Verdict columns in both themes
v3.8: Strategy/CDN/US section headers, Market [CDN]/[US] column, ARK Score column
"""
import datetime
from config.settings import (STRATEGY_TICKER_SET, STRATEGY_PINNED,
                              STRATEGY_ETF_TICKERS, STRATEGY_OVERLAP, STRATEGY_API_MAP)
from market_tags import get_market, get_tag
from ark_bigideas import get_ark_summary


def _smart_cagr(realized, estimate, n):
    if not realized or not estimate or realized <= 0 or n <= 0 or estimate <= 0:
        return None
    try: return (estimate / realized) ** (1.0 / n) - 1
    except: return None


def _split_sections(ticker_data_list):
    """Split ticker_data_list into Strategy, CDN, US sections (same logic as Excel)."""
    strategy_data = []
    cdn_data = []
    us_data = []

    for td in ticker_data_list:
        ticker = td.get("ticker", "")
        is_overlay = td.get("_is_overlay", False)
        is_strategy = td.get("_is_strategy", False) or ticker in STRATEGY_TICKER_SET

        if is_overlay:
            # Overlay copy -> Strategy section ONLY
            strategy_data.append(td)
        elif ticker in STRATEGY_OVERLAP or td.get("_api_ticker", ticker) in STRATEGY_OVERLAP:
            # Original overlap ticker -> CDN/US section ONLY (overlay handles Strategy)
            api_t = STRATEGY_API_MAP.get(ticker, td.get("_api_ticker", ticker))
            if get_market(api_t) == "CA":
                cdn_data.append(td)
            else:
                us_data.append(td)
        elif is_strategy:
            # Strategy-only ticker -> Strategy section
            strategy_data.append(td)
        else:
            # Regular portfolio ticker -> CDN/US
            if get_market(ticker) == "CA":
                cdn_data.append(td)
            else:
                us_data.append(td)

    # Sort Strategy: pinned first, then by DCF Upside, ETFs at bottom
    pinned = [t for t in strategy_data if t.get("ticker","") in STRATEGY_PINNED]
    etfs = [t for t in strategy_data if t.get("ticker","") in STRATEGY_ETF_TICKERS]
    stocks = [t for t in strategy_data
              if t.get("ticker","") not in STRATEGY_PINNED
              and t.get("ticker","") not in STRATEGY_ETF_TICKERS]
    pinned.sort(key=lambda x: STRATEGY_PINNED.index(x.get("ticker",""))
                if x.get("ticker","") in STRATEGY_PINNED else 999)
    stocks.sort(key=lambda x: x.get("dcf_upside") if x.get("dcf_upside") is not None else -999, reverse=True)
    strategy_data = pinned + stocks + etfs

    cdn_data.sort(key=lambda x: x.get("dcf_upside") if x.get("dcf_upside") is not None else -999, reverse=True)
    us_data.sort(key=lambda x: x.get("dcf_upside") if x.get("dcf_upside") is not None else -999, reverse=True)

    return strategy_data, cdn_data, us_data


# ==============================================================================
# STANDARD THEME (work / RBC)
# ==============================================================================
def render_html_email(ticker_data_list: list, usdcad: float = 1.36) -> str:
    today = datetime.date.today().strftime("%B %d, %Y")
    now = datetime.datetime.now().strftime("%H:%M ET")

    strategy_data, cdn_data, us_data = _split_sections(ticker_data_list)

    def _render_rows(data_list, start_idx=0):
        rows = ""
        for i, td in enumerate(data_list):
            bg = "#F8F9FA" if (i + start_idx) % 2 == 0 else "#FFFFFF"
            pu = td.get("price_usd"); pc = td.get("price_cad")
            pt = td.get("price_target"); gf = td.get("gf_score")
            az = td.get("altman_z"); pi = td.get("piotroski"); mom = td.get("momentum_rank")
            ticker = td.get("ticker", "")
            api_t = td.get("_api_ticker", STRATEGY_API_MAP.get(ticker, ticker))
            mkt = get_tag(api_t)
            ark_composite, ark_top, _ = get_ark_summary(api_t)
            if ark_composite == 0 and ticker != api_t:
                ark_composite, ark_top, _ = get_ark_summary(ticker)
            is_etf = td.get("_is_etf", False) or ticker in STRATEGY_ETF_TICKERS

            n = td.get("est_horizon", 3) or 3
            rev_n = td.get("rev_est_horizon") or n
            rr, re = td.get("rev_realized"), td.get("rev_estimate")
            rg = _smart_cagr(rr, re, rev_n) if not is_etf else None
            if rg is None and not is_etf: rg = td.get("precomp_rev_growth")
            pd_val = (pu/pt-1) if pu and pt and pt>0 and not is_etf else None

            dcf_fv = td.get("dcf_fair_value")
            dcf_upside = (dcf_fv / pu - 1) if dcf_fv and pu and pu > 0 else None
            dcf_verdict = td.get("dcf_verdict", "")

            def cell(v, fmt="${:.2f}", default="--"):
                if v is None: return f'<td style="padding:6px 10px;text-align:right;color:#636E72;">{default}</td>'
                return f'<td style="padding:6px 10px;text-align:right;">{fmt.format(v)}</td>'
            def cond(v, lo=None, hi=None, fmt="{:.1f}", default="--"):
                if v is None: return f'<td style="padding:6px 10px;text-align:right;color:#636E72;">{default}</td>'
                s = "padding:6px 10px;text-align:right;"
                if lo is not None and v < lo: s += "background:#F8D7DA;color:#721C24;font-weight:600;"
                elif hi is not None and v >= hi: s += "background:#D4EDDA;color:#155724;font-weight:600;"
                return f'<td style="{s}">{fmt.format(v)}</td>'
            def pct(v):
                if v is None: return '<td style="padding:6px 10px;text-align:right;color:#636E72;">--</td>'
                s = "padding:6px 10px;text-align:right;"
                if v > 0.15: s += "background:#D4EDDA;color:#155724;"
                elif v < -0.15: s += "background:#F8D7DA;color:#721C24;"
                return f'<td style="{s}">{v:+.1%}</td>'
            def dcf_pct_cell(v):
                if v is None: return '<td style="padding:6px 10px;text-align:right;color:#636E72;">--</td>'
                s = "padding:6px 10px;text-align:right;font-weight:600;"
                if v > 0.15: s += "background:#D4EDDA;color:#155724;"
                elif v < -0.10: s += "background:#F8D7DA;color:#721C24;"
                else: s += "background:#FFF3CD;color:#856404;"
                return f'<td style="{s}">{v:+.1%}</td>'
            def verdict_cell(v):
                if not v: return '<td style="padding:6px 10px;text-align:center;color:#636E72;">--</td>'
                s = "padding:6px 10px;text-align:center;font-weight:600;font-size:12px;"
                if "Under" in v: s += "background:#D4EDDA;color:#155724;"
                elif "Over" in v: s += "background:#F8D7DA;color:#721C24;"
                elif "ETF" in v: s += "background:#E2E8F0;color:#4A5568;"
                else: s += "background:#FFF3CD;color:#856404;"
                return f'<td style="{s}">{v}</td>'

            rows += f"""<tr style="background:{bg};">
              <td style="padding:6px 10px;font-weight:600;">{td.get('company','')}</td>
              <td style="padding:6px 10px;font-family:monospace;font-size:12px;">{ticker}</td>
              <td style="padding:6px 10px;text-align:center;font-size:11px;">{mkt}</td>
              {cell(pc)} {cell(pu)}
              {cond(gf, lo=50, hi=85, fmt='{:.0f}')}
              {pct(rg)} {cell(pt)}
              {cell(dcf_fv)}
              {dcf_pct_cell(dcf_upside)}
              {verdict_cell(dcf_verdict)}
              {pct(pd_val)}
              {cell(td.get('cfo_b'), fmt='{:.3f}')} {cell(td.get('fcf_b'), fmt='{:.3f}')}
              {cond(az, lo=1.81)} {cond(pi, hi=7, fmt='{:.0f}')}
              {cell(td.get('beta'), fmt='{:.2f}')}
              {cell(td.get('mktcap_b'), fmt='{:.1f}')}
              {cell(mom, fmt='{:.1f}')}
              <td style="padding:6px 10px;text-align:right;font-size:11px;">{ark_composite:.0f}</td>
            </tr>"""
        return rows

    def _section_header_row(label, bg="#2C3E50"):
        return f"""<tr><td colspan="20" style="padding:10px 12px;background:{bg};color:#FFF;font-weight:700;font-size:13px;border-bottom:2px solid #1B2838;">{label}</td></tr>"""

    # Build table header
    th_style = 'padding:10px;text-align:right;color:#FFF;'
    th_left = 'padding:10px;text-align:left;color:#FFF;'
    th_center = 'padding:10px;text-align:center;color:#FFF;'
    dcf_th = th_style + 'background:#4A2D5E;'

    header_row = f"""<tr style="background:#2D4A5E;">
        <th style="{th_left}">Company</th>
        <th style="{th_left}">Ticker</th>
        <th style="{th_center}">Mkt</th>
        <th style="{th_style}">CAD</th>
        <th style="{th_style}">USD</th>
        <th style="{th_style}">GF Score</th>
        <th style="{th_style}">Rev CAGR</th>
        <th style="{th_style}">GF Fair Value</th>
        <th style="{dcf_th}">DCF Fair Value</th>
        <th style="{dcf_th}">DCF Upside</th>
        <th style="{th_center}background:#4A2D5E;">Verdict</th>
        <th style="{th_style}">Prem/Disc</th>
        <th style="{th_style}">CFO</th>
        <th style="{th_style}">FCF</th>
        <th style="{th_style}">Z-Score</th>
        <th style="{th_style}">F-Score</th>
        <th style="{th_style}">Beta</th>
        <th style="{th_style}">Mkt Cap</th>
        <th style="{th_style}">Momentum</th>
        <th style="{th_style}">ARK</th>
    </tr>"""

    # Build body with section headers
    body = ""
    row_idx = 0
    if strategy_data:
        body += _section_header_row(f"\U0001F3AF Strategy ({len(strategy_data)})")
        body += _render_rows(strategy_data, row_idx)
        row_idx += len(strategy_data)
    if cdn_data:
        body += _section_header_row(f"\U0001F1E8\U0001F1E6 Canadian Focus List ({len(cdn_data)})", "#3D5A80")
        body += _render_rows(cdn_data, row_idx)
        row_idx += len(cdn_data)
    if us_data:
        body += _section_header_row(f"\U0001F1FA\U0001F1F8 US Focus List ({len(us_data)})", "#3D5A80")
        body += _render_rows(us_data, row_idx)

    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"></head>
<body style="margin:0;padding:20px;font-family:Calibri,'Segoe UI',Arial,sans-serif;background:#F0F2F5;">
<div style="max-width:1500px;margin:0 auto;background:#FFF;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
  <div style="background:#1B2838;padding:18px 24px;">
    <h1 style="margin:0;color:#FFF;font-size:18px;">Equity Ranking Dashboard</h1>
    <p style="margin:4px 0 0;color:#ADB5BD;font-size:12px;">{today} &bull; {now} &bull; USD/CAD: {usdcad:.4f}</p>
  </div>
  <div style="overflow-x:auto;">
    <table style="width:100%;border-collapse:collapse;font-size:13px;color:#2D3436;">
      <thead>{header_row}</thead>
      <tbody>{body}</tbody>
    </table>
  </div>
  <div style="padding:12px 24px;background:#F8F9FA;border-top:1px solid #DEE2E6;">
    <p style="margin:0;font-size:11px;color:#636E72;">
      <span style="background:#D4EDDA;padding:2px 6px;border-radius:3px;">Strong/Undervalued</span>
      <span style="background:#FFF3CD;padding:2px 6px;border-radius:3px;margin-left:4px;">Fairly Valued</span>
      <span style="background:#F8D7DA;padding:2px 6px;border-radius:3px;margin-left:4px;">Attention/Overvalued</span>
      <span style="background:#E2E8F0;padding:2px 6px;border-radius:3px;margin-left:4px;">ETF</span>
      &nbsp;&bull;&nbsp; DCF = Implied share price from analysts' estimates &bull; Full data in .xlsx &bull; Source: GuruFocus
    </p>
  </div>
</div></body></html>"""


# ==============================================================================
# BLOOMBERG THEME (personal)
# ==============================================================================
def render_bloomberg_html_email(ticker_data_list: list, usdcad: float = 1.36) -> str:
    today = datetime.date.today().strftime("%Y-%m-%d")
    now = datetime.datetime.now().strftime("%H:%M ET")

    strategy_data, cdn_data, us_data = _split_sections(ticker_data_list)

    def _render_bb_rows(data_list, start_idx=0):
        rows = ""
        for i, td in enumerate(data_list):
            bg = "#1A1A2E" if (i + start_idx) % 2 == 0 else "#16213E"
            pu = td.get("price_usd"); pc = td.get("price_cad")
            pt = td.get("price_target"); gf = td.get("gf_score")
            az = td.get("altman_z"); pi = td.get("piotroski"); mom = td.get("momentum_rank")
            ticker = td.get("ticker", "")
            api_t = td.get("_api_ticker", STRATEGY_API_MAP.get(ticker, ticker))
            mkt = get_tag(api_t)
            ark_composite, _, _ = get_ark_summary(api_t)
            if ark_composite == 0 and ticker != api_t:
                ark_composite, _, _ = get_ark_summary(ticker)
            is_etf = td.get("_is_etf", False) or ticker in STRATEGY_ETF_TICKERS

            n = td.get("est_horizon", 3) or 3
            rev_n = td.get("rev_est_horizon") or n
            eps_n = td.get("eps_est_horizon") or n
            ebitda_n = td.get("ebitda_est_horizon") or n

            rr, re = td.get("rev_realized"), td.get("rev_estimate")
            rg = _smart_cagr(rr, re, rev_n) if not is_etf else None
            if rg is None and not is_etf: rg = td.get("precomp_rev_growth")

            pd_val = (pu/pt-1) if pu and pt and pt>0 and not is_etf else None
            er, ee = td.get("eps_realized"), td.get("eps_estimate")
            eg = _smart_cagr(er, ee, eps_n) if not is_etf else None
            if eg is None and not is_etf: eg = td.get("precomp_eps_growth")

            ebr, ebe = td.get("ebitda_realized"), td.get("ebitda_estimate")
            ebg = _smart_cagr(ebr, ebe, ebitda_n) if not is_etf else None

            dcf_fv = td.get("dcf_fair_value")
            dcf_upside = (dcf_fv / pu - 1) if dcf_fv and pu and pu > 0 else None
            dcf_verdict = td.get("dcf_verdict", "")

            def bb(v, fmt="{:.2f}", color="#E0E0E0"):
                if v is None: return '<td style="padding:5px 8px;text-align:right;color:#555;font-family:Consolas,monospace;font-size:12px;">--</td>'
                return f'<td style="padding:5px 8px;text-align:right;color:{color};font-family:Consolas,monospace;font-size:12px;">{fmt.format(v)}</td>'
            def bb_pct(v, invert=False):
                if v is None: return bb(None)
                c = "#E0E0E0"
                if not invert:
                    if v > 0.05: c = "#00FF41"
                    elif v < -0.05: c = "#FF4444"
                else:
                    if v < -0.10: c = "#00FF41"
                    elif v > 0.10: c = "#FF4444"
                return f'<td style="padding:5px 8px;text-align:right;color:{c};font-family:Consolas,monospace;font-size:12px;">{v:+.1%}</td>'
            def bb_sc(v, lo=None, hi=None, fmt="{:.1f}"):
                if v is None: return bb(None)
                c = "#FF9F1C"
                if lo is not None and v < lo: c = "#FF4444"
                elif hi is not None and v >= hi: c = "#00FF41"
                return f'<td style="padding:5px 8px;text-align:right;color:{c};font-family:Consolas,monospace;font-size:12px;font-weight:600;">{fmt.format(v)}</td>'
            def bb_dcf_pct(v):
                if v is None: return bb(None)
                c = "#FF9F1C"
                if v > 0.15: c = "#00FF41"
                elif v < -0.10: c = "#FF4444"
                return f'<td style="padding:5px 8px;text-align:right;color:{c};font-family:Consolas,monospace;font-size:12px;font-weight:700;">{v:+.1%}</td>'
            def bb_verdict(v):
                if not v: return bb(None)
                c = "#FF9F1C"
                if "Under" in v: c = "#00FF41"
                elif "Over" in v: c = "#FF4444"
                elif "ETF" in v: c = "#87CEEB"
                short = "UNDR" if "Under" in v else "OVER" if "Over" in v else "ETF" if "ETF" in v else "FAIR"
                return f'<td style="padding:5px 8px;text-align:center;color:{c};font-family:Consolas,monospace;font-size:11px;font-weight:700;">{short}</td>'

            mkt_color = "#87CEEB" if "[US]" in mkt else "#FF9F1C"

            rows += f"""<tr style="background:{bg};border-bottom:1px solid #0A0A1A;">
              <td style="padding:5px 8px;color:#FF9F1C;font-weight:700;font-family:Consolas,monospace;font-size:12px;">{ticker}</td>
              <td style="padding:5px 8px;color:#E0E0E0;font-family:Consolas,monospace;font-size:11px;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{td.get('company','')}</td>
              <td style="padding:5px 8px;text-align:center;color:{mkt_color};font-family:Consolas,monospace;font-size:10px;font-weight:700;">{mkt}</td>
              {bb(pc,'{:.2f}','#FFFFFF')} {bb(pu,'{:.2f}','#FFFFFF')}
              {bb_sc(gf, lo=50, hi=80, fmt='{:.0f}')}
              {bb(pt,'{:.2f}','#87CEEB')}
              {bb(dcf_fv,'{:.2f}','#FFFFFF')}
              {bb_dcf_pct(dcf_upside)}
              {bb_verdict(dcf_verdict)}
              {bb_pct(pd_val, invert=True)}
              {bb_pct(rg)} {bb_pct(eg)} {bb_pct(ebg)}
              {bb(td.get('cfo_b'),'{:.2f}')} {bb(td.get('fcf_b'),'{:.2f}')}
              {bb_sc(az, lo=1.81, hi=3.0)} {bb_sc(pi, lo=4, hi=7, fmt='{:.0f}')}
              {bb(td.get('beta'),'{:.2f}','#87CEEB')} {bb(td.get('mktcap_b'),'{:.1f}')} {bb(mom,'{:.0f}')}
              {bb(ark_composite,'{:.0f}','#87CEEB')}
              <td style="padding:5px 8px;text-align:center;color:#555;font-family:Consolas,monospace;font-size:10px;">t+{n}</td>
            </tr>"""
        return rows

    def _bb_section(label, bg="#1A1A3E"):
        return f"""<tr><td colspan="23" style="padding:8px 12px;background:{bg};border-bottom:2px solid #FF9F1C;"><span style="color:#00FF41;font-family:Consolas,monospace;font-size:12px;font-weight:700;letter-spacing:1px;">{label}</span></td></tr>"""

    # Header
    th = 'padding:6px 8px;text-align:right;color:#FF9F1C;font-size:10px;'
    th_l = 'padding:6px 8px;text-align:left;color:#FF9F1C;font-size:10px;'
    th_c = 'padding:6px 8px;text-align:center;color:#FF9F1C;font-size:10px;'
    th_dcf = 'padding:6px 8px;text-align:right;color:#E0B0FF;font-size:10px;'

    header = f"""<tr style="background:#1A1A3E;border-bottom:2px solid #FF9F1C;">
        <th style="{th_l}">TICKER</th><th style="{th_l}">COMPANY</th>
        <th style="{th_c}">MKT</th>
        <th style="{th}">CAD</th><th style="{th}">USD</th>
        <th style="{th}">GF</th><th style="{th}">GF FV</th>
        <th style="{th_dcf}border-left:1px solid #FF9F1C;">DCF FV</th>
        <th style="{th_dcf}">DCF%</th>
        <th style="{th_c}color:#E0B0FF;border-right:1px solid #FF9F1C;">VERD</th>
        <th style="{th}">P/D</th>
        <th style="{th}">REV</th><th style="{th}">EPS</th><th style="{th}">EBITDA</th>
        <th style="{th}">CFO</th><th style="{th}">FCF</th>
        <th style="{th}">Z</th><th style="{th}">F</th>
        <th style="{th}">BETA</th><th style="{th}">MCAP</th><th style="{th}">MOM</th>
        <th style="{th}">ARK</th>
        <th style="{th_c}">EST</th>
    </tr>"""

    body = ""
    idx = 0
    if strategy_data:
        body += _bb_section(f"STRATEGY ({len(strategy_data)})")
        body += _render_bb_rows(strategy_data, idx)
        idx += len(strategy_data)
    if cdn_data:
        body += _bb_section(f"CANADIAN FOCUS ({len(cdn_data)})", "#0F1A2E")
        body += _render_bb_rows(cdn_data, idx)
        idx += len(cdn_data)
    if us_data:
        body += _bb_section(f"US FOCUS ({len(us_data)})", "#0F1A2E")
        body += _render_bb_rows(us_data, idx)

    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"></head>
<body style="margin:0;padding:12px;font-family:Consolas,monospace;background:#0A0A1A;">
<div style="max-width:1500px;margin:0 auto;background:#0F0F23;border:1px solid #1A1A3E;overflow:hidden;">
  <div style="background:#FF9F1C;padding:2px 12px;">
    <span style="color:#0A0A1A;font-size:11px;font-weight:700;letter-spacing:1px;">EQUITY RANKING</span>
    <span style="color:#0A0A1A;font-size:11px;float:right;">{today}</span>
  </div>
  <div style="padding:8px 12px;background:#0F0F23;border-bottom:1px solid #1A1A3E;">
    <span style="color:#00FF41;font-size:14px;font-weight:700;letter-spacing:1px;">CDN CORE EQUITY MONITOR</span>
    <span style="color:#555;font-size:11px;margin-left:16px;">{now}</span>
    <span style="color:#555;font-size:11px;margin-left:16px;">USD/CAD: <span style="color:#FF9F1C;">{usdcad:.4f}</span></span>
  </div>
  <div style="overflow-x:auto;">
    <table style="width:100%;border-collapse:collapse;font-size:12px;">
      <thead>{header}</thead>
      <tbody>{body}</tbody>
    </table>
  </div>
  <div style="padding:8px 12px;background:#0A0A1A;border-top:1px solid #1A1A3E;">
    <span style="color:#555;font-size:10px;">
      <span style="color:#00FF41;">&#9632;</span> UNDR
      <span style="color:#FF9F1C;">&#9632;</span> FAIR
      <span style="color:#FF4444;">&#9632;</span> OVER
      <span style="color:#87CEEB;">&#9632;</span> ETF
      &nbsp;|&nbsp; DCF = Implied share price from consensus estimates
      &nbsp;|&nbsp; Growth = CAGR (dynamic horizon) &nbsp;|&nbsp; Source: GuruFocus &nbsp;|&nbsp; Full data in .xlsx
    </span>
  </div>
</div></body></html>"""
