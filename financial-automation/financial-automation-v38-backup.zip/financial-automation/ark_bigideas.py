"""
ARK Invest 13 Big Ideas 2026 — Stock Ticker Relevance Mapping
v3.8 module — proximity index for 76 tickers (56 original + 20 new strategy)
"""

ARK_BIG_IDEAS = {
    "AI_INFRA":             {"name": "AI Infrastructure",       "short": "AI Infra"},
    "AI_CONSUMER":          {"name": "AI Consumer OS",          "short": "AI Consumer"},
    "AI_PRODUCTIVITY":      {"name": "AI Productivity",         "short": "AI Prod"},
    "BITCOIN":              {"name": "Bitcoin",                 "short": "Bitcoin"},
    "TOKENIZED_ASSETS":     {"name": "Tokenized Assets",       "short": "Tokenized"},
    "DEFI":                 {"name": "Decentralized Finance",   "short": "DeFi"},
    "MULTIOMICS":           {"name": "Multiomics",             "short": "Multiomics"},
    "REUSABLE_ROCKETS":     {"name": "Reusable Rockets",       "short": "Rockets"},
    "ROBOTICS":             {"name": "Robotics",               "short": "Robotics"},
    "DISTRIBUTED_ENERGY":   {"name": "Distributed Energy",     "short": "Dist Energy"},
    "AUTONOMOUS_VEHICLES":  {"name": "Autonomous Vehicles",    "short": "Auto Vehicles"},
    "AUTONOMOUS_LOGISTICS": {"name": "Autonomous Logistics",   "short": "Auto Logistics"},
    "CONVERGENCE":          {"name": "The Great Acceleration",  "short": "Convergence"},
}

# Scoring: 0=none, 1=tangential, 2=minor segment, 3=moderate, 4=major line, 5=core business
STOCK_RELEVANCE = {
    # ============================================================
    # ORIGINAL 56 TICKERS (unchanged from v3.6)
    # ============================================================
    "NVDA": {
        "company": "NVIDIA", "country": "US",
        "scores": {"AI_INFRA":5,"AI_CONSUMER":2,"AI_PRODUCTIVITY":3,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":2,"REUSABLE_ROCKETS":1,"ROBOTICS":4,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":3,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":3},
        "top_ideas": [("AI_INFRA","Core GPU/data-center business"),("ROBOTICS","Jetson/Isaac robotics platforms"),("AUTONOMOUS_VEHICLES","DRIVE AV computing")]
    },
    "GOOG": {
        "company": "Alphabet", "country": "US",
        "scores": {"AI_INFRA":4,"AI_CONSUMER":4,"AI_PRODUCTIVITY":5,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":1,"REUSABLE_ROCKETS":2,"ROBOTICS":2,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":2,"AUTONOMOUS_LOGISTICS":2,"CONVERGENCE":4},
        "top_ideas": [("AI_PRODUCTIVITY","Gemini across Workspace, enterprise AI"),("AI_CONSUMER","Search/Android agentic OS"),("AI_INFRA","Google Cloud AI infrastructure")]
    },
    "MSFT": {
        "company": "Microsoft", "country": "US",
        "scores": {"AI_INFRA":4,"AI_CONSUMER":3,"AI_PRODUCTIVITY":5,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":1,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":1,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":3},
        "top_ideas": [("AI_PRODUCTIVITY","Copilot across Office/Teams"),("AI_INFRA","Azure AI cloud"),("AI_CONSUMER","Windows/Bing AI consumer")]
    },
    "META": {
        "company": "Meta Platforms", "country": "US",
        "scores": {"AI_INFRA":3,"AI_CONSUMER":5,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":2},
        "top_ideas": [("AI_CONSUMER","Llama models, agentic AI in social apps"),("AI_INFRA","Massive data-center capex"),("AI_PRODUCTIVITY","Business platform AI")]
    },
    "AMZN": {
        "company": "Amazon", "country": "US",
        "scores": {"AI_INFRA":4,"AI_CONSUMER":4,"AI_PRODUCTIVITY":3,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":3,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":4,"CONVERGENCE":3},
        "top_ideas": [("AI_INFRA","AWS compute/AI core revenue"),("AUTONOMOUS_LOGISTICS","Delivery drones, last-mile"),("AI_CONSUMER","Alexa agentic commerce")]
    },
    "AAPL": {
        "company": "Apple", "country": "US",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":4,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("AI_CONSUMER","Apple Intelligence, on-device AI"),("AI_PRODUCTIVITY","Pro devices + AI productivity"),("CONVERGENCE","Ecosystem device convergence")]
    },
    "AVGO": {
        "company": "Broadcom", "country": "US",
        "scores": {"AI_INFRA":4,"AI_CONSUMER":1,"AI_PRODUCTIVITY":0,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":1,"ROBOTICS":2,"DISTRIBUTED_ENERGY":1,"AUTONOMOUS_VEHICLES":2,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":2},
        "top_ideas": [("AI_INFRA","Networking chips for data centers"),("ROBOTICS","Components for autonomous systems"),("AUTONOMOUS_VEHICLES","Automotive semiconductors")]
    },
    "PANW": {
        "company": "Palo Alto Networks", "country": "US",
        "scores": {"AI_INFRA":2,"AI_CONSUMER":0,"AI_PRODUCTIVITY":3,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("AI_PRODUCTIVITY","AI-powered enterprise security"),("AI_INFRA","Securing AI infrastructure")]
    },
    "NOW": {
        "company": "ServiceNow", "country": "US",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":1,"AI_PRODUCTIVITY":5,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":2},
        "top_ideas": [("AI_PRODUCTIVITY","Now Assist agentic AI for enterprise workflows"),("CONVERGENCE","Platform convergence via AI")]
    },
    "SHOP": {
        "company": "Shopify", "country": "CA",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":4,"AI_PRODUCTIVITY":3,"BITCOIN":1,"TOKENIZED_ASSETS":1,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":2,"CONVERGENCE":2},
        "top_ideas": [("AI_CONSUMER","Agentic commerce, AI-driven selling"),("AI_PRODUCTIVITY","AI for merchants, store optimization")]
    },
    "JPM": {
        "company": "JPMorgan Chase", "country": "US",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":2,"AI_PRODUCTIVITY":3,"BITCOIN":2,"TOKENIZED_ASSETS":3,"DEFI":1,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("AI_PRODUCTIVITY","Enterprise AI and banking ops"),("TOKENIZED_ASSETS","Digital assets, tokenization R&D")]
    },
    "BAC": {
        "company": "Bank of America", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":1,"AI_PRODUCTIVITY":3,"BITCOIN":1,"TOKENIZED_ASSETS":1,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("AI_PRODUCTIVITY","Banking process AI + Erica chatbot"),("BITCOIN","Digital asset custody")]
    },
    "MA": {
        "company": "Mastercard", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":3,"AI_PRODUCTIVITY":2,"BITCOIN":1,"TOKENIZED_ASSETS":3,"DEFI":1,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":2},
        "top_ideas": [("AI_CONSUMER","Digital wallets, agentic commerce"),("TOKENIZED_ASSETS","Crypto integrations, blockchain")]
    },
    "AON": {
        "company": "Aon", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":4,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("AI_PRODUCTIVITY","Enterprise AI for risk/insurance automation")]
    },
    "SPGI": {
        "company": "S&P Global", "country": "US",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":1,"AI_PRODUCTIVITY":3,"BITCOIN":0,"TOKENIZED_ASSETS":2,"DEFI":1,"MULTIOMICS":1,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("AI_PRODUCTIVITY","Data analytics + enterprise AI"),("TOKENIZED_ASSETS","Digital asset ratings")]
    },
    "JNJ": {
        "company": "Johnson & Johnson", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":4,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("MULTIOMICS","Drug development, gene therapy, AI pharma"),("AI_PRODUCTIVITY","AI in clinical research")]
    },
    "UNH": {
        "company": "UnitedHealth Group", "country": "US",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":1,"AI_PRODUCTIVITY":4,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":3,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("AI_PRODUCTIVITY","Healthcare ops automation / Optum AI"),("MULTIOMICS","Genomic insights, personalized medicine")]
    },
    "SYK": {
        "company": "Stryker", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":1,"REUSABLE_ROCKETS":0,"ROBOTICS":3,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("ROBOTICS","Mako surgical robotics platform"),("AI_PRODUCTIVITY","AI-assisted surgical planning")]
    },
    "HON": {
        "company": "Honeywell", "country": "US",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":0,"AI_PRODUCTIVITY":3,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":1,"ROBOTICS":3,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":1,"AUTONOMOUS_LOGISTICS":2,"CONVERGENCE":2},
        "top_ideas": [("ROBOTICS","Industrial robotics + automation"),("AI_PRODUCTIVITY","Enterprise ops AI")]
    },
    "RTX": {
        "company": "RTX Corporation", "country": "US",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":2,"ROBOTICS":2,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":2,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":1},
        "top_ideas": [("REUSABLE_ROCKETS","Aerospace and space tech"),("ROBOTICS","Defense robotics + autonomous")]
    },
    "UNP": {
        "company": "Union Pacific", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":1,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":4,"CONVERGENCE":1},
        "top_ideas": [("AUTONOMOUS_LOGISTICS","Rail automation, network optimization"),("AI_PRODUCTIVITY","Fleet management AI")]
    },
    "XYL": {
        "company": "Xylem", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("DISTRIBUTED_ENERGY","Water/energy optimization"),("AI_PRODUCTIVITY","Smart infrastructure IoT")]
    },
    "APH": {
        "company": "Amphenol", "country": "US",
        "scores": {"AI_INFRA":2,"AI_CONSUMER":1,"AI_PRODUCTIVITY":0,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":1,"ROBOTICS":2,"DISTRIBUTED_ENERGY":1,"AUTONOMOUS_VEHICLES":2,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":2},
        "top_ideas": [("AI_INFRA","Data center connectors"),("ROBOTICS","Connectors for automation")]
    },
    "CVX": {
        "company": "Chevron", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":0},
        "top_ideas": [("DISTRIBUTED_ENERGY","Renewable energy investments"),("AI_PRODUCTIVITY","Extraction/ops optimization")]
    },
    "NEE": {
        "company": "NextEra Energy", "country": "US",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":5,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("DISTRIBUTED_ENERGY","Core business: solar, wind, battery storage"),("AI_INFRA","Power for data centers")]
    },
    "ECL": {
        "company": "Ecolab", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("DISTRIBUTED_ENERGY","Sustainable water/energy solutions"),("AI_PRODUCTIVITY","AI-driven industrial optimization")]
    },
    "HD": {
        "company": "Home Depot", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":2,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":3,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":1},
        "top_ideas": [("DISTRIBUTED_ENERGY","Solar/battery installation services"),("AI_CONSUMER","E-commerce AI")]
    },
    "TJX": {
        "company": "TJX Companies", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":2,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":1},
        "top_ideas": [("AI_CONSUMER","AI-enhanced retail"),("ROBOTICS","Store/logistics automation")]
    },
    "COST": {
        "company": "Costco", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":2,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":2,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":2,"CONVERGENCE":1},
        "top_ideas": [("AI_CONSUMER","Membership commerce platform"),("ROBOTICS","Warehouse automation")]
    },
    # -- Canadian tickers (unchanged) --
    "RY": {
        "company": "Royal Bank of Canada", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":1,"AI_PRODUCTIVITY":2,"BITCOIN":1,"TOKENIZED_ASSETS":1,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("AI_PRODUCTIVITY","Banking automation + digital services"),("BITCOIN","Limited crypto services")]
    },
    "TD": {
        "company": "Toronto-Dominion Bank", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":1,"AI_PRODUCTIVITY":2,"BITCOIN":1,"TOKENIZED_ASSETS":1,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("AI_PRODUCTIVITY","Banking ops + digital transformation"),("BITCOIN","Digital asset services")]
    },
    "BMO": {
        "company": "Bank of Montreal", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":1,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":1,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("AI_PRODUCTIVITY","Banking ops and digital innovation"),("TOKENIZED_ASSETS","Emerging tokenization")]
    },
    "CM": {
        "company": "CIBC", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":1,"AI_PRODUCTIVITY":2,"BITCOIN":1,"TOKENIZED_ASSETS":1,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("AI_PRODUCTIVITY","Corporate banking automation"),("BITCOIN","Digital asset infrastructure")]
    },
    "NTIOF": {
        "company": "National Bank of Canada", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":1,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("AI_PRODUCTIVITY","Banking operations + digital"),("AI_CONSUMER","Retail digital platforms")]
    },
    "MFC": {
        "company": "Manulife", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":1,"AI_PRODUCTIVITY":3,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":1,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("AI_PRODUCTIVITY","Insurance ops automation + AI analytics"),("MULTIOMICS","Health/longevity data analytics")]
    },
    "SLF": {
        "company": "Sun Life", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":1,"AI_PRODUCTIVITY":3,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":1,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("AI_PRODUCTIVITY","Insurance automation + AI ops"),("MULTIOMICS","Health data analytics")]
    },
    "IFCZF": {
        "company": "Intact Financial", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("AI_PRODUCTIVITY","Underwriting + claims automation")]
    },
    "BN": {
        "company": "Brookfield Corp", "country": "CA",
        "scores": {"AI_INFRA":2,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":1},
        "top_ideas": [("DISTRIBUTED_ENERGY","Renewable energy + battery storage"),("AI_INFRA","Data center investments")]
    },
    "SU": {
        "company": "Suncor Energy", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":1,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":0},
        "top_ideas": [("DISTRIBUTED_ENERGY","Energy transition + renewables"),("AI_PRODUCTIVITY","Oil sands optimization via AI")]
    },
    "PBA": {
        "company": "Pembina Pipeline", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("DISTRIBUTED_ENERGY","Energy infrastructure + transition"),("AI_PRODUCTIVITY","Pipeline optimization")]
    },
    "TRP": {
        "company": "TC Energy", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("DISTRIBUTED_ENERGY","Energy infra + renewable transition"),("AI_PRODUCTIVITY","Grid/pipeline optimization")]
    },
    "BIP": {
        "company": "Brookfield Infrastructure", "country": "CA",
        "scores": {"AI_INFRA":2,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":2,"CONVERGENCE":1},
        "top_ideas": [("DISTRIBUTED_ENERGY","Renewable power infra"),("AI_INFRA","Data center + connectivity")]
    },
    "FCXXF": {
        "company": "First Capital REIT", "country": "CA",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":1,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("AI_CONSUMER","Retail real estate evolution"),("AI_INFRA","Smart building infra")]
    },
    "CP": {
        "company": "Canadian Pacific Kansas City", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":4,"CONVERGENCE":1},
        "top_ideas": [("AUTONOMOUS_LOGISTICS","Rail automation + autonomous logistics"),("AI_PRODUCTIVITY","Operational optimization")]
    },
    "SNCAF": {
        "company": "AtkinsRealis", "country": "CA",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":1,"ROBOTICS":1,"DISTRIBUTED_ENERGY":1,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":1},
        "top_ideas": [("AI_PRODUCTIVITY","Engineering AI optimization"),("ROBOTICS","Construction automation")]
    },
    "BDRBF": {
        "company": "Bombardier", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":1,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":1,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("AUTONOMOUS_VEHICLES","Aerospace + autonomous systems"),("REUSABLE_ROCKETS","Space/advanced transport")]
    },
    "ELEEF": {
        "company": "Element Fleet Management", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":3,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":3,"AUTONOMOUS_LOGISTICS":3,"CONVERGENCE":1},
        "top_ideas": [("AUTONOMOUS_VEHICLES","Fleet management for AVs"),("AUTONOMOUS_LOGISTICS","Autonomous trucking transition")]
    },
    "GFL": {
        "company": "GFL Environmental", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":1,"AUTONOMOUS_VEHICLES":1,"AUTONOMOUS_LOGISTICS":2,"CONVERGENCE":0},
        "top_ideas": [("AUTONOMOUS_LOGISTICS","Autonomous collection + routing"),("ROBOTICS","Automated sorting")]
    },
    "RBA": {
        "company": "RB Global", "country": "CA",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":2,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":1,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":1},
        "top_ideas": [("AI_CONSUMER","Digital equipment marketplace"),("AI_PRODUCTIVITY","Enterprise AI + market optimization")]
    },
    "WSPOF": {
        "company": "WSP Global", "country": "CA",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":0,"AI_PRODUCTIVITY":3,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":1,"AUTONOMOUS_VEHICLES":1,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":1},
        "top_ideas": [("AI_PRODUCTIVITY","Engineering AI + smart infra"),("ROBOTICS","Industrial automation")]
    },
    "TMTNF": {
        "company": "Toromont Industries", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":0},
        "top_ideas": [("DISTRIBUTED_ENERGY","Equipment for renewable deployment"),("AI_PRODUCTIVITY","Operations + fleet optimization")]
    },
    "CNSWF": {
        "company": "Constellation Software", "country": "CA",
        "scores": {"AI_INFRA":2,"AI_CONSUMER":1,"AI_PRODUCTIVITY":4,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":2},
        "top_ideas": [("AI_PRODUCTIVITY","Enterprise software + AI integration"),("AI_INFRA","Software infra for AI deployments")]
    },
    "DLMAF": {
        "company": "Dollarama", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":2,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":0},
        "top_ideas": [("AI_CONSUMER","Consumer commerce platform"),("ROBOTICS","Warehouse automation")]
    },
    "LBLCF": {
        "company": "Loblaw Companies", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":2,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":2,"CONVERGENCE":1},
        "top_ideas": [("AI_CONSUMER","Retail commerce, loyalty, personalization"),("AUTONOMOUS_LOGISTICS","Supply chain + delivery")]
    },
    "ANCTF": {
        "company": "Couche-Tard", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":2,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":1,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":1,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":0},
        "top_ideas": [("AI_CONSUMER","Digital payment integration"),("TOKENIZED_ASSETS","Digital wallet innovation")]
    },
    "CCDBF": {
        "company": "CCL Industries", "country": "CA",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":0},
        "top_ideas": [("ROBOTICS","Manufacturing automation"),("AUTONOMOUS_LOGISTICS","Supply chain ops")]
    },
    # ============================================================
    # v3.8: NEW STRATEGY TICKERS (20 new)
    # ============================================================
    "TSLA": {
        "company": "Tesla", "country": "US",
        "scores": {"AI_INFRA":3,"AI_CONSUMER":2,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":2,"ROBOTICS":4,"DISTRIBUTED_ENERGY":3,"AUTONOMOUS_VEHICLES":5,"AUTONOMOUS_LOGISTICS":3,"CONVERGENCE":4},
        "top_ideas": [("AUTONOMOUS_VEHICLES","Full Self-Driving, Robotaxi fleet"),("ROBOTICS","Optimus humanoid robot"),("DISTRIBUTED_ENERGY","Megapack, Powerwall, Solar Roof")]
    },
    "MSTR": {
        "company": "MicroStrategy", "country": "US",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":0,"AI_PRODUCTIVITY":2,"BITCOIN":5,"TOKENIZED_ASSETS":3,"DEFI":1,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("BITCOIN","Largest corporate BTC holder, BTC treasury strategy"),("TOKENIZED_ASSETS","Digital asset balance sheet"),("AI_PRODUCTIVITY","BI analytics platform")]
    },
    "COIN": {
        "company": "Coinbase Global", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":2,"AI_PRODUCTIVITY":1,"BITCOIN":4,"TOKENIZED_ASSETS":4,"DEFI":4,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":2},
        "top_ideas": [("BITCOIN","Core crypto exchange, institutional custody"),("DEFI","Base L2 chain, on-chain economy"),("TOKENIZED_ASSETS","Stablecoin infrastructure (USDC)")]
    },
    "CRWD": {
        "company": "CrowdStrike", "country": "US",
        "scores": {"AI_INFRA":3,"AI_CONSUMER":0,"AI_PRODUCTIVITY":4,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":2},
        "top_ideas": [("AI_PRODUCTIVITY","AI-native cybersecurity, Charlotte AI"),("AI_INFRA","Securing cloud/AI infrastructure")]
    },
    "GOOGL": {
        "company": "Alphabet Class A", "country": "US",
        "scores": {"AI_INFRA":4,"AI_CONSUMER":4,"AI_PRODUCTIVITY":5,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":1,"REUSABLE_ROCKETS":2,"ROBOTICS":2,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":2,"AUTONOMOUS_LOGISTICS":2,"CONVERGENCE":4},
        "top_ideas": [("AI_PRODUCTIVITY","Gemini across Workspace, enterprise AI"),("AI_CONSUMER","Search/Android agentic OS"),("AI_INFRA","Google Cloud AI infrastructure")]
    },
    "MELI": {
        "company": "MercadoLibre", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":4,"AI_PRODUCTIVITY":2,"BITCOIN":1,"TOKENIZED_ASSETS":2,"DEFI":2,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":3,"CONVERGENCE":2},
        "top_ideas": [("AI_CONSUMER","LatAm e-commerce + fintech super-app"),("AUTONOMOUS_LOGISTICS","Last-mile delivery network"),("TOKENIZED_ASSETS","Mercado Pago crypto integration")]
    },
    "PLTR": {
        "company": "Palantir Technologies", "country": "US",
        "scores": {"AI_INFRA":3,"AI_CONSUMER":1,"AI_PRODUCTIVITY":5,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":1,"REUSABLE_ROCKETS":1,"ROBOTICS":2,"DISTRIBUTED_ENERGY":1,"AUTONOMOUS_VEHICLES":1,"AUTONOMOUS_LOGISTICS":2,"CONVERGENCE":3},
        "top_ideas": [("AI_PRODUCTIVITY","AIP platform, enterprise AI orchestration"),("AI_INFRA","Foundry data infrastructure"),("CONVERGENCE","Cross-domain AI integration")]
    },
    "AMD": {
        "company": "Advanced Micro Devices", "country": "US",
        "scores": {"AI_INFRA":5,"AI_CONSUMER":1,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":1,"REUSABLE_ROCKETS":0,"ROBOTICS":2,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":1,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":2},
        "top_ideas": [("AI_INFRA","MI300X data center GPUs, EPYC server CPUs"),("ROBOTICS","Embedded computing for robotics"),("AI_PRODUCTIVITY","AI accelerators for enterprise")]
    },
    "TSM": {
        "company": "Taiwan Semiconductor", "country": "US",
        "scores": {"AI_INFRA":5,"AI_CONSUMER":1,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":1,"ROBOTICS":2,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":2,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":3},
        "top_ideas": [("AI_INFRA","Foundry for all AI chips (NVDA, AMD, AAPL)"),("CONVERGENCE","Enabling semiconductor convergence"),("AUTONOMOUS_VEHICLES","Automotive chip fabrication")]
    },
    "ISRG": {
        "company": "Intuitive Surgical", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":3,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":2,"REUSABLE_ROCKETS":0,"ROBOTICS":5,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":2},
        "top_ideas": [("ROBOTICS","da Vinci surgical robotics platform"),("AI_PRODUCTIVITY","AI-assisted surgical planning + analytics"),("MULTIOMICS","Precision surgery guided by genomics")]
    },
    "DELL": {
        "company": "Dell Technologies", "country": "US",
        "scores": {"AI_INFRA":4,"AI_CONSUMER":1,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":2},
        "top_ideas": [("AI_INFRA","AI servers, PowerEdge for training/inference"),("AI_PRODUCTIVITY","Enterprise AI infrastructure"),("CONVERGENCE","Edge-to-cloud AI stack")]
    },
    "SOFI": {
        "company": "SoFi Technologies", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":3,"AI_PRODUCTIVITY":2,"BITCOIN":1,"TOKENIZED_ASSETS":2,"DEFI":3,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("DEFI","Digital banking platform, Galileo fintech infra"),("AI_CONSUMER","Personal finance super-app"),("TOKENIZED_ASSETS","Crypto trading, digital assets")]
    },
    "HOOD": {
        "company": "Robinhood Markets", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":3,"AI_PRODUCTIVITY":1,"BITCOIN":2,"TOKENIZED_ASSETS":3,"DEFI":2,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("TOKENIZED_ASSETS","Crypto/options trading platform"),("AI_CONSUMER","Democratized investing super-app"),("BITCOIN","BTC/crypto trading revenue")]
    },
    "VST": {
        "company": "Vistra Corp", "country": "US",
        "scores": {"AI_INFRA":2,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":4,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("DISTRIBUTED_ENERGY","Nuclear + solar + battery storage"),("AI_INFRA","Data center power supply")]
    },
    "ORCL": {
        "company": "Oracle", "country": "US",
        "scores": {"AI_INFRA":3,"AI_CONSUMER":1,"AI_PRODUCTIVITY":4,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":1,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":2},
        "top_ideas": [("AI_PRODUCTIVITY","Cloud ERP + AI-powered enterprise software"),("AI_INFRA","OCI AI cloud infrastructure"),("MULTIOMICS","Healthcare data platform")]
    },
    "FSLR": {
        "company": "First Solar", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":5,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("DISTRIBUTED_ENERGY","US-made CdTe thin-film solar panels"),("ROBOTICS","Automated panel manufacturing")]
    },
    "CELH": {
        "company": "Celsius Holdings", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":2,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":1,"CONVERGENCE":0},
        "top_ideas": [("AI_CONSUMER","DTC consumer brand, health-focused energy"),("AI_PRODUCTIVITY","Supply chain optimization")]
    },
    "NFLX": {
        "company": "Netflix", "country": "US",
        "scores": {"AI_INFRA":2,"AI_CONSUMER":5,"AI_PRODUCTIVITY":2,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":2},
        "top_ideas": [("AI_CONSUMER","AI-driven content recommendation + creation"),("AI_INFRA","Massive streaming infrastructure + CDN"),("AI_PRODUCTIVITY","AI in content production pipeline")]
    },
    # -- Commodity ETFs (minimal ARK relevance) --
    "IAU": {
        "company": "iShares Gold Trust", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":0,"BITCOIN":0,"TOKENIZED_ASSETS":1,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":0,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("TOKENIZED_ASSETS","Gold as store-of-value, tokenization potential")]
    },
    "ICOP": {
        "company": "iShares Copper & Metals ETF", "country": "US",
        "scores": {"AI_INFRA":1,"AI_CONSUMER":0,"AI_PRODUCTIVITY":0,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":1,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":1,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":1},
        "top_ideas": [("DISTRIBUTED_ENERGY","Copper critical for electrification"),("ROBOTICS","Industrial metals demand")]
    },
    "XLE": {
        "company": "Energy Select Sector SPDR", "country": "US",
        "scores": {"AI_INFRA":0,"AI_CONSUMER":0,"AI_PRODUCTIVITY":1,"BITCOIN":0,"TOKENIZED_ASSETS":0,"DEFI":0,"MULTIOMICS":0,"REUSABLE_ROCKETS":0,"ROBOTICS":0,"DISTRIBUTED_ENERGY":2,"AUTONOMOUS_VEHICLES":0,"AUTONOMOUS_LOGISTICS":0,"CONVERGENCE":0},
        "top_ideas": [("DISTRIBUTED_ENERGY","Traditional + transitioning energy sector"),("AI_PRODUCTIVITY","Operations optimization")]
    },
}

def calculate_composite_score(scores_dict):
    return (sum(scores_dict.values()) / 65.0) * 100.0

for _t, _d in STOCK_RELEVANCE.items():
    _d["composite_score"] = calculate_composite_score(_d["scores"])

def get_ark_summary(ticker):
    data = STOCK_RELEVANCE.get(ticker.upper())
    if not data:
        return (0.0, "N/A", 0)
    composite = data["composite_score"]
    top = data.get("top_ideas", [])
    if top:
        key = top[0][0]
        score = data["scores"].get(key, 0)
        short = ARK_BIG_IDEAS.get(key, {}).get("short", key)
        return (composite, short, score)
    return (composite, "N/A", 0)

def get_ark_detail(ticker):
    return STOCK_RELEVANCE.get(ticker.upper())
