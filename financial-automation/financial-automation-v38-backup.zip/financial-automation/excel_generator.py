"""
Excel Generator -- v3.8

v3.3 fixes baked in:
  - Per-field CAGR with field-specific horizon and precomp fallback
v3.4:
  - NEW: "DCF Fair Value" column on main ranking sheet (right next to GF Fair Value)
  - NEW: "DCF Upside" column showing % vs current price
v3.7:
  - NEW: "Market" column (Col 4) showing [CDN] / [US]
  - NEW: "ARK Score" column (Col 22) composite 0-100
  - NEW: "Top ARK Theme" column (Col 23)
  - NEW: CDN / US section separation
v3.8:
  - CHANGE: Market column -- no colored badges (plain text only)
  - NEW: Strategy section above CDN/US (TSLA/MSTR pinned, rest by DCF Upside)
  - NEW: Commodity Exposure sub-section for ETFs (IAU, ICOP, XLE)
  - NEW: ETF graceful degradation (price/momentum only, Verdict="ETF")
"""

import os, datetime, math
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from config.settings import (OUTPUT_DIR, STRATEGY_TICKER_SET, STRATEGY_PINNED,
                              STRATEGY_ETF_TICKERS, STRATEGY_OVERLAP, STRATEGY_API_MAP)
from market_tags import get_market, get_tag
from ark_bigideas import get_ark_summary, get_ark_detail, ARK_BIG_IDEAS, STOCK_RELEVANCE


class C:
    TEXT = "2D3436"; TEXT_LIGHT = "636E72"; WHITE = "FFFFFF"
    HEADER_BG = "1B2838"
    SECTION_PRICE = "2D4A5E"; SECTION_SCORE = "3D5A3E"
    SECTION_FLOW = "5A3D4A"; SECTION_EST = "4A4A2D"
    SECTION_VAL = "4A2D5A"
    RED_SOFT = "F8D7DA"; AMBER_SOFT = "FFF3CD"
    GREEN_SOFT = "D4EDDA"; GREEN_VALUE = "C3E6CB"; ROSE_VALUE = "F5C6CB"
    ROW_EVEN = "F8F9FA"; ROW_ODD = "FFFFFF"; BORDER_LIGHT = "DEE2E6"


thin_border = Border(
    left=Side(style="thin", color=C.BORDER_LIGHT),
    right=Side(style="thin", color=C.BORDER_LIGHT),
    top=Side(style="thin", color=C.BORDER_LIGHT),
    bottom=Side(style="thin", color=C.BORDER_LIGHT))
header_font = Font(name="Calibri", bold=True, size=10, color=C.WHITE)
data_font   = Font(name="Calibri", size=10, color=C.TEXT)

def _fill(c): return PatternFill(start_color=c, end_color=c, fill_type="solid")


def _smart_cagr(realized, estimate, n):
    """CAGR adapting to actual estimate horizon."""
    if not realized or not estimate or realized <= 0 or n <= 0 or estimate <= 0:
        return None
    try:
        return (estimate / realized) ** (1.0 / n) - 1
    except (ValueError, ZeroDivisionError, OverflowError):
        return None


COLUMNS = [
    ("Company",            "company",         22, None,        C.HEADER_BG),
    ("Ticker",             "ticker",          8,  None,        C.HEADER_BG),
    ("ADP Code",           "adp",             10, None,        C.HEADER_BG),
    ("Market",             "market_tag",      8,  None,        C.HEADER_BG),
    ("Price CAD",          "price_cad",       12, '#,##0.00',  C.SECTION_PRICE),
    ("Price USD",          "price_usd",       12, '#,##0.00',  C.SECTION_PRICE),
    ("GF Value Score",     "gf_score",        11, '0',         C.SECTION_SCORE),
    ("Est. Rev CAGR",      "rev_growth_est",  12, '0.0%',      C.SECTION_SCORE),
    ("GF Fair Value",      "price_target",    12, '#,##0.00',  C.SECTION_SCORE),
    # ---- v3.4 NEW: DCF columns right next to GF Fair Value ----
    ("DCF Fair Value",     "dcf_fair_value",  13, '$#,##0.00', C.SECTION_VAL),
    ("DCF Upside",         "dcf_upside",      10, '0.0%',      C.SECTION_VAL),
    ("Verdict",            "dcf_verdict",     12, None,        C.SECTION_VAL),
    # ------------------------------------------------------------
    ("Prem/Disc (Hugo)",   "prem_disc_hugo",  14, '0.0%',      C.SECTION_PRICE),
    ("Prem/Disc (GF)",     "prem_disc_guru",  14, '0.0%',      C.SECTION_PRICE),
    ("CFO ($B)",           "cfo_b",           10, '#,##0.000', C.SECTION_FLOW),
    ("FCF ($B)",           "fcf_b",           10, '#,##0.000', C.SECTION_FLOW),
    ("Altman Z-Score",     "altman_z",        12, '0.0',       C.SECTION_SCORE),
    ("Piotroski F-Score",  "piotroski",       13, '0',         C.SECTION_SCORE),
    ("Beta (5Y)",          "beta",            8,  '0.00',      C.SECTION_SCORE),
    ("Market Cap ($B)",    "mktcap_b",        13, '#,##0.0',   C.SECTION_PRICE),
    ("Momentum Rank",      "momentum_rank",   12, '0.0',       C.SECTION_SCORE),
    ("ARK Score",          "ark_score",       10, '0.0',       C.SECTION_SCORE),
    ("Top ARK Theme",      "ark_top_theme",   14, None,        C.SECTION_SCORE),
    ("Focus Weight",       "focus_weight",    10, '0.0%',      C.HEADER_BG),
    ("RBC Risk Rating",    "rbc_risk",        12, None,        C.HEADER_BG),
    ("Sector",             "sector",          22, None,        C.HEADER_BG),
    ("Last Updated",       "last_update",     16, 'YYYY-MM-DD HH:MM', C.HEADER_BG),
    ("Est. Horizon",       "est_horizon_lbl", 10, None,        C.SECTION_EST),
    ("Rev CAGR",           "rev_growth_calc", 10, '0.0%',      C.SECTION_EST),
    ("Revenue Realized",   "rev_realized",    14, '#,##0',     C.SECTION_EST),
    ("Revenue Est (fwd)",  "rev_estimate",    14, '#,##0',     C.SECTION_EST),
    ("EBITDA CAGR",        "ebitda_growth",   11, '0.0%',      C.SECTION_EST),
    ("EBITDA Realized",    "ebitda_realized", 14, '#,##0',     C.SECTION_EST),
    ("EBITDA Est (fwd)",   "ebitda_estimate", 14, '#,##0',     C.SECTION_EST),
    ("EPS CAGR",           "eps_growth",      9,  '0.0%',      C.SECTION_EST),
    ("EPS Realized",       "eps_realized",    11, '#,##0.00',  C.SECTION_EST),
    ("EPS Est (fwd)",      "eps_estimate",    11, '#,##0.00',  C.SECTION_EST),
    ("DPS CAGR",           "dps_growth",      9,  '0.0%',      C.SECTION_EST),
    ("DPS Realized",       "div_realized",    11, '#,##0.00',  C.SECTION_EST),
    ("DPS Est (fwd)",      "div_estimate",    11, '#,##0.00',  C.SECTION_EST),
]

# Columns to null out for ETFs
ETF_SKIP_KEYS = {
    "dcf_fair_value", "dcf_upside", "prem_disc_hugo", "prem_disc_guru",
    "cfo_b", "fcf_b", "altman_z", "piotroski",
    "rev_growth_est", "rev_growth_calc", "rev_realized", "rev_estimate",
    "ebitda_growth", "ebitda_realized", "ebitda_estimate",
    "eps_growth", "eps_realized", "eps_estimate",
    "dps_growth", "div_realized", "div_estimate",
    "focus_weight", "gf_score", "price_target",
}


def build_ranking_sheet(ticker_data_list: list, output_path: str = None) -> str:
    if output_path is None:
        output_path = os.path.join(OUTPUT_DIR, f"ranking_{datetime.date.today()}.xlsx")

    wb = Workbook(); ws = wb.active; ws.title = "Ranking"

    # title
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(COLUMNS))
    tc = ws.cell(row=1, column=1)
    tc.value = f"Equity Ranking Dashboard -- {datetime.date.today().strftime('%B %d, %Y')}"
    tc.font = Font(name="Calibri", bold=True, size=13, color=C.WHITE)
    tc.fill = _fill(C.HEADER_BG)
    tc.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    # usd/cad
    ws.cell(row=2, column=1, value="USD/CAD:").font = Font(name="Calibri", bold=True, size=9, color=C.TEXT_LIGHT)
    uc = ws.cell(row=2, column=2, value=ticker_data_list[0].get("usdcad", 1.36) if ticker_data_list else 1.36)
    uc.font = data_font; uc.number_format = '0.0000'

    # headers
    hr = 3
    for ci, (hdr, key, w, fmt, sec) in enumerate(COLUMNS, 1):
        cell = ws.cell(row=hr, column=ci, value=hdr)
        cell.font = header_font; cell.fill = _fill(sec)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.row_dimensions[hr].height = 36

    # -- v3.8: Three-way split: Strategy -> CDN -> US --
    # Classify tickers into sections
    strategy_data = []
    cdn_tickers = []
    us_tickers = []

    for td in ticker_data_list:
        ticker = td.get("ticker", "")
        is_overlay = td.get("_is_overlay", False)
        is_strategy = td.get("_is_strategy", False) or ticker in STRATEGY_TICKER_SET

        if is_overlay:
            # Overlay copy -> Strategy section ONLY
            strategy_data.append(td)
        elif ticker in STRATEGY_OVERLAP or td.get("_api_ticker", ticker) in STRATEGY_OVERLAP:
            # Original overlap ticker -> CDN/US section ONLY (overlay handles Strategy)
            api_t = STRATEGY_API_MAP.get(ticker, td.get("_api_ticker", ticker))
            if get_market(api_t) == "CA":
                cdn_tickers.append(td)
            else:
                us_tickers.append(td)
        elif is_strategy:
            # Strategy-only ticker -> Strategy section
            strategy_data.append(td)
        else:
            # Regular portfolio ticker -> CDN/US
            if get_market(ticker) == "CA":
                cdn_tickers.append(td)
            else:
                us_tickers.append(td)

    # Sort Strategy: pinned first, then stocks by DCF Upside, ETFs at bottom
    def _sort_strategy(data):
        pinned = [t for t in data if t.get("ticker","") in STRATEGY_PINNED]
        etfs = [t for t in data if t.get("ticker","") in STRATEGY_ETF_TICKERS]
        stocks = [t for t in data
                  if t.get("ticker","") not in STRATEGY_PINNED
                  and t.get("ticker","") not in STRATEGY_ETF_TICKERS]

        pinned.sort(key=lambda x: STRATEGY_PINNED.index(x.get("ticker",""))
                    if x.get("ticker","") in STRATEGY_PINNED else 999)
        stocks.sort(key=lambda x: x.get("dcf_upside") if x.get("dcf_upside") is not None else -999, reverse=True)
        return pinned + stocks + etfs

    strategy_data = _sort_strategy(strategy_data)
    cdn_tickers.sort(key=lambda x: x.get("dcf_upside") if x.get("dcf_upside") is not None else -999, reverse=True)
    us_tickers.sort(key=lambda x: x.get("dcf_upside") if x.get("dcf_upside") is not None else -999, reverse=True)

    # Helper: write a section divider row
    def _write_section_header(ws, row, label, num_cols, color="3D5A80"):
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=num_cols)
        sc = ws.cell(row=row, column=1)
        sc.value = label
        sc.font = Font(name="Calibri", bold=True, size=11, color=C.WHITE)
        sc.fill = _fill(color)
        sc.alignment = Alignment(horizontal="left", vertical="center")
        ws.row_dimensions[row].height = 26

    sorted_data = []
    section_rows = []

    ds = hr + 1
    current_row = ds

    # ---- STRATEGY SECTION ----
    if strategy_data:
        etf_count = sum(1 for t in strategy_data if t.get("ticker","") in STRATEGY_ETF_TICKERS)
        stock_count = len(strategy_data) - etf_count
        _write_section_header(ws, current_row,
            f"  \U0001F3AF  Strategy  ({len(strategy_data)} names)", len(COLUMNS), "2C3E50")
        section_rows.append(current_row)
        current_row += 1

        # Write strategy stock rows
        etf_header_written = False
        for td in strategy_data:
            if td.get("ticker","") in STRATEGY_ETF_TICKERS and not etf_header_written:
                # Commodity Exposure sub-header
                _write_section_header(ws, current_row,
                    f"      Commodity Exposure  ({etf_count} ETFs)", len(COLUMNS), "5D6D7E")
                section_rows.append(current_row)
                current_row += 1
                etf_header_written = True
            sorted_data.append((current_row, td))
            current_row += 1

    # ---- CANADIAN FOCUS LIST ----
    _write_section_header(ws, current_row,
        f"  \U0001F1E8\U0001F1E6  Canadian Focus List  ({len(cdn_tickers)} names)", len(COLUMNS))
    section_rows.append(current_row)
    current_row += 1

    for td in cdn_tickers:
        sorted_data.append((current_row, td))
        current_row += 1

    # ---- US FOCUS LIST ----
    _write_section_header(ws, current_row,
        f"  \U0001F1FA\U0001F1F8  US Focus List  ({len(us_tickers)} names)", len(COLUMNS))
    section_rows.append(current_row)
    current_row += 1

    for td in us_tickers:
        sorted_data.append((current_row, td))
        current_row += 1

    # ---- DATA ROWS ----
    for ri, (row, td) in enumerate(sorted_data):
        row_fill = _fill(C.ROW_EVEN if ri % 2 == 0 else C.ROW_ODD)
        td["adp"] = td.get("adp", "")
        td["last_update"] = datetime.datetime.now()

        # Market tag
        ticker = td.get("ticker", "")
        api_ticker = td.get("_api_ticker", STRATEGY_API_MAP.get(ticker, ticker))
        td["market_tag"] = get_tag(api_ticker)

        # ARK scores
        ark_lookup = api_ticker if api_ticker else ticker
        ark_composite, ark_top, _ = get_ark_summary(ark_lookup)
        # Also check display ticker for GOOGL -> has its own entry in v3.8
        if ark_composite == 0 and ticker != ark_lookup:
            ark_composite, ark_top, _ = get_ark_summary(ticker)
        td["ark_score"] = round(ark_composite, 1) if ark_composite else 0.0
        td["ark_top_theme"] = ark_top

        # Is this an ETF? Skip growth/valuation columns
        is_etf = td.get("_is_etf", False) or ticker in STRATEGY_ETF_TICKERS

        # DYNAMIC GROWTH (v3.3: per-field horizon with precomp fallback)
        if not is_etf:
            n = td.get("est_horizon", 3) or 3
            if n < 1: n = 3
            td["est_horizon_lbl"] = f"t+{n}"

            for rk, ek, gk, hk, pk in [
                ("rev_realized","rev_estimate","rev_growth_calc","rev_est_horizon","precomp_rev_growth"),
                ("ebitda_realized","ebitda_estimate","ebitda_growth","ebitda_est_horizon",None),
                ("eps_realized","eps_estimate","eps_growth","eps_est_horizon","precomp_eps_growth"),
                ("div_realized","div_estimate","dps_growth","div_est_horizon","precomp_div_growth")]:
                field_n = td.get(hk) or n
                if field_n < 1: field_n = n
                growth = _smart_cagr(td.get(rk), td.get(ek), field_n)
                if growth is None and pk:
                    growth = td.get(pk)
                td[gk] = growth

            td["rev_growth_est"] = td.get("rev_growth_calc")

            pu, pt = td.get("price_usd"), td.get("price_target")
            if pu and pt and pt > 0:
                td["prem_disc_hugo"] = (pt / pu - 1) * -1
                td["prem_disc_guru"] = pu / pt - 1
            else:
                td["prem_disc_hugo"] = td["prem_disc_guru"] = None

            # DCF upside
            dcf_fv = td.get("dcf_fair_value")
            if dcf_fv and pu and pu > 0:
                td["dcf_upside"] = dcf_fv / pu - 1
            else:
                td["dcf_upside"] = None
        else:
            # ETF: null out growth/valuation fields
            td["est_horizon_lbl"] = "--"
            for key in ETF_SKIP_KEYS:
                td[key] = None
            td["dcf_verdict"] = "ETF"

        # Write cells
        for ci, (hdr, key, w, fmt, sec) in enumerate(COLUMNS, 1):
            cell = ws.cell(row=row, column=ci)
            val = td.get(key)
            cell.value = val; cell.font = data_font; cell.fill = row_fill; cell.border = thin_border
            if fmt: cell.number_format = fmt
            if key in ("company","ticker","adp","market_tag","rbc_risk","sector","est_horizon_lbl","dcf_verdict","ark_top_theme"):
                cell.alignment = Alignment(horizontal="left", vertical="center")
            else:
                cell.alignment = Alignment(horizontal="right", vertical="center")

            if val is None: continue

            # -- conditional formatting --
            if not isinstance(val, (int, float)):
                # v3.8: Market tag — NO colored badges (plain text only)
                if key == "dcf_verdict":
                    if "Under" in str(val):
                        cell.fill = _fill(C.GREEN_SOFT)
                        cell.font = Font(name="Calibri", size=10, color="155724", bold=True)
                    elif "Over" in str(val):
                        cell.fill = _fill(C.RED_SOFT)
                        cell.font = Font(name="Calibri", size=10, color="721C24", bold=True)
                    elif "Fairly" in str(val):
                        cell.fill = _fill(C.AMBER_SOFT)
                        cell.font = Font(name="Calibri", size=10, color="856404")
                    elif "ETF" in str(val):
                        cell.fill = _fill("E2E8F0")
                        cell.font = Font(name="Calibri", size=10, color="4A5568", italic=True, bold=True)
                    elif "N/M" in str(val):
                        cell.fill = _fill(C.ROW_EVEN)
                        cell.font = Font(name="Calibri", size=10, color="636E72", italic=True)
                continue

            if key == "altman_z":
                if val < 1.81:
                    cell.fill = _fill(C.RED_SOFT); cell.font = Font(name="Calibri", size=10, color="721C24", bold=True)
                elif val < 2.99:
                    cell.fill = _fill(C.AMBER_SOFT); cell.font = Font(name="Calibri", size=10, color="856404")
            elif key == "piotroski":
                if val >= 7:
                    cell.fill = _fill(C.GREEN_SOFT); cell.font = Font(name="Calibri", size=10, color="155724", bold=True)
                elif val <= 3: cell.fill = _fill(C.RED_SOFT)
            elif key in ("prem_disc_hugo","prem_disc_guru"):
                if val < -0.15: cell.fill = _fill(C.GREEN_VALUE)
                elif val > 0.15: cell.fill = _fill(C.ROSE_VALUE)
            elif key == "gf_score":
                if val >= 85:
                    cell.fill = _fill(C.GREEN_SOFT); cell.font = Font(name="Calibri", size=10, color="155724", bold=True)
                elif val <= 50: cell.fill = _fill(C.RED_SOFT)
            elif key == "rev_growth_est":
                if val > 0.10: cell.fill = _fill(C.GREEN_SOFT)
                elif val < 0: cell.fill = _fill(C.RED_SOFT)
            elif key == "dcf_upside":
                if val > 0.15:
                    cell.fill = _fill(C.GREEN_VALUE)
                    cell.font = Font(name="Calibri", size=10, color="155724", bold=True)
                elif val < -0.10:
                    cell.fill = _fill(C.ROSE_VALUE)
                    cell.font = Font(name="Calibri", size=10, color="721C24", bold=True)
            elif key == "dcf_fair_value":
                pu = td.get("price_usd")
                if pu and pu > 0:
                    ratio = val / pu
                    if ratio > 1.15:
                        cell.fill = _fill(C.GREEN_VALUE)
                        cell.font = Font(name="Calibri", size=10, color="155724", bold=True)
                    elif ratio < 0.85:
                        cell.fill = _fill(C.ROSE_VALUE)
                        cell.font = Font(name="Calibri", size=10, color="721C24", bold=True)
            elif key == "ark_score":
                if val >= 15:
                    cell.fill = _fill(C.GREEN_SOFT)
                    cell.font = Font(name="Calibri", size=10, color="155724", bold=True)
                elif val >= 8:
                    cell.fill = _fill(C.AMBER_SOFT)
                    cell.font = Font(name="Calibri", size=10, color="856404")

    ws.freeze_panes = f"D{hr + 1}"
    ws.auto_filter.ref = f"A{hr}:{get_column_letter(len(COLUMNS))}{current_row - 1}"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    wb.save(output_path)
    return output_path
