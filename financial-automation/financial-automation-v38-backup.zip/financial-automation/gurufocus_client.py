"""
GuruFocus API Client -- v3.8

v3.3 fixes (baked in):
  - _best_estimate() walks backwards through estimate arrays (fixes BMO None issue)
  - Per-field estimate horizons (rev_est_horizon, ebitda_est_horizon, etc.)
  - EPS fallback: eps_nri_estimate -> per_share_eps_estimate
  - EBITDA fallback: ebitda_estimate -> ebit_estimate
  - Pre-computed growth rates as ultimate CAGR fallback
  - Beta validation floor raised to 0.15 (fixes DLMAF 0.04 artifact)

v3.4 additions:
  - Per-field horizons returned in result dict for downstream use
  - Pre-computed growth fields in result dict

v3.8 additions:
  - Third FX fallback API (fawazahmed0 currency-api)
  - FX source tracking — returns (rate, source) tuple
  - FX rate cached for session (fetched once, reused)
"""

import requests, time, json, os, logging, datetime
from typing import Optional, Any
from config.settings import GURUFOCUS_API_KEY, GURUFOCUS_BASE_URL, BANK_TICKERS, OUTPUT_DIR

logger = logging.getLogger(__name__)


class GuruFocusClient:

    def __init__(self, api_key: str = GURUFOCUS_API_KEY):
        self.api_key = api_key
        self.base = f"{GURUFOCUS_BASE_URL}/{api_key}"
        self.session = requests.Session()
        self.session.headers.update({"Accept": "application/json"})
        self._cached_fx = None   # v3.8: cache (rate, source) for the session

    def _get(self, path: str, retries: int = 3) -> Optional[dict]:
        url = f"{self.base}/{path}"
        for attempt in range(retries):
            try:
                resp = self.session.get(url, timeout=30)
                if resp.status_code == 200:
                    return resp.json()
                if resp.status_code == 429:
                    time.sleep(2 ** attempt); continue
                logger.error(f"HTTP {resp.status_code} for {path}: {resp.text[:300]}")
                return None
            except requests.RequestException as e:
                logger.error(f"Request error for {path}: {e}")
                if attempt < retries - 1: time.sleep(1)
        return None

    def get_summary(self, ticker):          return self._get(f"stock/{ticker}/summary")
    def get_keyratios(self, ticker):        return self._get(f"stock/{ticker}/keyratios")
    def get_financials(self, ticker):       return self._get(f"stock/{ticker}/financials")
    def get_analyst_estimate(self, ticker): return self._get(f"stock/{ticker}/analyst_estimate")
    def get_quote(self, ticker):            return self._get(f"stock/{ticker}/quote")

    # -- helpers --
    @staticmethod
    def _to_float(val: Any) -> Optional[float]:
        if val is None or val == "" or val == "N/A" or val == "None":
            return None
        try:
            if isinstance(val, str):
                val = val.replace(",", "").replace("$", "").replace("%", "").strip()
            return float(val)
        except (ValueError, TypeError):
            return None

    @staticmethod
    def _walk(data: Any, *keys) -> Any:
        for k in keys:
            if isinstance(data, dict):
                data = data.get(k)
            elif isinstance(data, list) and isinstance(k, int) and -len(data) <= k < len(data):
                data = data[k]
            else:
                return None
        return data

    def _walk_float(self, data: Any, *keys) -> Optional[float]:
        return self._to_float(self._walk(data, *keys))

    @staticmethod
    def _last_valid(arr: Any) -> Any:
        if not isinstance(arr, list) or len(arr) == 0:
            return None
        for idx in [-2, -1, -3]:
            if abs(idx) <= len(arr):
                val = arr[idx]
                if val is not None and val != "" and val != "0" and val != 0:
                    return val
        return arr[-1]

    @staticmethod
    def _best_estimate(arr):
        """Return (value, effective_horizon) from estimate array, skipping trailing Nones.
        Walks backwards to find last non-None value. Returns (None, 0) if nothing found.
        """
        if not isinstance(arr, list) or len(arr) == 0:
            return None, 0
        for i in range(len(arr) - 1, -1, -1):
            val = arr[i]
            if val is not None and val != "" and val != "None":
                try:
                    return float(str(val).replace(",", "")), i + 1
                except (ValueError, TypeError):
                    continue
        return None, 0

    @staticmethod
    def _deep_find_beta(data, max_depth=6):
        if max_depth <= 0 or data is None:
            return None
        if isinstance(data, dict):
            for key in ["Beta", "beta", "5-Year Beta", "3-Year Beta"]:
                if key in data:
                    val = data[key]
                    if isinstance(val, dict):
                        inner = val.get("value")
                        if inner is not None:
                            try:
                                f = float(str(inner).replace(",", ""))
                                if 0.15 < f < 5.0: return f
                            except (ValueError, TypeError): pass
                    elif val is not None:
                        try:
                            f = float(str(val).replace(",", ""))
                            if 0.15 < f < 5.0: return f
                        except (ValueError, TypeError): pass
            for k, v in data.items():
                if isinstance(v, dict):
                    result = GuruFocusClient._deep_find_beta(v, max_depth - 1)
                    if result is not None: return result
        return None

    @staticmethod
    def _detect_estimate_horizon(est_annual: dict) -> int:
        dates = est_annual.get("date", [])
        if dates: return len(dates)
        for key in ["revenue_estimate", "eps_nri_estimate", "ebitda_estimate",
                     "per_share_eps_estimate", "dividend_estimate"]:
            arr = est_annual.get(key, [])
            if arr and len(arr) > 0: return len(arr)
        return 0

    # =========================================================================
    # v3.8: FX rate with 3 sources + caching + source tracking
    # =========================================================================
    def get_usdcad_rate(self) -> float:
        """Return USD/CAD rate. Caches for the lifetime of this client instance."""
        if self._cached_fx is not None:
            rate, source = self._cached_fx
            logger.info(f"FX: USD/CAD = {rate:.4f} (cached, original source: {source})")
            return rate

        fx_sources = [
            ("exchangerate-api.com",
             "https://api.exchangerate-api.com/v4/latest/USD",
             lambda j: j.get("rates", {}).get("CAD")),
            ("open.er-api.com",
             "https://open.er-api.com/v6/latest/USD",
             lambda j: j.get("rates", {}).get("CAD")),
            ("fawazahmed0/currency-api",
             "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json",
             lambda j: j.get("usd", {}).get("cad")),
        ]

        for source_name, url, extractor in fx_sources:
            try:
                resp = requests.get(url, timeout=10)
                if resp.status_code == 200:
                    rate = extractor(resp.json())
                    if rate:
                        rate = float(rate)
                        self._cached_fx = (rate, source_name)
                        logger.info(f"FX: USD/CAD = {rate:.4f} (source: {source_name})")
                        return rate
                logger.warning(f"FX: {source_name} returned {resp.status_code}")
            except Exception as e:
                logger.warning(f"FX: {source_name} failed — {e}")

        # Hardcoded fallback
        fallback = 1.36
        self._cached_fx = (fallback, "hardcoded fallback")
        logger.warning(f"FX: All sources failed, using hardcoded {fallback}")
        return fallback

    def get_usdcad_source(self) -> str:
        """Return the source name that provided the current FX rate."""
        if self._cached_fx:
            return self._cached_fx[1]
        return "not yet fetched"

    # == MAIN DATA ASSEMBLY ==

    def fetch_ticker_data(self, ticker: str, company_name: str = "") -> dict:
        logger.info(f"Fetching data for {ticker} ({company_name})...")

        summary    = self.get_summary(ticker) or {}
        keyratios  = self.get_keyratios(ticker) or {}
        financials = self.get_financials(ticker) or {}
        estimates  = self.get_analyst_estimate(ticker) or {}
        quote      = self.get_quote(ticker) or {}

        for name, data in [("summary", summary), ("keyratios", keyratios),
                           ("financials", financials), ("estimates", estimates), ("quote", quote)]:
            logger.info(f"  {name}: {len(str(data))} chars" if data else f"  {name}: EMPTY")

        usdcad = self.get_usdcad_rate()

        # -- section shortcuts --
        s_general    = self._walk(summary, "summary", "general") or {}
        s_chart      = self._walk(summary, "summary", "chart") or {}
        s_ratio      = self._walk(summary, "summary", "ratio") or {}
        kr_fund      = self._walk(keyratios, "Fundamental") or {}
        kr_price     = self._walk(keyratios, "Price") or {}
        kr_divs      = self._walk(keyratios, "Dividends") or {}
        fin_annuals  = self._walk(financials, "financials", "annuals") or {}
        fin_pershare = self._walk(fin_annuals, "per_share_data_array") or {}
        fin_income   = self._walk(fin_annuals, "income_statement") or {}
        fin_cashflow = self._walk(fin_annuals, "cashflow_statement") or {}
        est_annual   = self._walk(estimates, "annual") or {}

        # -- estimate horizon (overall) --
        est_horizon = self._detect_estimate_horizon(est_annual)
        est_dates   = est_annual.get("date", [])
        logger.info(f"  Estimates: t+{est_horizon} ({est_dates})")

        # -- price USD --
        price_usd = (self._to_float(quote.get("Price"))
                     or self._to_float(quote.get("Current Price"))
                     or self._to_float(s_general.get("price"))
                     or self._to_float(kr_price.get("Current Price")))
        price_cad = price_usd * usdcad if price_usd else None

        # -- scores & targets --
        gf_score     = self._to_float(s_general.get("gf_score"))
        price_target = self._to_float(s_chart.get("GF Value"))
        mktcap_m     = self._to_float(kr_fund.get("Market Cap ($M)"))
        mktcap_b     = mktcap_m / 1000 if mktcap_m else None
        momentum     = self._to_float(s_general.get("rank_momentum"))

        # -- beta (with validation, floor=0.15 for v3.3+) --
        beta = self._to_float(kr_price.get("Beta"))
        if beta is not None and (beta < 0.15 or beta > 5.0): beta = None
        if beta is None:
            beta = self._to_float(kr_price.get("5-Year Beta"))
            if beta is not None and (beta < 0.15 or beta > 5.0): beta = None
        if beta is None:
            br = self._walk(s_ratio, "Beta")
            if isinstance(br, dict): beta = self._to_float(br.get("value"))
            elif br is not None: beta = self._to_float(br)
            if beta is not None and (beta < 0.15 or beta > 5.0): beta = None
        if beta is None: beta = self._deep_find_beta(keyratios)
        if beta is None: beta = self._deep_find_beta(summary)
        if beta is None:
            logger.warning(f"  Beta not found for {ticker}, defaulting to 1.0")
            beta = 1.0

        # -- altman z (bank fix: catches 0.0) --
        altman_z = self._to_float(kr_fund.get("Altman Z-Score"))
        if altman_z is None:
            az = self._walk(s_ratio, "Altman Z-Score")
            if isinstance(az, dict): altman_z = self._to_float(az.get("value"))
        if ticker.upper() in BANK_TICKERS and (altman_z is None or altman_z == 0 or altman_z == 0.0):
            altman_z = 5.0
            logger.info(f"  Bank ticker {ticker}: Altman Z -> 5.0 (default)")

        # -- piotroski --
        piotroski = self._to_float(kr_fund.get("Piotroski F-Score"))
        if piotroski is None:
            fr = self._walk(s_ratio, "F-Score")
            if isinstance(fr, dict): piotroski = self._to_float(fr.get("value"))

        # -- CFO & FCF --
        cfo_ps = self._to_float(self._last_valid(fin_pershare.get("Operating Cash Flow per Share")))
        fcf_ps = self._to_float(self._last_valid(fin_pershare.get("Free Cash Flow per Share")))
        cfo_total = self._to_float(self._last_valid(
            fin_cashflow.get("Cash Flow from Operations")
            or fin_cashflow.get("Cash Flow from Operating Activities")
            or fin_cashflow.get("Operating Cash Flow")))
        fcf_total = self._to_float(self._last_valid(fin_cashflow.get("Free Cash Flow")))

        def _to_billions(total, ps):
            if total:
                return total / 1e6 if abs(total) > 1e6 else total / 1e3 if abs(total) > 100 else total
            elif ps and mktcap_m and price_usd:
                shares_m = mktcap_m / price_usd
                return ps * shares_m / 1000
            return None

        cfo_b = _to_billions(cfo_total, cfo_ps)
        fcf_b = _to_billions(fcf_total, fcf_ps)

        # -- revenue realized --
        rev_realized = self._to_float(self._last_valid(
            fin_income.get("Revenue") or fin_income.get("Total Revenue")))
        if rev_realized is None:
            rps = self._to_float(self._last_valid(fin_pershare.get("Revenue per Share")))
            if rps and mktcap_m and price_usd:
                rev_realized = rps * (mktcap_m / price_usd)

        # -- ebitda realized (with EBIT fallback) --
        ebitda_realized = self._to_float(self._last_valid(fin_income.get("EBITDA")))
        if ebitda_realized is None:
            eps_ = self._to_float(self._last_valid(fin_pershare.get("EBITDA per Share")))
            if eps_ and mktcap_m and price_usd:
                ebitda_realized = eps_ * (mktcap_m / price_usd)
        if ebitda_realized is None:
            ebitda_realized = self._to_float(self._last_valid(
                fin_income.get("Operating Income") or fin_income.get("EBIT")))

        # -- eps realized --
        eps_realized = self._to_float(self._last_valid(
            fin_pershare.get("EPS without NRI")
            or fin_pershare.get("Earnings per Share (Diluted)")))

        # -- dividends realized --
        div_realized = (self._to_float(self._last_valid(fin_pershare.get("Dividends per Share")))
                        or self._to_float(kr_divs.get("Dividends per Share (TTM)")))

        # ============================================
        # v3.3: SMART ESTIMATES with _best_estimate()
        # ============================================
        # Each field gets its own effective horizon
        rev_estimate, rev_hor = self._best_estimate(est_annual.get("revenue_estimate", []))
        ebitda_estimate, ebitda_hor = self._best_estimate(est_annual.get("ebitda_estimate", []))
        eps_estimate, eps_hor = self._best_estimate(est_annual.get("eps_nri_estimate", []))
        div_estimate, div_hor = self._best_estimate(est_annual.get("dividend_estimate", []))

        # Fallback: eps_nri -> per_share_eps
        if eps_estimate is None:
            eps_estimate, eps_hor = self._best_estimate(est_annual.get("per_share_eps_estimate", []))

        # Fallback: ebitda -> ebit
        if ebitda_estimate is None:
            ebitda_estimate, ebitda_hor = self._best_estimate(est_annual.get("ebit_estimate", []))

        # Pre-computed growth rates from API (ultimate fallback for CAGR)
        kr_growth = self._walk(keyratios, "Growth") or {}
        precomp_rev_growth = self._to_float(kr_growth.get("long_term_revenue_growth_rate_mean"))
        if precomp_rev_growth is not None:
            precomp_rev_growth = precomp_rev_growth / 100 if abs(precomp_rev_growth) > 1 else precomp_rev_growth
        precomp_eps_growth = self._to_float(kr_growth.get("long_term_earnings_growth_rate_mean"))
        if precomp_eps_growth is not None:
            precomp_eps_growth = precomp_eps_growth / 100 if abs(precomp_eps_growth) > 1 else precomp_eps_growth
        precomp_div_growth = self._to_float(kr_divs.get("Dividend Growth Rate (5Y)"))
        if precomp_div_growth is not None:
            precomp_div_growth = precomp_div_growth / 100 if abs(precomp_div_growth) > 1 else precomp_div_growth

        logger.info(f"  Estimates (v3.4 smart): rev={rev_estimate}@t+{rev_hor}, "
                     f"ebitda={ebitda_estimate}@t+{ebitda_hor}, "
                     f"eps={eps_estimate}@t+{eps_hor}, div={div_estimate}@t+{div_hor}")

        result = {
            "company": company_name, "ticker": ticker,
            "price_usd": price_usd, "price_cad": price_cad,
            "gf_score": gf_score, "price_target": price_target,
            "mktcap_b": mktcap_b, "beta": beta, "momentum_rank": momentum,
            "altman_z": altman_z, "piotroski": piotroski,
            "cfo_b": cfo_b, "fcf_b": fcf_b,
            "rev_realized": rev_realized, "ebitda_realized": ebitda_realized,
            "eps_realized": eps_realized, "div_realized": div_realized,
            "rev_estimate": rev_estimate, "ebitda_estimate": ebitda_estimate,
            "eps_estimate": eps_estimate, "div_estimate": div_estimate,
            "est_horizon": est_horizon, "est_dates": est_dates,
            # v3.3 per-field horizons
            "rev_est_horizon": rev_hor, "ebitda_est_horizon": ebitda_hor,
            "eps_est_horizon": eps_hor, "div_est_horizon": div_hor,
            # v3.3 pre-computed growth
            "precomp_rev_growth": precomp_rev_growth,
            "precomp_eps_growth": precomp_eps_growth,
            "precomp_div_growth": precomp_div_growth,
            "usdcad": usdcad,
            "usdcad_source": self.get_usdcad_source(),   # v3.8
            "_summary": summary, "_keyratios": keyratios,
            "_financials": financials, "_estimates": estimates,
        }

        for key in ["price_usd", "gf_score", "price_target", "mktcap_b", "beta",
                     "momentum_rank", "altman_z", "piotroski", "cfo_b", "fcf_b",
                     "rev_realized", "rev_estimate", "ebitda_realized", "ebitda_estimate",
                     "eps_realized", "eps_estimate", "div_realized", "div_estimate",
                     "est_horizon", "rev_est_horizon", "ebitda_est_horizon",
                     "eps_est_horizon", "div_est_horizon"]:
            val = result.get(key)
            status = "+" if val is not None else "x"
            logger.info(f"  {key:25s} = {str(val):>15s}  {status}")

        return result


# -- discovery mode --
def discover_api_fields(ticker: str = "DLMAF"):
    client = GuruFocusClient()
    discovery = {}

    for name, fn in [("summary", client.get_summary), ("keyratios", client.get_keyratios),
                     ("financials", client.get_financials), ("analyst_estimate", client.get_analyst_estimate),
                     ("quote", client.get_quote)]:
        print(f"\n{'='*80}\n  ENDPOINT: {name} -- {ticker}\n{'='*80}")
        data = fn(ticker)
        discovery[name] = data
        if data:
            pretty = json.dumps(data, indent=2, default=str)
            print(pretty[:4000])
            if len(pretty) > 4000: print(f"\n  ... ({len(pretty)-4000} more chars)")
        else:
            print("  *** NO DATA ***")

    out = os.path.join(OUTPUT_DIR, f"api_discovery_{ticker}.json")
    with open(out, "w") as f: json.dump(discovery, f, indent=2, default=str)
    print(f"\nSaved: {out}")

    # beta debug
    print(f"\n{'='*80}\n  BETA DEBUG\n{'='*80}")
    kr_p = client._walk(discovery.get("keyratios", {}), "Price") or {}
    s_r  = client._walk(discovery.get("summary", {}), "summary", "ratio") or {}
    for sect_name, sect in [("keyratios.Price", kr_p), ("summary.ratio", s_r)]:
        if isinstance(sect, dict):
            for k in sorted(sect.keys()):
                if "beta" in k.lower(): print(f"  {sect_name}.{k} = {sect[k]}")

    # estimate debug
    print(f"\n{'='*80}\n  ESTIMATE HORIZON DEBUG\n{'='*80}")
    ea = client._walk(discovery.get("analyst_estimate", {}), "annual") or {}
    print(f"  Dates: {ea.get('date', [])} (n={len(ea.get('date', []))})")
    for ek in ["revenue_estimate", "ebitda_estimate", "eps_nri_estimate",
                "per_share_eps_estimate", "ebit_estimate", "dividend_estimate"]:
        arr = ea.get(ek, [])
        print(f"  {ek}: {arr} (n={len(arr)})")

    # extraction test
    print(f"\n{'='*80}\n  EXTRACTION TEST\n{'='*80}")
    td = client.fetch_ticker_data(ticker, "TEST")
    for key in ["price_usd", "price_cad", "gf_score", "price_target", "mktcap_b",
                "beta", "momentum_rank", "altman_z", "piotroski", "cfo_b", "fcf_b",
                "rev_realized", "rev_estimate", "ebitda_realized", "ebitda_estimate",
                "eps_realized", "eps_estimate", "div_realized", "div_estimate",
                "est_horizon", "rev_est_horizon", "ebitda_est_horizon",
                "eps_est_horizon", "div_est_horizon"]:
        val = td.get(key)
        status = "+" if val is not None else "x MISSING"
        print(f"  {key:25s} = {str(val):>15s}  {status}")


if __name__ == "__main__":
    import sys
    discover_api_fields(sys.argv[1] if len(sys.argv) > 1 else "DLMAF")
