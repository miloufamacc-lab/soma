"""
API Response Cache — v3.6
4-hour TTL file-based cache to avoid redundant GuruFocus API calls.
"""
import os, json, time, hashlib, logging

logger = logging.getLogger(__name__)

CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".api_cache")
CACHE_TTL = 4 * 3600

def _cache_path(key):
    h = hashlib.md5(key.encode()).hexdigest()
    return os.path.join(CACHE_DIR, f"{h}.json")

def get_cached(endpoint, ticker):
    os.makedirs(CACHE_DIR, exist_ok=True)
    key = f"{endpoint}:{ticker}"
    path = _cache_path(key)
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r") as f:
            entry = json.load(f)
        if time.time() - entry.get("ts", 0) > CACHE_TTL:
            os.remove(path)
            return None
        logger.debug(f"  CACHE HIT: {endpoint} for {ticker}")
        return entry.get("data")
    except Exception:
        return None

def set_cached(endpoint, ticker, data):
    os.makedirs(CACHE_DIR, exist_ok=True)
    key = f"{endpoint}:{ticker}"
    path = _cache_path(key)
    try:
        with open(path, "w") as f:
            json.dump({"ts": time.time(), "data": data}, f)
    except Exception:
        pass

def clear_cache():
    if os.path.exists(CACHE_DIR):
        for fn in os.listdir(CACHE_DIR):
            try:
                os.remove(os.path.join(CACHE_DIR, fn))
            except Exception:
                pass
    logger.info("API cache cleared.")

def cache_stats():
    if not os.path.exists(CACHE_DIR):
        return (0, 0, 0)
    files = os.listdir(CACHE_DIR)
    total_bytes = sum(os.path.getsize(os.path.join(CACHE_DIR, f)) for f in files)
    oldest = 0
    for fn in files:
        try:
            with open(os.path.join(CACHE_DIR, fn)) as f:
                entry = json.load(f)
            age = (time.time() - entry.get("ts", time.time())) / 3600
            oldest = max(oldest, age)
        except Exception:
            pass
    return (len(files), total_bytes, oldest)
