"""
Profile Summary Tab -- v3.4

Adds a single "Profile Summary" sheet to the workbook with one row per ticker,
giving a scannable cheat-sheet view of all companies alongside key quant data.

This is ADDITIVE -- existing 1P_TICKER and Val_TICKER tabs remain untouched.
"""

from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import datetime


class C:
    WHITE = "FFFFFF"; TEXT = "2D3436"; TEXT_LIGHT = "636E72"
    HEADER_BG = "1B2838"; SECTION_QUAL = "2D4A5E"; SECTION_VAL = "4A2D5A"
    SECTION_QUANT = "3D5A3E"; GREEN_SOFT = "D4EDDA"; RED_SOFT = "F8D7DA"
    AMBER_SOFT = "FFF3CD"; ROW_EVEN = "F8F9FA"; ROW_ODD = "FFFFFF"
    BORDER_LIGHT = "DEE2E6"


thin_border = Border(
    left=Side(style="thin", color=C.BORDER_LIGHT),
    right=Side(style="thin", color=C.BORDER_LIGHT),
    top=Side(style="thin", color=C.BORDER_LIGHT),
    bottom=Side(style="thin", color=C.BORDER_LIGHT))
header_font = Font(name="Calibri", bold=True, size=9, color=C.WHITE)
data_font = Font(name="Calibri", size=9, color=C.TEXT)

def _fill(c): return PatternFill(start_color=c, end_color=c, fill_type="solid")


# Column definitions: (Header, key, width, format, section_color)
SUMMARY_COLS = [
    ("Ticker",              "ticker",               8,   None,       C.HEADER_BG),
    ("Company",             "company",              20,   None,       C.HEADER_BG),
    ("Sector",              "sector",               18,   None,       C.HEADER_BG),
    ("Price USD",           "price_usd",            10,  '$#,##0.00', C.SECTION_QUANT),
    ("Verdict",             "dcf_verdict",          11,   None,       C.SECTION_VAL),
    ("DCF FV",              "dcf_fair_value",       10,  '$#,##0.00', C.SECTION_VAL),
    ("DCF Upside",          "dcf_upside",            9,  '0.0%',      C.SECTION_VAL),
    ("GF Score",            "gf_score",              8,  '0',         C.SECTION_QUANT),
    ("Beta",                "beta",                  7,  '0.00',      C.SECTION_QUANT),
    ("Business Description","description",          45,   None,       C.SECTION_QUAL),
    ("Competitive Advantage","competitive_advantage",40,  None,       C.SECTION_QUAL),
    ("Critical Factor #1",  "cf_1",                 35,   None,       C.SECTION_QUAL),
    ("Critical Factor #2",  "cf_2",                 35,   None,       C.SECTION_QUAL),
    ("Key Risk #1",         "risk_1",               35,   None,       C.SECTION_QUAL),
    ("Key Risk #2",         "risk_2",               35,   None,       C.SECTION_QUAL),
    ("Valuation Method",    "valuation_method",     22,   None,       C.SECTION_QUAL),
    ("Peer Group",          "peer_group_str",       18,   None,       C.SECTION_QUAL),
]


def add_profile_summary_sheet(wb, ticker_data_list, profiles_map):
    """
    Add a 'Profile Summary' tab to the workbook.

    Args:
        wb: openpyxl Workbook (already has Ranking, Val_*, 1P_* tabs)
        ticker_data_list: list of ticker_data dicts from API
        profiles_map: dict of {ticker: profile_dict} from company_profiles
    """
    ws = wb.create_sheet(title="Profile Summary", index=1)  # right after Ranking tab

    # ---- Title row ----
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(SUMMARY_COLS))
    tc = ws.cell(row=1, column=1)
    tc.value = f"Company Profile Summary -- {datetime.date.today().strftime('%B %d, %Y')}"
    tc.font = Font(name="Calibri", bold=True, size=12, color=C.WHITE)
    tc.fill = _fill(C.HEADER_BG)
    tc.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    # ---- Header row ----
    hr = 2
    for ci, (hdr, key, w, fmt, sec) in enumerate(SUMMARY_COLS, 1):
        cell = ws.cell(row=hr, column=ci, value=hdr)
        cell.font = header_font
        cell.fill = _fill(sec)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.row_dimensions[hr].height = 32

    # ---- Data rows ----
    ds = hr + 1
    for ri, td in enumerate(ticker_data_list):
        row = ds + ri
        row_fill = _fill(C.ROW_EVEN if ri % 2 == 0 else C.ROW_ODD)
        ticker = td.get("ticker", "")
        profile = profiles_map.get(ticker, {})

        # Build enriched row data
        cfs = profile.get("critical_factors", [])
        risks = profile.get("key_risks", [])
        peers = profile.get("peer_group", [])

        # DCF upside calc
        dcf_fv = td.get("dcf_fair_value")
        pu = td.get("price_usd")
        dcf_up = (dcf_fv / pu - 1) if dcf_fv and pu and pu > 0 else None

        row_data = {
            "ticker": ticker,
            "company": td.get("company", ""),
            "sector": td.get("sector", ""),
            "price_usd": pu,
            "dcf_verdict": td.get("dcf_verdict", ""),
            "dcf_fair_value": dcf_fv,
            "dcf_upside": dcf_up,
            "gf_score": td.get("gf_score"),
            "beta": td.get("beta"),
            "description": profile.get("description", ""),
            "competitive_advantage": profile.get("competitive_advantage", ""),
            "cf_1": cfs[0] if len(cfs) > 0 else "",
            "cf_2": cfs[1] if len(cfs) > 1 else "",
            "risk_1": risks[0] if len(risks) > 0 else "",
            "risk_2": risks[1] if len(risks) > 1 else "",
            "valuation_method": profile.get("valuation_method", ""),
            "peer_group_str": ", ".join(peers) if peers else "",
        }

        for ci, (hdr, key, w, fmt, sec) in enumerate(SUMMARY_COLS, 1):
            cell = ws.cell(row=row, column=ci)
            val = row_data.get(key)
            cell.value = val
            cell.font = data_font
            cell.fill = row_fill
            cell.border = thin_border
            if fmt:
                cell.number_format = fmt

            # Text wrapping for long fields
            if key in ("description", "competitive_advantage", "cf_1", "cf_2",
                       "risk_1", "risk_2", "valuation_method"):
                cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
            elif key in ("ticker", "company", "sector", "dcf_verdict", "peer_group_str"):
                cell.alignment = Alignment(horizontal="left", vertical="center")
            else:
                cell.alignment = Alignment(horizontal="right", vertical="center")

            if val is None:
                continue

            # Conditional formatting
            if key == "dcf_verdict" and isinstance(val, str):
                if "Under" in val:
                    cell.fill = _fill(C.GREEN_SOFT)
                    cell.font = Font(name="Calibri", size=9, color="155724", bold=True)
                elif "Over" in val:
                    cell.fill = _fill(C.RED_SOFT)
                    cell.font = Font(name="Calibri", size=9, color="721C24", bold=True)
                elif "Fairly" in val:
                    cell.fill = _fill(C.AMBER_SOFT)
                    cell.font = Font(name="Calibri", size=9, color="856404")
            elif key == "dcf_upside" and isinstance(val, (int, float)):
                if val > 0.15:
                    cell.fill = _fill(C.GREEN_SOFT)
                    cell.font = Font(name="Calibri", size=9, color="155724", bold=True)
                elif val < -0.10:
                    cell.fill = _fill(C.RED_SOFT)
                    cell.font = Font(name="Calibri", size=9, color="721C24", bold=True)

        # Set row height for readability (text wrap rows)
        ws.row_dimensions[row].height = 48

    # Freeze panes
    ws.freeze_panes = f"C{ds}"
    ws.auto_filter.ref = f"A{hr}:{get_column_letter(len(SUMMARY_COLS))}{ds + len(ticker_data_list) - 1}"

