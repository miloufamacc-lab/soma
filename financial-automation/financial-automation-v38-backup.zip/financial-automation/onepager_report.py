"""
One-Pager Combined Report -- v3.4

Generates a single standalone HTML file containing all company one-pagers
with a clickable table of contents at the top.

This is ADDITIVE -- individual onepager_TICKER.html files and 1P_TICKER tabs
in the Excel continue to be generated as before.

100% self-contained: inline CSS, no external resources, no JavaScript.
Opens in any browser, works fully offline behind VPN.
"""

import datetime
from onepager_renderer import render_onepager_html


def render_combined_onepager_report(ticker_data_list, valuation_analyses, profiles_map):
    """
    Generate a single HTML file with all one-pagers and a table of contents.

    Args:
        ticker_data_list: list of ticker_data dicts
        valuation_analyses: dict of {ticker: analysis_dict}
        profiles_map: dict of {ticker: profile_dict}

    Returns:
        str: Complete HTML document
    """
    today = datetime.date.today().strftime("%B %d, %Y")
    n_tickers = len(ticker_data_list)

    # ---- Build TOC and one-pager sections ----
    toc_rows = ""
    onepager_sections = ""

    for i, td in enumerate(ticker_data_list):
        ticker = td.get("ticker", "")
        company = td.get("company", "")
        sector = td.get("sector", "")
        analysis = valuation_analyses.get(ticker, {})
        profile = profiles_map.get(ticker, {})

        verdict = analysis.get("verdict", {}).get("rating", "")
        dcf_ip = analysis.get("dcf", {}).get("implied_price")
        price = td.get("price_usd")
        dcf_up = (dcf_ip / price - 1) if dcf_ip and price and price > 0 else None

        # Verdict color for TOC
        if "Under" in verdict:
            v_color = "#155724"; v_bg = "#D4EDDA"
        elif "Over" in verdict:
            v_color = "#721C24"; v_bg = "#F8D7DA"
        else:
            v_color = "#856404"; v_bg = "#FFF3CD"

        dcf_str = f"${dcf_ip:.2f}" if dcf_ip else "--"
        up_str = f"{dcf_up:+.1%}" if dcf_up is not None else "--"

        # TOC row
        toc_rows += f"""<tr style="background:{'#F8F9FA' if i % 2 == 0 else '#FFFFFF'};">
          <td style="padding:5px 10px;"><a href="#op_{ticker}" style="color:#2D4A5E;text-decoration:none;font-weight:600;">{ticker}</a></td>
          <td style="padding:5px 10px;">{company}</td>
          <td style="padding:5px 10px;color:#636E72;font-size:12px;">{sector}</td>
          <td style="padding:5px 10px;text-align:right;">{'N/A' if price is None else f'{price:.2f}'}</td>
          <td style="padding:5px 10px;text-align:right;">{dcf_str}</td>
          <td style="padding:5px 10px;text-align:right;">{up_str}</td>
          <td style="padding:5px 10px;text-align:center;">
            <span style="background:{v_bg};color:{v_color};padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;">{verdict}</span>
          </td>
        </tr>"""

        # One-pager section (extract the inner body from the individual renderer)
        # We re-render each one-pager but strip the outer HTML/body tags
        # and wrap in a div with an anchor
        individual_html = render_onepager_html(td, analysis, profile)

        # Extract just the content div (between <body...> and </body>)
        body_start = individual_html.find("<body")
        body_inner_start = individual_html.find(">", body_start) + 1
        body_end = individual_html.find("</body>")
        inner_content = individual_html[body_inner_start:body_end] if body_start >= 0 and body_end >= 0 else individual_html

        onepager_sections += f"""
        <div id="op_{ticker}" style="margin:24px 0;page-break-before:always;">
          <div style="text-align:right;margin-bottom:4px;">
            <a href="#toc" style="color:#636E72;font-size:11px;text-decoration:none;">&#9650; Back to Table of Contents</a>
          </div>
          {inner_content}
        </div>
        """

    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Company One-Pager Report -- {today}</title>
<style>
  body {{ margin:0; padding:20px; font-family:Calibri,'Segoe UI',Arial,sans-serif; background:#F0F2F5; }}
  a {{ color:#2D4A5E; }}
  @media print {{
    body {{ background:#FFF; padding:0; }}
    .no-print {{ display:none; }}
  }}
</style>
</head>
<body>

<!-- REPORT HEADER -->
<div style="max-width:900px;margin:0 auto 24px;background:#1B2838;border-radius:8px;padding:20px 24px;color:#FFF;">
  <h1 style="margin:0;font-size:22px;">Company One-Pager Report</h1>
  <p style="margin:6px 0 0;color:#ADB5BD;font-size:13px;">{today} &bull; {n_tickers} companies &bull; Source: GuruFocus API + Company Profiles</p>
</div>

<!-- TABLE OF CONTENTS -->
<div id="toc" style="max-width:900px;margin:0 auto 24px;background:#FFF;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
  <div style="background:#2D4A5E;padding:12px 24px;">
    <h2 style="margin:0;color:#FFF;font-size:16px;">Table of Contents</h2>
  </div>
  <div style="overflow-x:auto;">
    <table style="width:100%;border-collapse:collapse;font-size:13px;color:#2D3436;">
      <thead><tr style="background:#F8F9FA;">
        <th style="padding:8px 10px;text-align:left;color:#636E72;font-size:11px;">Ticker</th>
        <th style="padding:8px 10px;text-align:left;color:#636E72;font-size:11px;">Company</th>
        <th style="padding:8px 10px;text-align:left;color:#636E72;font-size:11px;">Sector</th>
        <th style="padding:8px 10px;text-align:right;color:#636E72;font-size:11px;">Price</th>
        <th style="padding:8px 10px;text-align:right;color:#636E72;font-size:11px;">DCF FV</th>
        <th style="padding:8px 10px;text-align:right;color:#636E72;font-size:11px;">Upside</th>
        <th style="padding:8px 10px;text-align:center;color:#636E72;font-size:11px;">Verdict</th>
      </tr></thead>
      <tbody>{toc_rows}</tbody>
    </table>
  </div>
</div>

<!-- ONE-PAGER SECTIONS -->
<div style="max-width:900px;margin:0 auto;">
  {onepager_sections}
</div>

<!-- FOOTER -->
<div style="max-width:900px;margin:24px auto 0;text-align:center;">
  <p style="font-size:11px;color:#636E72;">
    Generated {today} &bull; Sources: GuruFocus API, analyst consensus, company filings &bull; Not investment advice
  </p>
</div>

</body>
</html>"""

