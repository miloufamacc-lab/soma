"""
Main Orchestrator -- v3.8

v3.4 KEY CHANGE:
  Valuation runs BEFORE building the ranking sheet and emails.

v3.8 KEY CHANGES:
  - Strategy section: 30 tickers (TSLA, MSTR, NVDA, ... + 3 commodity ETFs)
  - Deduped fetching: overlapping tickers fetched once, data reused
  - GOOGL -> GOOG API remapping
  - ETF graceful degradation (skip valuation for IAU, ICOP, XLE)
  - FX rate logging with source tracking

Usage:
    python main.py                  # Daily ranking + valuation + email
    python main.py --valuation SU   # Valuation for one ticker only
    python main.py --discover DLMAF # Debug: raw API for ticker
    python main.py --dry-run        # Build files, don't email
    python main.py --mandate myfile # Use specific mandate
    python main.py --force          # Run even if market closed
    python main.py --quiet          # Suppress per-ticker logging
"""

import argparse, datetime, logging, sys, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.settings import (PORTFOLIO, OUTPUT_DIR,
                              STRATEGY_TICKERS, STRATEGY_API_MAP,
                              STRATEGY_TICKER_SET, STRATEGY_ETF_TICKERS,
                              STRATEGY_OVERLAP)
from gurufocus_client import GuruFocusClient, discover_api_fields
from excel_generator import build_ranking_sheet
from html_renderer import render_html_email, render_bloomberg_html_email
from email_sender import send_daily_email, send_valuation_email
from valuation_engine import ValuationModel, render_valuation_html, add_valuation_sheet
from onepager_renderer import render_onepager_html, add_onepager_sheet
from onepager_report import render_combined_onepager_report
from profile_summary import add_profile_summary_sheet
from config.company_profiles import get_profile

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S")
logger = logging.getLogger(__name__)


def is_market_open_today():
    today = datetime.date.today()
    if today.weekday() >= 5: return False
    yr = today.year
    holidays = [datetime.date(yr,1,1), datetime.date(yr,7,4), datetime.date(yr,12,25),
                datetime.date(yr,6,19)]
    return today not in holidays


def load_mandate(name=None):
    if name:
        p = os.path.join(os.path.dirname(__file__), "config", "mandates", f"{name}.py")
        if os.path.exists(p):
            import importlib.util
            spec = importlib.util.spec_from_file_location("mandate", p)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod.PORTFOLIO
        else:
            logger.error(f"Mandate not found: {p}"); sys.exit(1)
    return PORTFOLIO


def run_daily_ranking(portfolio, dry_run=False, run_valuation="all"):
    client = GuruFocusClient()

    # ---- STEP 0: Build combined fetch list (portfolio + strategy, deduped) ----
    # Map display_ticker -> api_ticker for fetching
    fetch_list = []          # (company, display_ticker, api_ticker, adp, sector, risk, is_strategy_only)
    seen_api_tickers = set()

    # Portfolio tickers first (always fetched)
    for company, ticker, adp, sector, risk in portfolio:
        api_ticker = ticker
        seen_api_tickers.add(api_ticker.upper())
        fetch_list.append((company, ticker, api_ticker, adp, sector, risk, False))

    # Strategy tickers: skip if already in portfolio, remap GOOGL->GOOG
    for company, ticker, adp, sector, risk in STRATEGY_TICKERS:
        api_ticker = STRATEGY_API_MAP.get(ticker, ticker)
        key = api_ticker.upper()
        if key in seen_api_tickers:
            logger.info(f"  Strategy: {ticker} -> reusing {key} from portfolio")
            continue
        seen_api_tickers.add(key)
        fetch_list.append((company, ticker, api_ticker, adp, sector, risk, True))

    logger.info(f"Fetching {len(fetch_list)} unique tickers "
                f"({len(portfolio)} portfolio + {len(fetch_list) - len(portfolio)} strategy-only)")

    # ---- STEP 1: Fetch all ticker data from API ----
    ticker_data_list = []
    ticker_data_map = {}  # api_ticker -> td dict (for overlap reuse)

    for company, display_ticker, api_ticker, adp, sector, risk, _strat_only in fetch_list:
        is_etf = display_ticker in STRATEGY_ETF_TICKERS

        try:
            td = client.fetch_ticker_data(api_ticker, company)
        except Exception as e:
            logger.error(f"  Failed to fetch {api_ticker}: {e}")
            td = {"company": company, "ticker": display_ticker, "price_usd": None}

        td["adp"] = adp
        td["sector"] = sector
        td["rbc_risk"] = risk
        td["_display_ticker"] = display_ticker  # v3.8: what to show in output
        td["_api_ticker"] = api_ticker
        td["_is_etf"] = is_etf
        td["_is_strategy"] = display_ticker in STRATEGY_TICKER_SET

        # Store the actual ticker as the display ticker (GOOGL not GOOG in output)
        td["ticker"] = display_ticker

        ticker_data_list.append(td)
        ticker_data_map[api_ticker.upper()] = td

    if not ticker_data_list:
        logger.error("No data fetched -- aborting."); return

    # ---- STEP 2: Run valuation (skip ETFs) ----
    valuation_analyses = {}
    if run_valuation:
        if run_valuation == "all":
            tickers_to_value = [td["_api_ticker"] for td in ticker_data_list
                                if not td.get("_is_etf")]
        else:
            tickers_to_value = [run_valuation]

        for t in tickers_to_value:
            match = next((td for td in ticker_data_list if td["_api_ticker"] == t), None)
            if match:
                vm = ValuationModel(match)
                analysis = vm.run_full_analysis()
                valuation_analyses[t] = analysis

                # Inject DCF results
                ip = analysis["dcf"].get("implied_price")
                vr = analysis["verdict"]["rating"]
                match["dcf_fair_value"] = ip
                match["dcf_verdict"] = vr

                n = match.get("est_horizon", "?")
                ip_str = f"${ip:.2f}" if ip else "N/A"
                vm_label = analysis.get("valuation_method", "FCF DCF")
                logger.info(f"  Valuation: {t} -> {vr}, {vm_label}={ip_str}, horizon=t+{n}")

        # ETFs get "ETF" verdict, no DCF
        for td in ticker_data_list:
            if td.get("_is_etf"):
                td["dcf_fair_value"] = None
                td["dcf_verdict"] = "ETF"
                logger.info(f"  ETF: {td['ticker']} -> skipped valuation")

    # ---- STEP 2b: Build overlap data (duplicate rows for Strategy + CDN/US) ----
    # For tickers in STRATEGY_OVERLAP, we need to create a copy for the Strategy section
    # The original stays in CDN/US, the copy goes to Strategy
    import copy
    strategy_overlay = []
    for overlap_ticker in STRATEGY_OVERLAP:
        # Find the matching display ticker in STRATEGY_TICKERS
        strategy_display = None
        for _, st, _, _, _ in STRATEGY_TICKERS:
            api_t = STRATEGY_API_MAP.get(st, st)
            if api_t.upper() == overlap_ticker.upper() or st.upper() == overlap_ticker.upper():
                strategy_display = st
                break

        if strategy_display:
            # Find the fetched data (by API ticker)
            api_t = STRATEGY_API_MAP.get(overlap_ticker, overlap_ticker)
            source_td = ticker_data_map.get(api_t.upper())
            if not source_td:
                source_td = ticker_data_map.get(overlap_ticker.upper())
            if source_td:
                overlay = copy.deepcopy(source_td)
                overlay["ticker"] = strategy_display  # Use Strategy display name
                overlay["_display_ticker"] = strategy_display
                overlay["_is_strategy"] = True
                overlay["_is_overlay"] = True  # mark as overlay copy
                strategy_overlay.append(overlay)

    # Combine: original list + overlay copies
    combined_list = ticker_data_list + strategy_overlay

    # ---- STEP 3: Build ranking Excel ----
    today_str = datetime.date.today().strftime("%Y-%m-%d")
    xlsx_path = os.path.join(OUTPUT_DIR, f"ranking_{today_str}.xlsx")
    xlsx_path = build_ranking_sheet(combined_list, xlsx_path)
    logger.info(f"Excel (ranking with Strategy + DCF): {xlsx_path}")

    # ---- STEP 4: Add per-ticker valuation detail sheets + one-pagers ----
    if valuation_analyses:
        from openpyxl import load_workbook
        wb = load_workbook(xlsx_path)
        for t, analysis in valuation_analyses.items():
            add_valuation_sheet(wb, analysis)

            match = next((td for td in ticker_data_list if td["_api_ticker"] == t), None)
            if match:
                profile = get_profile(t)
                add_onepager_sheet(wb, match, analysis, profile)

                onepager_html = render_onepager_html(match, analysis, profile)
                op_path = os.path.join(OUTPUT_DIR, f"onepager_{t}_{today_str}.html")
                with open(op_path, "w") as f: f.write(onepager_html)
                logger.info(f"  One-pager: {t} -> {op_path}")

            if run_valuation != "all" and not dry_run:
                send_valuation_email(render_valuation_html(analysis), t, xlsx_path)

        profiles_map = {td.get("_api_ticker", ""): get_profile(td.get("_api_ticker", ""))
                        for td in ticker_data_list}
        add_profile_summary_sheet(wb, ticker_data_list, profiles_map)
        logger.info("Excel: Profile Summary tab added")

        wb.save(xlsx_path)
        logger.info(f"Excel (with valuation + one-pager + summary sheets): {xlsx_path}")

        report_html = render_combined_onepager_report(
            ticker_data_list, valuation_analyses, profiles_map)
        report_path = os.path.join(OUTPUT_DIR, f"onepager_report_{today_str}.html")
        with open(report_path, "w") as f:
            f.write(report_html)
        logger.info(f"Combined one-pager report: {report_path}")

    # ---- STEP 5: Generate both email themes ----
    usdcad = ticker_data_list[0].get("usdcad", 1.36) if ticker_data_list else 1.36
    html_standard = render_html_email(combined_list, usdcad)
    html_bloomberg = render_bloomberg_html_email(combined_list, usdcad)

    for suffix, content in [("standard", html_standard), ("bloomberg", html_bloomberg)]:
        preview_path = os.path.join(OUTPUT_DIR, f"email_preview_{suffix}_{today_str}.html")
        with open(preview_path, "w") as f: f.write(content)
        logger.info(f"HTML preview ({suffix}): {preview_path}")

    # ---- STEP 6: Send or skip ----
    if dry_run:
        logger.info("DRY RUN -- no email sent. Check output/ folder.")
    else:
        if send_daily_email(html_standard, xlsx_path, bloomberg_html=html_bloomberg):
            logger.info("Daily email sent to all recipients!")
        else:
            logger.error("Email send failed.")


def main():
    parser = argparse.ArgumentParser(description="Financial Data Automation v3.8")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--valuation", type=str, default="all",
                        help="'all' (default), specific ticker, or 'none' to skip")
    parser.add_argument("--discover", type=str, default=None)
    parser.add_argument("--mandate", type=str, default=None)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    if args.quiet:
        logging.getLogger().setLevel(logging.WARNING)

    if args.discover:
        discover_api_fields(args.discover); return

    if not args.force and not is_market_open_today():
        logger.info("Market closed. Use --force to override."); return

    portfolio = load_mandate(args.mandate)
    logger.info(f"Running for {len(portfolio)} portfolio + {len(STRATEGY_TICKERS)} strategy tickers (valuation: {args.valuation})")

    val = args.valuation if args.valuation != "none" else None
    run_daily_ranking(portfolio, dry_run=args.dry_run, run_valuation=val)


if __name__ == "__main__":
    main()
