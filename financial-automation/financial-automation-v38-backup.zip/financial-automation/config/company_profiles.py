"""
Company Profiles -- qualitative data layer for one-pagers.

Update this quarterly or when company strategy changes materially.
Each profile feeds into the one-pager renderer alongside live API data.

Structure per ticker follows ADViCE™ / TIER™ / EPIC™ frameworks:
  - description:           2-3 sentence business overview
  - business_lines:        list of (segment_name, revenue_pct, brief_description)
  - mission:               stated corporate mission or strategic vision
  - competitive_advantage: what gives this company its moat
  - peer_group:            list of comparable tickers for context
  - critical_factors:      EPIC™-filtered: the 1-3 factors most likely to move the stock
  - key_risks:             top 2-3 risks to the bull thesis (the "Where We Could Be Wrong")
  - valuation_method:      optimal primary valuation per the flowchart (DCF, P/B, EV/EBITDA, PEG, etc.)
  - catalysts:             near-term events or triggers with expected timing
"""

COMPANY_PROFILES = {

    "DLMAF": {
        "description": (
            "Dollarama is Canada's largest dollar store operator with 1,500+ locations nationwide, "
            "offering a broad assortment of consumer products at fixed price points ($0.50-$5.00). "
            "Also expanding internationally through its 60.1% stake in Dollarcity (Latin America)."
        ),
        "business_lines": [
            ("Canadian Retail", 85, "1,500+ stores across all 10 provinces, fixed price point model"),
            ("Dollarcity (LatAm)", 15, "60.1% ownership; 600+ stores in Colombia, El Salvador, Guatemala, Peru"),
        ],
        "mission": (
            "To offer Canadians a compelling value proposition through a broad assortment of everyday "
            "consumer products at low fixed price points in convenient locations."
        ),
        "competitive_advantage": (
            "Unmatched scale in Canadian value retail with direct overseas sourcing, high store density "
            "creating a logistics moat, and a proven playbook exportable to Latin America via Dollarcity. "
            "Pricing power through controlled price point expansion ($1 to $5 over 15 years)."
        ),
        "peer_group": ["DG", "DLTR", "FIVE"],
        "critical_factors": [
            "Same-store sales growth trajectory as price points expand",
            "Dollarcity international expansion pace and profitability ramp",
            "Consumer trade-down dynamics in a softening Canadian economy",
        ],
        "key_risks": [
            "Consumer spending shift: if economy strengthens, trade-down traffic could reverse",
            "Dollarcity execution risk in new LatAm markets",
            "Import cost pressure from CAD weakness or tariff changes",
        ],
        "valuation_method": "DCF + EV/EBITDA (capital-light, stable cash flows)",
        "catalysts": [
            ("Q4 earnings release", "Mar 2026"),
            ("Dollarcity store count update", "Quarterly"),
            ("Same-store sales trajectory", "Monthly/Quarterly"),
        ],
    },

    "ANCTF": {
        "description": (
            "Alimentation Couche-Tard is one of the world's largest convenience store and fuel retail "
            "operators with ~16,700 stores across North America, Europe, and Asia. Known for disciplined "
            "M&A and operational excellence in integrating acquired networks."
        ),
        "business_lines": [
            ("Convenience (Merchandise)", 35, "High-margin in-store sales: food, beverages, tobacco, general merchandise"),
            ("Fuel Retail", 60, "Motor fuel across 14,000+ forecourts; margin driven by spread not price"),
            ("Other / EV Charging", 5, "Emerging EV infrastructure, car wash, fleet fueling"),
        ],
        "mission": (
            "To become the world's preferred destination for convenience and mobility, driven by "
            "operational excellence, strategic M&A, and a relentless focus on the customer."
        ),
        "competitive_advantage": (
            "Best-in-class M&A integration engine — 30+ years of acquiring and improving c-store networks. "
            "Global scale provides procurement leverage. Strong free cash flow generation funds serial acquisitions. "
            "Decentralized ops model keeps execution tight at the store level."
        ),
        "peer_group": ["CASY", "MUSA", "7-Eleven"],
        "critical_factors": [
            "M&A pipeline and integration execution (especially post-Seven & i bid)",
            "Same-store merchandise revenue growth (margin driver)",
            "Fuel margin sustainability as EV adoption accelerates",
        ],
        "key_risks": [
            "Large acquisition miss: overpaying or integration failure (Seven & i scale risk)",
            "Accelerating EV adoption eroding fuel volumes faster than forecast",
            "Regulatory risk in European fuel markets",
        ],
        "valuation_method": "DCF + EV/EBITDA (consistent FCF, acquisition-driven growth)",
        "catalysts": [
            ("Seven & i acquisition outcome", "2025-2026"),
            ("Quarterly earnings + same-store sales", "Quarterly"),
            ("New market entries or bolt-on acquisitions", "Ongoing"),
        ],
    },

    "LBLCF": {
        "description": (
            "Loblaw Companies is Canada's largest food and pharmacy retailer, operating ~2,500 stores under "
            "banners including Loblaws, No Frills, Shoppers Drug Mart, and T&T Supermarket. Also controls "
            "PC Financial services and the PC Optimum loyalty program (20M+ members)."
        ),
        "business_lines": [
            ("Food Retail", 55, "Full-service and discount grocery: Loblaws, No Frills, Provigo, Maxi, T&T"),
            ("Drug Retail / Pharmacy", 35, "Shoppers Drug Mart: pharmacy, beauty, convenience; 1,900+ locations"),
            ("Financial Services / Other", 10, "PC Financial, PC Optimum, Joe Fresh, real estate (Choice REIT)"),
        ],
        "mission": (
            "To help Canadians Live Life Well by providing the best in food, health, and beauty, "
            "delivered through innovative retail and digital experiences."
        ),
        "competitive_advantage": (
            "Dominant grocery + pharmacy integrated model unique in Canada. PC Optimum loyalty platform "
            "drives cross-banner traffic and data insights. Discount banner (No Frills) captures trade-down. "
            "Shoppers Drug Mart provides pharmacy margin stability and beauty/cosmetics growth."
        ),
        "peer_group": ["MRU.TO", "EMP.A.TO", "WMT", "COST"],
        "critical_factors": [
            "Food inflation pass-through and same-store sales growth",
            "Shoppers Drug Mart pharmacy reform impact (drug pricing regulations)",
            "E-commerce and PC Express adoption rates",
        ],
        "key_risks": [
            "Government action on grocery pricing or pharmacy drug reform",
            "Intensifying competition from Walmart and Amazon grocery",
            "Consumer pushback on food inflation perception (political/reputational risk)",
        ],
        "valuation_method": "DCF + P/E (stable earnings, defensive consumer staple)",
        "catalysts": [
            ("Quarterly earnings", "Quarterly"),
            ("Pharmacy reform policy updates", "Ongoing"),
            ("PC Optimum / e-commerce metrics", "Quarterly"),
        ],
    },

    "PBA": {
        "description": (
            "Pembina Pipeline is a leading North American energy infrastructure company operating an integrated "
            "system of pipelines, gas processing, and NGL fractionation facilities. ~90% of revenue is "
            "fee-based or take-or-pay, providing cash flow visibility."
        ),
        "business_lines": [
            ("Pipelines", 50, "Conventional and oil sands pipelines across Western Canada; 18,000+ km network"),
            ("Facilities", 35, "Gas processing plants, NGL fractionation, storage; Empress/Cochin facilities"),
            ("Marketing & New Ventures", 15, "NGL marketing, midstream optimization, LNG/PDH growth projects"),
        ],
        "mission": (
            "To be the pipeline company of choice for customers, investors, employees, and communities "
            "by providing safe, reliable, and cost-effective transportation and midstream services."
        ),
        "competitive_advantage": (
            "Integrated pipeline + processing model creates captive volumes. Long-term take-or-pay contracts "
            "de-risk cash flows. Strategic asset position in Western Canadian Sedimentary Basin. "
            "Strong credit metrics and investment-grade balance sheet support dividend growth."
        ),
        "peer_group": ["TRP", "ENB", "PPL.TO", "KEY.TO"],
        "critical_factors": [
            "Western Canadian production growth driving volume throughput",
            "LNG Canada / Cedar LNG project progress (long-term growth optionality)",
            "Contract renewal rates and re-contracting spreads",
        ],
        "key_risks": [
            "Prolonged commodity downturn reducing producer drilling activity",
            "Regulatory delays on new pipeline or facility expansions",
            "Interest rate sensitivity given capital-intensive business model",
        ],
        "valuation_method": "DCF + EV/EBITDA + Dividend Discount (infrastructure/yield)",
        "catalysts": [
            ("Quarterly earnings + throughput volumes", "Quarterly"),
            ("LNG Canada construction milestones", "2025-2026"),
            ("Dividend increase announcement", "Annual, typically Q4"),
        ],
    },

    "SU": {
        "description": (
            "Suncor Energy is Canada's premier integrated energy company, combining oil sands mining "
            "and in-situ production with a downstream refining and retail network (Petro-Canada brand, "
            "1,800+ stations). Produces ~750,000 boe/d making it one of Canada's largest producers."
        ),
        "business_lines": [
            ("Oil Sands (Upstream)", 65, "Mining and in-situ operations: Fort Hills, Syncrude, Firebag, Base Plant"),
            ("Exploration & Production", 10, "Offshore (Terra Nova, Hebron, Buzzard) and conventional assets"),
            ("Refining & Marketing (Downstream)", 25, "4 refineries (460K bbl/d capacity) + Petro-Canada retail network"),
        ],
        "mission": (
            "To be Canada's leading integrated energy company, providing trusted energy products "
            "while advancing toward a low-carbon future responsibly."
        ),
        "competitive_advantage": (
            "Integrated model: upstream production feeds directly into owned refineries, capturing full margin. "
            "Largest oil sands operator with lowest per-barrel operating costs after years of efficiency focus. "
            "Petro-Canada brand provides retail margin stability. Strong shareholder returns (buybacks + dividends)."
        ),
        "peer_group": ["CVE", "CNQ", "IMO", "MEG"],
        "critical_factors": [
            "WTI/WCS oil price differential and absolute crude price levels",
            "Operational reliability improvement at mining and upgrader assets",
            "Capital allocation: buyback pace vs. debt reduction vs. growth capex",
        ],
        "key_risks": [
            "Sustained oil price decline below $60 WTI compresses margins significantly",
            "Operational outage risk at large-scale mining/upgrading assets",
            "ESG/regulatory risk: carbon pricing, emissions caps, stranded asset narrative",
        ],
        "valuation_method": "DCF + NAV (reserve-based) + EV/DACF (integrated E&P standard)",
        "catalysts": [
            ("Quarterly earnings + production guidance", "Quarterly"),
            ("TMX pipeline ramp impact on WCS differential", "2025-2026"),
            ("Share buyback program updates", "Ongoing"),
        ],
    },

    "TRP": {
        "description": (
            "TC Energy (formerly TransCanada) is one of North America's largest energy infrastructure "
            "companies, operating ~93,000 km of natural gas pipelines, 4,900 MW of power generation, "
            "and 650 bcf of natural gas storage. Spun off its liquids pipelines as South Bow in 2024."
        ),
        "business_lines": [
            ("Canadian Natural Gas Pipelines", 35, "NGTL system, Mainline: backbone of Canadian gas transport"),
            ("U.S. Natural Gas Pipelines", 35, "Columbia Gas, ANR, Great Lakes, Tuscarora; serving eastern U.S. demand"),
            ("Mexico Natural Gas Pipelines", 10, "Southeast Gateway pipeline; growing LNG/power generation demand"),
            ("Power & Energy Solutions", 20, "Bruce Power (nuclear), natural gas generation, pumped hydro storage"),
        ],
        "mission": (
            "To deliver the energy people need, every day, safely, reliably, and sustainably, "
            "while creating value for stakeholders and communities."
        ),
        "competitive_advantage": (
            "Monopoly-like regulated pipeline assets with cost-of-service contracts (regulated returns). "
            "Massive scale in North American gas infrastructure — irreplaceable network. "
            "Bruce Power stake provides clean baseload generation exposure. "
            "Post-South Bow spin-off creates a pure-play gas/power infrastructure story."
        ),
        "peer_group": ["ENB", "PBA", "KMI", "WMB"],
        "critical_factors": [
            "NGTL/Mainline rate case outcomes and regulatory ROE",
            "Deleveraging progress post-South Bow separation (target 4.75x debt/EBITDA)",
            "Mexico Southeast Gateway pipeline commissioning and returns",
        ],
        "key_risks": [
            "Regulatory ROE compression on Canadian pipelines (CER decisions)",
            "Slower-than-expected deleveraging constraining dividend growth",
            "Natural gas demand disruption from accelerated electrification",
        ],
        "valuation_method": "DCF + Dividend Discount + EV/EBITDA (regulated utility-like)",
        "catalysts": [
            ("Quarterly earnings + rate base growth", "Quarterly"),
            ("NGTL rate case ruling", "2025-2026"),
            ("Southeast Gateway pipeline in-service", "2025"),
            ("Debt reduction milestones", "Ongoing"),
        ],
    },

    "BMO": {
        "description": (
            "Bank of Montreal is Canada's fourth-largest bank by assets and one of the oldest banks in "
            "North America (founded 1817). Operates across personal & commercial banking, wealth management, "
            "and capital markets in Canada and the U.S. (significantly expanded U.S. presence via Bank of the West acquisition)."
        ),
        "business_lines": [
            ("Canadian P&C Banking", 35, "Personal and commercial banking across Canada; mortgages, deposits, business lending"),
            ("U.S. P&C Banking", 25, "Bank of the West integration; Midwest and West Coast footprint"),
            ("BMO Wealth Management", 20, "Private banking, asset management, insurance; BMO GAM, Nesbitt Burns"),
            ("BMO Capital Markets", 20, "Investment banking, trading, research; strong in Canadian debt and equity"),
        ],
        "mission": (
            "Boldly Grow the Good in business and life — to drive real change for an inclusive society, "
            "a thriving economy, and a sustainable future."
        ),
        "competitive_advantage": (
            "Strengthened U.S. footprint via Bank of the West creates a differentiated cross-border franchise. "
            "Leading Canadian commercial bank with deep mid-market relationships. "
            "Strong capital markets business (particularly Canadian fixed income). "
            "Technology investment in digital banking and AI (BMO Alto, digital-first platforms)."
        ),
        "peer_group": ["RY", "TD", "BNS", "CM", "NA"],
        "critical_factors": [
            "Bank of the West integration synergy realization ($800M+ target)",
            "U.S. commercial loan growth and NIM expansion",
            "Credit quality trajectory as rate cycle turns (PCL normalization)",
        ],
        "key_risks": [
            "Credit losses spike: U.S. commercial real estate or consumer portfolios deteriorate",
            "Integration execution risk: Bank of the West synergies underdelivered",
            "Canadian housing correction impacting mortgage book quality",
        ],
        "valuation_method": "P/B + P/E (bank standard; Altman Z not applicable, use CET1 instead)",
        "catalysts": [
            ("Quarterly earnings + PCL trends", "Quarterly"),
            ("Bank of the West synergy milestones", "Quarterly updates"),
            ("CET1 ratio trajectory and capital return plans", "Ongoing"),
        ],
    },

    "BN": {
        "description": (
            "Brookfield Corporation is a global alternative asset management company with a diversified portfolio "
            "spanning infrastructure, renewable energy, real estate, and private equity. Operates as a holding company "
            "with significant stakes in Brookfield Infrastructure Partners, Brookfield Renewable, and Brookfield Asset Management."
        ),
        "business_lines": [
            ("Infrastructure", 30, "Utility-like assets (electricity grids, water, transport) across North America, Europe, Australia"),
            ("Renewable Energy", 25, "Hydroelectric, wind, solar generating capacity; integrated storage and trading"),
            ("Real Estate", 20, "Commercial, industrial, and logistical properties globally"),
            ("Private Equity / Alternatives", 25, "Asset management fees, private credit, opportunistic investing"),
        ],
        "mission": (
            "To invest in global alternative assets that generate long-term, inflation-protected returns while "
            "driving sustainable infrastructure solutions worldwide."
        ),
        "competitive_advantage": (
            "Diversified stable-yield asset base with inflation protection provides resilient earnings across cycles. "
            "Scale in infrastructure and renewable energy creates procurement and financing advantages. "
            "Asset management fee growth drives margin expansion as AUM grows. "
            "Deep operational expertise in owning and optimizing long-life utility-like assets."
        ),
        "peer_group": ["BIP", "BEP", "NEE", "AVA", "EACPF"],
        "critical_factors": [
            "NAV per share accretion from acquisitions and organic growth",
            "Asset management fee growth from expanding AUM",
            "Capital allocation decisions: reinvestment, buybacks, dividends",
        ],
        "key_risks": [
            "Rising interest rates compressing valuations of yield-oriented assets and increasing financing costs",
            "Renewable energy policy reversals or reduced subsidies",
            "Real estate asset impairment if occupancy or rents decline sharply",
        ],
        "valuation_method": "NAV discount/premium analysis (holding company structure)",
        "catalysts": [
            ("NAV per share updates", "Semi-annual / annual"),
            ("Major acquisition or disposition announcements", "Ongoing"),
            ("Asset management AUM growth milestones", "Quarterly"),
            ("Dividend increase or capital return announcements", "Annual"),
        ],
    },

    "CM": {
        "description": (
            "Canadian Imperial Bank of Commerce (CIBC) is Canada's second-largest bank by assets, formed from "
            "the 1961 merger of Imperial Bank of Canada and Commerce Bank. Operates across personal and commercial "
            "banking, wealth management, and capital markets in Canada and select U.S. markets."
        ),
        "business_lines": [
            ("Canadian Personal Banking", 40, "Retail mortgages, deposits, credit cards, consumer lending across branch network"),
            ("Canadian Commercial Banking", 25, "Mid-market and small business lending, deposits, transaction services"),
            ("Wealth Management", 15, "Private banking, asset management, insurance; CIBC Asset Management, Wood Gundy"),
            ("Capital Markets", 20, "Investment banking, trading, research; strong in Canadian equity and debt markets"),
        ],
        "mission": (
            "To make a difference in the lives of Canadians and support the growth and success of Canadian businesses "
            "through innovative, trusted financial solutions."
        ),
        "competitive_advantage": (
            "Strong position in Canadian mid-market corporate lending with deep client relationships. "
            "Efficient cost-to-income ratio among Canadian peers through technology investments. "
            "Integrated wealth and commercial banking creates cross-sell opportunities. "
            "Leading capital markets franchise in Canadian securities."
        ),
        "peer_group": ["RY", "TD", "BNS", "BMO"],
        "critical_factors": [
            "Net interest margin (NIM) expansion as rates normalize from historically compressed levels",
            "Loan loss provisions and PCL trends in commercial and consumer portfolios",
            "Capital return pace (dividends and buybacks) driving shareholder returns",
        ],
        "key_risks": [
            "Commercial real estate deterioration or insolvency spike if economy softens significantly",
            "NIM compression if rates decline before deposit rates adjust",
            "Regulatory capital requirements limiting distribution flexibility",
        ],
        "valuation_method": "P/B + P/E (bank standard; use CET1 and leverage ratios for risk assessment)",
        "catalysts": [
            ("Quarterly earnings + NIM trends", "Quarterly"),
            ("Capital return announcements (dividend/buyback updates)", "Quarterly/Annual"),
            ("Regulatory capital ratio assessments", "Semi-annual"),
        ],
    },

    "IFCZF": {
        "description": (
            "Intact Financial Corporation is Canada's largest property and casualty insurance company, operating "
            "under banners including Intact Insurance, belairdirect, Elephant Insurance (U.S.), and Heritage Insurance (Canada). "
            "Provides auto, home, commercial, and specialty insurance across Canada and select U.S. markets."
        ),
        "business_lines": [
            ("Personal Auto Insurance", 45, "Canadian auto, home, tenant insurance; digital-first direct distribution"),
            ("Commercial Lines", 30, "Mid-market and small-business commercial insurance; package policies"),
            ("U.S. Insurance", 20, "Elephant Insurance (auto), Kin Canada; growing U.S. premium volume"),
            ("Specialty / Other", 5, "Niche commercial lines, group insurance, reinsurance"),
        ],
        "mission": (
            "To be the most trusted and inclusive insurer in Canada and North America, supporting customers "
            "when they need us most with fair, innovative, and accessible insurance solutions."
        ),
        "competitive_advantage": (
            "Dominant market share in Canadian P&C (~35% of auto market). "
            "Superior underwriting discipline and loss control driving technical profitability. "
            "Integrated digital platform (belairdirect, digital-native) reduces costs and improves customer experience. "
            "Diversified distribution (direct, brokers, partnerships) reduces channel concentration."
        ),
        "peer_group": ["FFH", "RLY.TO", "SAMHX"],
        "critical_factors": [
            "Combined ratio (loss + expense) trends; target <95% for profitability",
            "Premium volume growth in auto and commercial segments",
            "Claims inflation from healthcare, auto parts, supply chain disruptions",
        ],
        "key_risks": [
            "Catastrophic loss events (severe weather, natural disasters) spike loss ratios",
            "Auto claims inflation outpacing pricing discipline; underwriting margin compression",
            "Regulatory pressure on auto insurance rates in Canada (rate suppression by provinces)",
        ],
        "valuation_method": "P/B + P/E (insurance standard; monitor book value growth and ROIC)",
        "catalysts": [
            ("Quarterly earnings + combined ratio", "Quarterly"),
            ("Rate adequacy updates and premium growth", "Quarterly"),
            ("Catastrophic loss events or reserve adjustments", "As occurred"),
            ("Dividend or capital return announcements", "Annual/Quarterly"),
        ],
    },

    "MFC": {
        "description": (
            "Manulife Financial is a global diversified financial services company providing life insurance, wealth "
            "management, and asset management solutions to clients in Asia, Canada, and the U.S. Significant exposure to "
            "Asia-Pacific growth markets, particularly China and Japan, with ~50% of earnings from Asian operations."
        ),
        "business_lines": [
            ("Asia Insurance & Wealth", 50, "Life insurance, employee benefits, wealth management in Asia-Pacific markets"),
            ("Canadian Insurance & Wealth", 20, "Individual life insurance, group benefits, wealth management in Canada"),
            ("U.S. Insurance & Wealth", 15, "Individual life, disability insurance, employee benefits in U.S."),
            ("Global Wealth & Asset Management", 15, "Boston Financial Data Services (wealth platforms), asset management, reinsurance"),
        ],
        "mission": (
            "To make decisions easier and lives better by providing financial advice and solutions that help clients "
            "achieve their financial goals and build financial security."
        ),
        "competitive_advantage": (
            "Unmatched scale and distribution in Asian insurance markets with deep local expertise. "
            "Fee-based wealth and asset management businesses provide stable, higher-margin earnings. "
            "Integrated platform (insurance, wealth, AM) drives cross-sell and client retention. "
            "Strong capital generation supports dividends and share buybacks."
        ),
        "peer_group": ["SLF", "FFH", "GWO", "PRU", "AEG"],
        "critical_factors": [
            "Asia insurance sales and profitability growth; policy lapses and lapse rates",
            "Equity market exposure and sensitivity to market-linked returns on wealth assets",
            "Interest rate environment impact on investment yields and reserves",
        ],
        "key_risks": [
            "Asia economic slowdown (particularly China) compressing insurance demand and credit quality",
            "Investment losses from equity market downturn or credit defaults",
            "Regulatory changes in Asia (China capital outflows restrictions, solvency rules)",
        ],
        "valuation_method": "P/B + P/E (insurance/asset manager blend; track embedded value growth)",
        "catalysts": [
            ("Quarterly earnings + Asia sales growth", "Quarterly"),
            ("Equity market performance impact on wealth and AUM", "Ongoing"),
            ("Dividend increase or share buyback announcements", "Annual"),
            ("Major Asia market developments or regulatory updates", "As occurred"),
        ],
    },

    "NTIOF": {
        "description": (
            "National Bank of Canada is Canada's sixth-largest bank by assets with a dominant position in Quebec, "
            "where it holds ~30% market share. Operates across personal and commercial banking, wealth management, and "
            "financial services, with a focus on the Quebec and Ontario markets."
        ),
        "business_lines": [
            ("Personal Banking", 45, "Mortgages, deposits, consumer lending, credit cards; Quebec-focused branch network"),
            ("Commercial Banking", 30, "Small and mid-market business lending, deposits, working capital solutions"),
            ("Wealth Management", 15, "Private banking, investment advisory, insurance distribution; Financière Bannationale"),
            ("Other / Treasury", 10, "Treasury, other financial services, investment activities"),
        ],
        "mission": (
            "To provide Quebecers and other Canadians with innovative financial solutions that help them achieve "
            "their financial goals and create a sustainable future."
        ),
        "competitive_advantage": (
            "Dominant regional franchise in Quebec provides customer loyalty and pricing power. "
            "Lower cost-to-income ratio than larger national banks due to operational efficiency. "
            "Deep small and mid-market SMB relationships with stickiness. "
            "Local market expertise and community presence in Quebec creates barriers to entry."
        ),
        "peer_group": ["RY", "TD", "BNS", "CM", "BMO"],
        "critical_factors": [
            "Net interest margin (NIM) expansion as rate environment normalizes",
            "Commercial loan growth and credit quality in Quebec SMB segment",
            "Deposit growth and funding stability; cost of deposits",
        ],
        "key_risks": [
            "Quebec economic stagnation or recession compressing lending volumes and credit quality",
            "NIM compression if rate environment weakens faster than expected",
            "Regional concentration risk limits geographic diversification",
        ],
        "valuation_method": "P/B + P/E (regional bank standard; assess capital adequacy and ROE)",
        "catalysts": [
            ("Quarterly earnings + NIM/credit quality metrics", "Quarterly"),
            ("Capital return announcements (dividends/buybacks)", "Quarterly/Annual"),
            ("Quebec economic data and regional SMB activity", "Ongoing"),
        ],
    },

    "RY": {
        "description": (
            "Royal Bank of Canada (RBC) is Canada's largest bank by assets and market capitalization, operating a "
            "diversified global financial services platform spanning personal and commercial banking, wealth management, "
            "capital markets, and insurance across Canada, U.S., and international markets."
        ),
        "business_lines": [
            ("Canadian Personal & Commercial Banking", 35, "Mortgages, deposits, business loans, payments, deposits; largest retail presence"),
            ("U.S. Banking", 20, "U.S. personal and commercial banking; City National merger integration (West Coast focus)"),
            ("Wealth Management", 15, "Private banking, asset management, insurance; RBC Dominion Securities, RBC GAM"),
            ("Capital Markets", 20, "Investment banking, trading, research; strong global franchise"),
            ("Insurance & Other", 10, "Life insurance, P&C insurance, other financial services"),
        ],
        "mission": (
            "To deliver consistent, above-average returns to shareholders, while driving positive social and environmental "
            "outcomes through responsible banking and financial services."
        ),
        "competitive_advantage": (
            "Largest Canadian bank with unmatched scale and diversification across segments and geographies. "
            "Leading capital markets franchise globally (equities, FI, emerging markets). "
            "Strong wealth management and insurance distribution. "
            "Technology and digital banking investments create operational efficiency and customer experience edge."
        ),
        "peer_group": ["TD", "BNS", "CM", "BMO"],
        "critical_factors": [
            "Net interest margin (NIM) expansion as rates normalize; deposit mix and costs",
            "Capital Markets business profitability and market volatility sensitivity",
            "Credit quality trajectory; provision for credit losses (PCL) normalization",
        ],
        "key_risks": [
            "Geopolitical or macro shock triggering capital markets revenue decline and credit losses",
            "NIM compression if rate environment weakens; deposit flight to higher-yield alternatives",
            "Regulatory capital requirements and OSFI guidance limiting distributions",
        ],
        "valuation_method": "P/B + P/E (bank standard; use CET1 and ROE as key metrics)",
        "catalysts": [
            ("Quarterly earnings + NIM/PCL trends", "Quarterly"),
            ("Capital Markets activity and market condition updates", "Ongoing"),
            ("Dividend increase or buyback program announcements", "Annual/Quarterly"),
            ("City National integration synergy achievements", "Quarterly updates"),
        ],
    },

    "SLF": {
        "description": (
            "Sun Life Financial is a global diversified financial services company providing life insurance, health "
            "benefits, wealth management, and asset management solutions across Canada, U.S., and Asia-Pacific. "
            "~50% of revenue comes from Asia-Pacific operations, making it a significant Asia-exposure play."
        ),
        "business_lines": [
            ("Insurance Canada", 25, "Individual life insurance, group benefits, group insurance across Canada"),
            ("Insurance U.S.", 20, "Employee benefits, life insurance, supplemental insurance in U.S. market"),
            ("Asia Insurance", 30, "Rapidly growing life and health insurance in Vietnam, Philippines, Indonesia, Malaysia"),
            ("Wealth & Asset Management", 25, "Asset management (MFS, Clarica), wealth management, institutional services"),
        ],
        "mission": (
            "To help our clients achieve lifetime financial security and live healthier lives by providing reliable, "
            "innovative insurance and wealth management solutions."
        ),
        "competitive_advantage": (
            "Leading position in Canadian group benefits (sticky recurring revenue). "
            "Rapidly expanding Asia-Pacific franchise with growth rates 15%+ annually. "
            "Integrated wealth and asset management (MFS) provides fee diversification. "
            "Strong capital generation and shareholder returns (buybacks + dividends)."
        ),
        "peer_group": ["MFC", "FFH", "GWO", "PRU", "AEG"],
        "critical_factors": [
            "Asia insurance growth rates and profitability; new market expansion",
            "Asset management AUM growth and fee income expansion",
            "Group benefits persistency and pricing in Canada and U.S.",
        ],
        "key_risks": [
            "Asia economic slowdown or policy lapse acceleration in emerging markets",
            "Investment losses from equity/credit market downturns affecting embedded value",
            "Regulatory changes (capital requirements, solvency rules) in Asia or North America",
        ],
        "valuation_method": "P/B + P/E (insurance/asset manager; monitor embedded value and ROIC)",
        "catalysts": [
            ("Quarterly earnings + Asia sales/profitability", "Quarterly"),
            ("AUM and fee income growth milestones", "Quarterly"),
            ("Dividend increase or share buyback announcements", "Annual"),
            ("Major Asia expansion or acquisition announcements", "Ongoing"),
        ],
    },

    "TD": {
        "description": (
            "Toronto-Dominion Bank is Canada's largest bank by revenue and one of North America's leading diversified "
            "financial services companies. Operates a significant U.S. retail banking franchise via TD Bank (Northeastern U.S.), "
            "plus Canadian operations, wealth management, and capital markets across North America."
        ),
        "business_lines": [
            ("Canadian Personal & Commercial Banking", 30, "Mortgages, deposits, business lending across Canada; strong retail presence"),
            ("U.S. Banking (TD Bank)", 35, "Largest retail footprint in Northeast U.S.; mortgages, deposits, commercial loans"),
            ("Wealth Management", 15, "Private banking, asset management (TD Asset Management), insurance distribution"),
            ("Capital Markets", 15, "Investment banking, trading, research; strong in North American equities and FI"),
            ("Other", 5, "Treasury, other financial services"),
        ],
        "mission": (
            "To be the better bank, helping millions achieve their financial goals and supporting the success of Canadian "
            "and U.S. businesses through trusted, innovative financial solutions."
        ),
        "competitive_advantage": (
            "Largest retail banking footprint in Northeast U.S. creates unmatched scale in the region. "
            "Canadian market leader with deep customer relationships across retail and commercial. "
            "Integrated cross-border platform (Canada-U.S.) provides unique competitive advantage. "
            "Strong capital generation and efficient cost structure relative to peers."
        ),
        "peer_group": ["RY", "BNS", "CM", "BMO"],
        "critical_factors": [
            "U.S. NIM expansion and loan growth; TD Bank competitive positioning in Northeast",
            "Credit quality in U.S. consumer and commercial portfolios; PCL trends",
            "Capital return pace and CET1 capital ratio management",
        ],
        "key_risks": [
            "U.S. credit deterioration spike: consumer/SMB insolvencies if economy weakens",
            "NIM compression from rising deposit costs or rate declines",
            "Regulatory capital pressures or OSFI/Federal Reserve constraints on distributions",
        ],
        "valuation_method": "P/B + P/E (bank standard; track U.S. earnings contribution and exposure)",
        "catalysts": [
            ("Quarterly earnings + U.S. NIM/credit metrics", "Quarterly"),
            ("U.S. economic data and Fed policy impact on loan demand", "Ongoing"),
            ("Capital return announcements (dividends/buybacks)", "Annual/Quarterly"),
            ("TD Bank integration and expense synergy updates", "Quarterly"),
        ],
    },

    "SNCAF": {
        "description": (
            "AtkinsRealis Group (formerly SNC-Lavalin) is a diversified engineering and professional services company "
            "providing project delivery, engineering design, and consulting services to the oil & gas, nuclear, "
            "mining, infrastructure, and clean energy sectors globally."
        ),
        "business_lines": [
            ("Nuclear", 25, "Nuclear plant design, engineering, decommissioning; CANDU expertise; government contracts"),
            ("Oil & Gas", 35, "E&P engineering, LNG project delivery, downstream optimization, upstream development"),
            ("Infrastructure", 20, "Transportation, water, power infrastructure; urban transit, tunneling, dams"),
            ("Mining & Metals", 15, "Mining engineering, metallurgical design, environmental compliance"),
            ("Clean Energy", 5, "Renewable energy projects, grid modernization, energy transition engineering"),
        ],
        "mission": (
            "To deliver world-class engineering solutions and professional services that drive sustainable growth "
            "for clients and create shared value across global markets."
        ),
        "competitive_advantage": (
            "Unique nuclear engineering expertise and CANDU history provides moat in nuclear power projects. "
            "Global scale in LNG and major project delivery creates competitive advantage. "
            "Integrated services model (engineering, procurement, construction) improves project execution. "
            "Strong government relationships in Canada, especially on nuclear and infrastructure contracts."
        ),
        "peer_group": ["WSP", "WLDSF", "ACM", "PAX", "SNC.TO"],
        "critical_factors": [
            "LNG project backlog execution and margin realization",
            "New nuclear project wins (small modular reactors, government initiatives)",
            "Gross margin expansion through project mix and operational leverage",
        ],
        "key_risks": [
            "Project execution risks: schedule delays, cost overruns on major engineering projects",
            "Macro slowdown reducing E&P capex spend and infrastructure investment",
            "Reputational/compliance risk from legacy corporate governance issues",
        ],
        "valuation_method": "DCF + EV/EBITDA (project-based; backlog conversion is key)",
        "catalysts": [
            ("Quarterly earnings + backlog updates", "Quarterly"),
            ("Major project award announcements (nuclear, LNG, infrastructure)", "Ongoing"),
            ("Margin improvement from project delivery", "Quarterly"),
            ("Government contracts and stimulus announcements", "As announced"),
        ],
    },

    "BDRBF": {
        "description": (
            "Bombardier Inc. (Class B Shares) is a Canadian aircraft manufacturer focused exclusively on business jets "
            "and after-market services after the sale of its commercial aerospace and rail divisions. Produces high-margin "
            "business jets (Learjet, Global, Challenger lines) serving ultra-high-net-worth and corporate clients globally."
        ),
        "business_lines": [
            ("Business Jet Manufacturing", 65, "Learjet, Global, and Challenger line-ups; deliveries, development"),
            ("After-Market Services & Support", 35, "Spare parts, maintenance, training, engineering support; high margin"),
        ],
        "mission": (
            "To design, manufacture, and support the world's best business jets and provide exceptional customer support "
            "that creates lasting value for customers, employees, and shareholders."
        ),
        "competitive_advantage": (
            "Premium brand positioning in ultra-high-end business jet market with loyal customer base. "
            "Integrated after-market services (35% of revenue) provides recurring, high-margin revenue stream. "
            "Strong backlog provides visibility; limited direct competition (Gulfstream, Bombardier duopoly in large jets). "
            "Operational efficiency improvements post-divestiture improve margins."
        ),
        "peer_group": ["BA", "LMT", "HII"],
        "critical_factors": [
            "Business jet delivery volume and price realization in global market",
            "Backlog growth and conversion to deliveries; new platform ramp",
            "After-market services revenue growth and margin maintenance",
        ],
        "key_risks": [
            "Global economic downturn reducing UHNW capex and aircraft demand",
            "New aircraft development delays or technical issues (Global 8000 ramp risk)",
            "Supply chain disruptions impacting component availability and delivery timelines",
        ],
        "valuation_method": "DCF + EV/EBITDA (manufacturing + recurring services blend)",
        "catalysts": [
            ("Quarterly earnings + delivery and backlog updates", "Quarterly"),
            ("Global 8000 delivery ramp and order book growth", "Quarterly updates"),
            ("Free cash flow generation and capital allocation", "Quarterly"),
            ("Macro economic indicators (UHNW wealth, M&A activity)", "Ongoing"),
        ],
    },

    "CP": {
        "description": (
            "Canadian Pacific Kansas City (CPKC) is a transcontinental railroad connecting Canada, the U.S. (Midwest and South), "
            "and Mexico, formed from the 2023 merger of Canadian Pacific Railway and Kansas City Southern. Provides freight rail "
            "transportation across North America with strategic advantage in Mexico trade corridors."
        ),
        "business_lines": [
            ("Merchandise Freight", 55, "Automotive, intermodal, consumer products, forest products, metals/minerals"),
            ("Grain & Coal", 30, "Canadian grain exports, coal to utilities and export terminals; seasonal volume"),
            ("Energy & Chemicals", 15, "Crude oil, petrochemicals, refined products; lower than peers but strategic"),
        ],
        "mission": (
            "To provide customers with the North American transportation solutions they need to compete globally, "
            "while delivering sustainable value to stakeholders and supporting the communities we serve."
        ),
        "competitive_advantage": (
            "Unique Mexico corridor (Monterrey-Texas trade) creates strategic differentiation from competitors. "
            "Integrated CPKC network spans Canada-U.S.-Mexico, enabling complex supply chains not possible for competitors. "
            "Strong freight mix diversity reduces commodity exposure vs. peers (CN, UP). "
            "Technology and operational optimization drive margin expansion."
        ),
        "peer_group": ["CN", "UP", "CSX", "KSU.TO"],
        "critical_factors": [
            "Volume growth in automotive and intermodal (Mexico trade ramp post-CPKC integration)",
            "Operating ratio improvement (OpEx as % of revenue); target <60%",
            "Grain exports and coal volumes; commodity price pass-through",
        ],
        "key_risks": [
            "U.S./Mexico economic slowdown reducing automotive and intermodal freight demand",
            "Integration execution challenges from CPKC merger; synergy shortfalls",
            "Competitive pricing pressure on key routes from trucking and competitor rails",
        ],
        "valuation_method": "DCF + EV/EBITDA (railroad standard; focus on free cash flow)",
        "catalysts": [
            ("Quarterly earnings + operating ratio trends", "Quarterly"),
            ("CPKC integration synergy updates and realized benefits", "Quarterly"),
            ("Mexico trade volume and automotive freight updates", "Quarterly"),
            ("Capital allocation announcements (dividends, buybacks)", "Annual/Quarterly"),
        ],
    },

    "ELEEF": {
        "description": (
            "Element Fleet Management is a North American vehicle fleet management and leasing company providing "
            "fleet services, financing, and technology solutions to corporate and government customers. Operates "
            "the largest privately-held fleet management platform in the region."
        ),
        "business_lines": [
            ("Fleet Leasing & Management", 70, "Full-service fleet leasing, maintenance, fuel, insurance, driver safety"),
            ("Fleet Technology Services", 20, "Telematics, fleet optimization software, mobile apps, driver coaching"),
            ("Other Fleet Services", 10, "Remarketing, parts procurement, roadside assistance, compliance"),
        ],
        "mission": (
            "To simplify fleet management for our customers by providing integrated, technology-enabled solutions "
            "that reduce costs, improve safety, and enhance operational efficiency."
        ),
        "competitive_advantage": (
            "Largest independent fleet management platform in North America with scale advantages. "
            "Vertically integrated model (leasing, maintenance, tech) drives customer stickiness and profitability. "
            "Proprietary technology platform and data analytics improve customer outcomes. "
            "High customer switching costs create sticky recurring revenue base."
        ),
        "peer_group": ["MAC", "AMSWA", "LTRX"],
        "critical_factors": [
            "Fleet revenue growth and customer acquisition; churn rates",
            "EBITDA margin expansion from technology monetization and scale",
            "Used vehicle price realization (impacts residual values and profitability)",
        ],
        "key_risks": [
            "Economic downturn reducing fleet sizes and capex spending by customers",
            "Used vehicle market collapse impacting residual values and lease returns",
            "Competition from traditional auto lease providers (captive finance arms)",
        ],
        "valuation_method": "DCF + EV/EBITDA (leasing model; monitor customer lifetime value)",
        "catalysts": [
            ("Quarterly earnings + customer metrics", "Quarterly"),
            ("Fleet growth initiatives and pricing updates", "Quarterly"),
            ("Technology platform monetization milestones", "Annual/Quarterly"),
            ("Used vehicle market trends and residual value impacts", "Ongoing"),
        ],
    },

    "GFL": {
        "description": (
            "GFL Environmental is one of North America's largest waste and environmental services companies, providing "
            "waste collection, recycling, transfer/disposal, and liquid & hazardous waste management services across "
            "Canada and the U.S. through an integrated network of facilities and customer relationships."
        ),
        "business_lines": [
            ("Solid Waste Collection", 50, "Residential and commercial trash collection, commercial compactor services"),
            ("Disposal & Transfer", 30, "Landfill operations, transfer stations, recycling facilities; gate revenue"),
            ("Liquid Waste & Environmental", 15, "Hazardous and non-hazardous liquid waste disposal, environmental remediation"),
            ("Other", 5, "Ancillary services, equipment rental, third-party collection"),
        ],
        "mission": (
            "To be the leading environmental services company in North America, providing sustainable waste management "
            "and environmental solutions that protect the environment and communities we serve."
        ),
        "competitive_advantage": (
            "Largest integrated waste platform in North America creates cost synergies and route density. "
            "Long-term collection contracts provide stable, recurring revenue with inflation pass-through. "
            "Owned disposal capacity (landfills, transfer stations) creates margin capture vs. competitors. "
            "M&A playbook allows consolidation of fragmented regional operators."
        ),
        "peer_group": ["WM", "RSG", "AMRS"],
        "critical_factors": [
            "Same-store volume growth in waste collection; price realization",
            "Disposal facility margins and capacity utilization",
            "Debt reduction and deleveraging post-acquisition integration",
        ],
        "key_risks": [
            "Recession reducing commercial waste volumes and collection pricing",
            "Landfill capacity constraints or environmental regulation tightening",
            "Higher input costs (fuel, labor) and difficulty passing through to customers",
        ],
        "valuation_method": "DCF + EV/EBITDA (infrastructure-like cash flows with growth)",
        "catalysts": [
            ("Quarterly earnings + volume and price metrics", "Quarterly"),
            ("Acquisition completion and integration synergy updates", "Quarterly/As announced"),
            ("Facility margin expansion and utilization", "Quarterly"),
            ("Debt reduction and credit metric improvements", "Quarterly/Annual"),
        ],
    },

    "RBA": {
        "description": (
            "RB Global (formerly Ritchie Bros. Auctioneers) is a leading global operator of online and in-person "
            "auctions for industrial equipment, vehicles, and heavy machinery. Services buyers and sellers of used "
            "industrial assets across construction, mining, transportation, and agriculture sectors."
        ),
        "business_lines": [
            ("Equipment Auctions", 70, "Online and physical auctions for construction equipment, excavators, trucks, machinery"),
            ("Marketplace Services", 20, "Liquidity services, private sale facilitation, fleet disposals; growing digital platform"),
            ("Tradeout / Other", 10, "Equipment appraisals, logistics support, other value-added services"),
        ],
        "mission": (
            "To connect buyers and sellers of industrial equipment globally, providing transparent, efficient, and "
            "innovative marketplace solutions that maximize value for all participants."
        ),
        "competitive_advantage": (
            "Market-leading position with 70+ years of brand trust and customer relationships. "
            "Two-sided network effects create competitive moat (more sellers attract more buyers and vice versa). "
            "Digital transformation (online auctions, mobile platform) improves customer experience and margins. "
            "Global logistics network and financing partnerships create ecosystem advantage."
        ),
        "peer_group": ["COHR", "QRTEA", "eBay"],
        "critical_factors": [
            "Transaction volumes and gross transaction values (GTV) growth",
            "Commission take rate maintenance and expansion through marketplace mix",
            "Digital penetration growth in online auctions reducing physical auction dependency",
        ],
        "key_risks": [
            "Macro downturn reducing capital equipment sales and auction volumes",
            "Competitive pressure from direct online platforms (manufacturer e-commerce)",
            "Customer concentration risk: major sellers/buyers account for significant volume",
        ],
        "valuation_method": "DCF + EV/EBITDA (marketplace economics)",
        "catalysts": [
            ("Quarterly earnings + transaction volume/GTV metrics", "Quarterly"),
            ("Digital platform adoption and marketplace growth", "Quarterly"),
            ("Commission rate and fee expansion initiatives", "Quarterly/Annual"),
            ("M&A integration or new vertical launch announcements", "Ongoing"),
        ],
    },

    "TMTNF": {
        "description": (
            "Toromont Industries is a leading Canadian equipment dealer and distributor, operating two primary business "
            "segments: Caterpillar equipment sales, rentals, and aftermarket support in Canada, and CIMCO refrigeration "
            "solutions globally. Delivers a blend of equipment distribution, industrial services, and refrigeration systems."
        ),
        "business_lines": [
            ("Caterpillar Equipment & Services", 65, "New and used equipment sales, rentals, parts, service; mining, construction, industrial"),
            ("CIMCO Refrigeration", 30, "Refrigeration systems, HVAC solutions, marine refrigeration; design and installation"),
            ("Other", 5, "Financing, third-party product distribution, ancillary services"),
        ],
        "mission": (
            "To be the preferred provider of equipment and solutions that enable our customers to operate safely, "
            "efficiently, and sustainably across their industries."
        ),
        "competitive_advantage": (
            "Exclusive Caterpillar dealership in Canada creates high-barrier distribution franchise. "
            "Integrated equipment rental fleet and service network drive customer stickiness. "
            "CIMCO global refrigeration presence and expertise in marine/industrial applications. "
            "Recurring parts, service, and rental revenue streams provide earnings stability."
        ),
        "peer_group": ["WFT", "GES", "ACR", "UVV"],
        "critical_factors": [
            "Mining capex and equipment utilization driving CAT sales volume",
            "Rental utilization rates and fleet return on assets (deployed rental equipment)",
            "Parts and service revenue growth from installed base",
        ],
        "key_risks": [
            "Commodity downturn reducing mining activity and CAT equipment demand",
            "Used equipment prices decline if market oversupply; impacts rental fleet values",
            "Competition from other CAT dealers (Canada regional market share risk)",
        ],
        "valuation_method": "DCF + EV/EBITDA (equipment distribution with service/rental recurring revenue)",
        "catalysts": [
            ("Quarterly earnings + equipment sales/rental metrics", "Quarterly"),
            ("Mining capex spend and CAT/industry demand trends", "Quarterly"),
            ("Parts and service margin expansion", "Quarterly"),
            ("Capital allocation announcements (dividends, buybacks)", "Annual/Quarterly"),
        ],
    },

    "WSPOF": {
        "description": (
            "WSP Global is a world-leading engineering consulting services firm providing project delivery, advisory, "
            "and technology solutions across infrastructure, resources, energy, and real estate sectors globally. "
            "Operates through ~200 offices across 40+ countries with diverse geographic and sectoral diversification."
        ),
        "business_lines": [
            ("Transportation", 30, "Highways, airports, rail, transit, ports, intelligent transportation systems"),
            ("Built Environment", 20, "Buildings, urban development, campus masterplans, real estate advisory"),
            ("Resources & Energy", 25, "Oil & gas, mining, power generation, renewable energy engineering"),
            ("Environment", 15, "Environmental consulting, water, sustainability, remediation"),
            ("Other/Tech", 10, "Digital solutions, software platforms, data services, technology consulting"),
        ],
        "mission": (
            "To be a trusted global leader in engineering and professional services, helping clients shape a more "
            "sustainable, resilient, and prosperous world."
        ),
        "competitive_advantage": (
            "Global scale with diverse sector and geographic exposure reduces concentration risk. "
            "Technology and digital services capability drive higher-margin growth. "
            "Strategic M&A of complementary consulting firms expands service lines and geography. "
            "Strong recurring advisory revenue provides earnings stability."
        ),
        "peer_group": ["ACM", "WLDSF", "AMRS", "PAX"],
        "critical_factors": [
            "Organic revenue growth (excluding acquisitions) and backlog conversion",
            "Digital/tech services revenue growth and margin improvement",
            "Operating margin expansion through operational leverage and service mix",
        ],
        "key_risks": [
            "Economic slowdown reducing infrastructure and real estate development spending",
            "M&A integration challenges or overpayment on acquisitions",
            "Talent retention and recruitment in competitive consulting market",
        ],
        "valuation_method": "DCF + EV/EBITDA (consulting services; monitor backlog and utilization)",
        "catalysts": [
            ("Quarterly earnings + organic revenue growth", "Quarterly"),
            ("Backlog and pipeline updates", "Quarterly"),
            ("M&A announcements and integration progress", "Ongoing"),
            ("Technology/digital services revenue contribution", "Quarterly"),
        ],
    },

    "CNSWF": {
        "description": (
            "Constellation Software is a Canadian-listed holding company that acquires, manages, and grows vertical market "
            "software (VMS) businesses serving niche end-markets with mission-critical applications. Operates a decentralized "
            "portfolio of 100+ independent software companies across diverse verticals with recurring SaaS-like revenue models."
        ),
        "business_lines": [
            ("Vertical Market Software", 85, "Niche software solutions for specific industries: healthcare, legal, construction, finance, etc."),
            ("Managed IT Services", 10, "IT infrastructure, support, consulting for VMS customer base"),
            ("Other / Holding Company", 5, "Interest income, treasury operations, corporate overhead"),
        ],
        "mission": (
            "To acquire and grow vertical market software companies that serve niche markets with sustainable competitive "
            "advantages, supporting customers in their critical business operations."
        ),
        "competitive_advantage": (
            "Unique M&A roll-up strategy acquiring fragmented VMS markets; consolidation playbook. "
            "Decentralized operating model allows acquired companies to maintain autonomy while benefiting from parent support. "
            "Recurring subscription/SaaS-like revenue provides visibility and predictability. "
            "Multiple arbitrage opportunity: acquiring niche software at low multiples, improving operations, growing organically."
        ),
        "peer_group": ["IT", "VIML", "VERIV"],
        "critical_factors": [
            "Organic revenue growth within acquired software companies (churn, price increases)",
            "M&A pipeline and acquisition volume/quality; integration success",
            "Free cash flow generation for reinvestment in acquisitions and shareholder returns",
        ],
        "key_risks": [
            "Economic downturn reducing capex spend of VMS customers, especially in discretionary IT",
            "Integration execution risk: acquired company underperformance post-acquisition",
            "Valuation compression if market turns away from software/SaaS multiples",
        ],
        "valuation_method": "DCF + EV/EBITDA + P/FCF (software/VMS model; focus on FCF conversion)",
        "catalysts": [
            ("Quarterly earnings + organic growth metrics", "Quarterly"),
            ("M&A announcements and deal pipeline updates", "Ongoing"),
            ("Free cash flow generation and capital allocation", "Quarterly/Annual"),
            ("Integration progress and synergy realization", "Quarterly updates"),
        ],
    },

    "SHOP": {
        "description": (
            "Shopify is a Canadian-listed cloud-based e-commerce and point-of-sale platform enabling merchants of all "
            "sizes to sell online, in-store, and across multiple channels. Operates a global platform business with "
            "95,000+ stores using the platform and expanding into merchant services and financial products."
        ),
        "business_lines": [
            ("Subscription Solutions", 50, "Platform subscription fees, app store, theme sales; recurring SaaS model"),
            ("Merchant Services", 30, "Payment processing, point-of-sale, shipping, cash advances (merchant financing)"),
            ("Other / Strategic Initiatives", 20, "Logistics (6 River Systems, warehouse automation), ads, capital/fintech services"),
        ],
        "mission": (
            "To make commerce better for everyone by providing powerful, easy-to-use tools for entrepreneurs and brands "
            "to build and grow their businesses globally."
        ),
        "competitive_advantage": (
            "Leading independent e-commerce platform with largest app ecosystem and merchant lock-in. "
            "Expanding merchant services (payments, logistics, financing) drive higher monetization per merchant. "
            "Network effects: growth in apps/integrations attracts merchants; growth in merchants attracts developers. "
            "Global reach with product supporting multiple geographies, currencies, and sales channels."
        ),
        "peer_group": ["WIX", "SQ", "PYPL", "MSTR"],
        "critical_factors": [
            "Gross merchandise volume (GMV) growth and net revenue retention (NRR) from existing merchants",
            "Merchant services take rate expansion and penetration (payments, capital, logistics)",
            "Operating leverage and path to profitability from AI/efficiency gains",
        ],
        "key_risks": [
            "E-commerce growth slowdown reducing merchant capex and Shopify adoption",
            "Shift to integrated platforms (Amazon, TikTok Shop) reducing Shopify market share",
            "Competition from WooCommerce, BigCommerce and newer entrants in SMB e-commerce",
        ],
        "valuation_method": "DCF + P/S (SaaS/platform; focus on NRR and path to profitability)",
        "catalysts": [
            ("Quarterly earnings + GMV, NRR, merchant growth metrics", "Quarterly"),
            ("Merchant services revenue contribution and take rate expansion", "Quarterly"),
            ("Operating margin improvement from AI and automation", "Quarterly/Annual"),
            ("New product launches (ads, fintech, logistics) expansion updates", "Ongoing"),
        ],
    },

    "CCDBF": {
        "description": (
            "CCL Industries is a global leader in specialty packaging and label solutions, providing pressure-sensitive "
            "labels, packaging materials, and specialty films for consumer goods, pharmaceuticals, and industrial sectors. "
            "Operates with a diversified portfolio across label, packaging, and film segments globally."
        ),
        "business_lines": [
            ("Label Solutions", 50, "Pressure-sensitive labels, linerboard; food, beverage, pharma, industrial applications"),
            ("Packaging Materials", 35, "Specialty films, bags, protective packaging; industrial and consumer applications"),
            ("Ancillary / Other", 15, "Flexographic and digital printing, testing services, managed inventory services"),
        ],
        "mission": (
            "To be the world's leading provider of specialty label and packaging solutions, supporting customers in "
            "global supply chains with sustainable, innovative products."
        ),
        "competitive_advantage": (
            "Dominant market position in pressure-sensitive labels with scale economies. "
            "Integrated manufacturing and printing capabilities create vertical integration advantages. "
            "Customer relationships and switching costs high in pharmaceutical and food & beverage applications. "
            "Strong R&D and technical service support differentiates from competitors."
        ),
        "peer_group": ["RRD", "AVY", "WNW", "UL"],
        "critical_factors": [
            "Volume growth in food, beverage, and pharmaceutical end-markets",
            "Price realization and input cost (raw materials, energy) inflation pass-through",
            "Margin stability and operating leverage from scale",
        ],
        "key_risks": [
            "Packaging substitution: shift away from labels to alternative labeling (direct print, etc.)",
            "Commodity input cost inflation reducing margins if price increases lag",
            "Macro slowdown reducing consumer goods production and demand",
        ],
        "valuation_method": "DCF + EV/EBITDA (packaging/materials; monitor raw material cost trends)",
        "catalysts": [
            ("Quarterly earnings + volume and price metrics", "Quarterly"),
            ("Input cost and margin trend updates", "Quarterly"),
            ("End-market demand signals (consumer goods, pharma)", "Ongoing"),
            ("Capital allocation and dividend announcements", "Annual/Quarterly"),
        ],
    },

    "FCXXF": {
        "description": (
            "First Capital REIT is a leading Canadian REIT specializing in grocery-anchored, urban retail properties "
            "across Canada's major metropolitan markets. Provides stable, high-quality retail real estate with strong "
            "tenant mix (essential retail) and consistent cash flows to unitholders."
        ),
        "business_lines": [
            ("Grocery-Anchored Retail", 85, "Shopping centers anchored by major grocers (Loblaws, Sobeys, Metro); secondary tenants"),
            ("Mixed-Use Urban Retail", 15, "Urban-focused retail properties; mixed-use development; emerging grocery-less concept testing"),
        ],
        "mission": (
            "To own and operate high-quality, grocery-anchored retail properties in Canada's major urban markets, "
            "generating sustainable distributions to unitholders while supporting thriving communities."
        ),
        "competitive_advantage": (
            "Essential retail focus (grocery-anchored) provides recession resistance and stable tenant credit. "
            "High-quality real estate in premium urban locations with embedded land value. "
            "Strong relationships with major grocer anchors (Loblaws, Sobeys) provide renewal certainty. "
            "Efficient management and maintenance of portfolio creates operational efficiency."
        ),
        "peer_group": ["REI.UN", "ARCP", "ARL.UN", "PURE"],
        "critical_factors": [
            "Same-store NOI growth from rental rate increases and occupancy maintenance",
            "Tenant occupancy and credit quality; renewal spreads",
            "Distribution per unit yield maintenance and sustainability",
        ],
        "key_risks": [
            "Retail real estate disruption: e-commerce and changing consumer behavior reduce traffic",
            "Anchor tenant financial stress (grocer consolidation, bankruptcy risk)",
            "Interest rate sensitivity given leverage and mortgage refinancing requirements",
        ],
        "valuation_method": "DCF + P/FFO + NAV (real estate; monitor FFO per unit and distribution coverage)",
        "catalysts": [
            ("Quarterly earnings + NOI and occupancy metrics", "Quarterly"),
            ("Rental rate increases and lease renewal spreads", "Quarterly"),
            ("Distribution per unit and payout ratio announcements", "Monthly/Quarterly"),
            ("Capital deployment (acquisitions, dispositions) announcements", "Ongoing"),
        ],
    },

    "BIP": {
        "description": (
            "Brookfield Infrastructure Partners is a global infrastructure limited partnership providing essential services "
            "through a diversified portfolio of utility-like assets (electricity grids, water systems, transport, telecom) "
            "across North America, Europe, Australia, and Latin America. Generates stable, long-duration cash flows with "
            "inflation protection."
        ),
        "business_lines": [
            ("Utilities (Electricity, Water)", 40, "Regulated utility operations; electricity grids, water systems; essential services"),
            ("Transport & Logistics", 30, "Toll roads, ports, terminals, rail assets; user-fee or regulated return models"),
            ("Telecom & Technology", 20, "Fiber optic networks, telecom infrastructure; growing broadband and 5G opportunities"),
            ("Other / Development", 10, "Growth projects, technology, minority investments, corporate"),
        ],
        "mission": (
            "To invest in global essential infrastructure assets that generate stable, inflation-protected returns while "
            "supporting sustainable economic growth and development in our communities."
        ),
        "competitive_advantage": (
            "Diversified portfolio across geographies, assets, and revenue models reduces concentration risk. "
            "Essential service nature (utilities, transport) provides resilient demand and inflation pass-through. "
            "Stable cash flows support high distribution yields and distribution growth. "
            "Scale in infrastructure acquisition and operation creates operational efficiency."
        ),
        "peer_group": ["BN", "ENB", "KMI", "EACPF", "AVA"],
        "critical_factors": [
            "Distribution per unit growth and sustainability; payout ratios",
            "NOI/EBITDA growth from organic operations and acquisitions",
            "Interest rate sensitivity and refinancing risk (leverage management)",
        ],
        "key_risks": [
            "Rising interest rates compressing valuations and increasing financing costs",
            "Regulatory changes in utility and toll road markets (rate setting, cap on returns)",
            "Integration risk on major acquisitions or greenfield development delays",
        ],
        "valuation_method": "DCF + Dividend Discount + NAV (infrastructure LP; monitor distribution coverage and leverage)",
        "catalysts": [
            ("Distribution per unit announcements and increases", "Quarterly/Annual"),
            ("Quarterly earnings + NOI and EBITDA metrics", "Quarterly"),
            ("Major acquisition or divestiture announcements", "Ongoing"),
            ("Interest rate and refinancing developments", "As announced"),
        ],
    },

    # ── US Focus List ──────────────────────────────────────────────────

    "GOOG": {
        "description": "Alphabet Inc. (Google parent) is a dominant digital advertising and cloud computing company. Primary revenue driver is Google Search and YouTube advertising. Expanding into cloud services, autonomous vehicles (Waymo), and AI capabilities.",
        "business_lines": [
            ("Google Search & YouTube Advertising", 60, "Display and search ad network across Google.com and YouTube platform"),
            ("Google Cloud", 10, "Cloud infrastructure, data analytics, and enterprise services"),
            ("Google Network (AdSense, AdMob)", 15, "Third-party network advertising revenue"),
            ("Other Bets (Waymo, Verily, etc.)", 15, "Autonomous vehicles, life sciences, moonshot projects"),
        ],
        "mission": "To organize the world's information and make it universally accessible.",
        "competitive_advantage": "Massive search moat with 90%+ search market share, unmatched data collection, YouTube dominance, and rapid AI/ML capabilities.",
        "peer_group": ["META", "MSFT", "AMZN"],
        "critical_factors": ["Regulatory antitrust pressure on ad/search dominance", "AI competition and generative search adoption", "YouTube ad growth and creator revenue sharing"],
        "key_risks": ["Antitrust litigation threatening core search business", "Generative AI cannibalizing search queries", "Competition from OpenAI and ChatGPT integration"],
        "valuation_method": "DCF + EV/Revenue",
        "catalysts": [
            ("AI Search Integration Results", "Q2-Q3 2026"),
            ("Antitrust Ruling (Potential Remedy)", "H2 2026+"),
            ("Cloud Growth Acceleration", "Quarterly"),
        ],
    },
    "META": {
        "description": "Meta Platforms owns Facebook, Instagram, and WhatsApp, with 3+ billion monthly active users. Monetization focuses on advertising across social platforms. Investing heavily in Reality Labs metaverse and AI infrastructure.",
        "business_lines": [
            ("Facebook & Instagram Advertising", 97, "Core social media ad network across apps"),
            ("Reality Labs", 2, "VR/AR hardware (Quest) and metaverse development"),
            ("Other", 1, "Miscellaneous revenue streams"),
        ],
        "mission": "To give people the power to build community and bring the world closer together.",
        "competitive_advantage": "Largest social network globally with integrated ecosystem (WhatsApp, Instagram, Facebook), unparalleled user data for targeting, and network effects.",
        "peer_group": ["GOOG", "AMZN", "MSFT"],
        "critical_factors": ["Ad pricing and volume growth", "Apple iOS privacy changes and tracking restrictions", "Reality Labs losses and metaverse ROI"],
        "key_risks": ["Regulatory scrutiny on data privacy and market power", "TikTok competition for Gen Z engagement", "Reality Labs losses continuing to drag profitability"],
        "valuation_method": "DCF + EV/Revenue",
        "catalysts": [
            ("AI Advertising Optimization Results", "Quarterly"),
            ("Reality Labs Breakeven Timeline", "2027+"),
            ("Regulatory Action (App Store, Privacy)", "Ongoing"),
        ],
    },
    "AMZN": {
        "description": "Amazon is a diversified technology and retail conglomerate with e-commerce, cloud computing (AWS), and advertising divisions. AWS is the dominant cloud provider generating substantial margins.",
        "business_lines": [
            ("AWS (Cloud Services)", 16, "Infrastructure, databases, compute, analytics for enterprise"),
            ("Online Stores (Retail)", 55, "Third-party and first-party e-commerce marketplace"),
            ("Advertising", 12, "Sponsored product listings and ad network"),
            ("Physical Stores & Other", 17, "Whole Foods, cashier-less stores, logistics"),
        ],
        "mission": "To be Earth's most customer-centric company.",
        "competitive_advantage": "AWS dominance (~30%+ cloud market share), massive retail network, advertising growth, AI integration, and scale economies.",
        "peer_group": ["MSFT", "GOOG", "COST"],
        "critical_factors": ["AWS margin maintenance vs. competition", "Advertising acceleration and monetization", "AI capabilities and competitive response from Azure"],
        "key_risks": ["Competitive pressure from Microsoft Azure and Google Cloud", "Antitrust scrutiny on marketplace practices", "Advertising slowing if economic downturn persists"],
        "valuation_method": "DCF + EV/Revenue",
        "catalysts": [
            ("AWS Margin Expansion", "Quarterly"),
            ("Advertising Growth Acceleration", "Q2-Q3 2026"),
            ("AI Infrastructure Investments ROI", "2026-2027"),
        ],
    },
    "HD": {
        "description": "The Home Depot is the world's largest home improvement retailer with a network of ~2,300 stores. Core business is DIY and professional customer sales of building materials and tools.",
        "business_lines": [
            ("Lumber & Building Materials", 45, "Wood products, drywall, roofing, insulation"),
            ("Hardlines (Tools, Hardware, Plumbing)", 35, "Power tools, hand tools, fasteners, plumbing supplies"),
            ("Seasonal & Décor", 15, "Outdoor furniture, lighting, seasonal items"),
            ("Services (Installation, Rentals)", 5, "Tool rental, installation services, delivery"),
        ],
        "mission": "To help customers achieve their home improvement dreams.",
        "competitive_advantage": "Largest retail footprint, best-in-class supply chain, professional customer relationships, and brand loyalty.",
        "peer_group": ["LOW", "COST"],
        "critical_factors": ["Housing starts and home improvement spending", "DIY penetration and adoption rates", "Lumber pricing and supply chain cost"],
        "key_risks": ["Economic slowdown reducing discretionary home improvement", "Rising labor costs for delivery and services", "Competitive intensity from online (Amazon, Wayfair)"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Housing Cycle Inflection", "H2 2026-2027"),
            ("Professional Customer Growth", "Quarterly"),
            ("Digital & Omnichannel Expansion", "Ongoing"),
        ],
    },
    "TJX": {
        "description": "TJX Companies operates off-price retail chains (TJ Maxx, Marshalls, HomeGoods). Focus on discounted branded apparel, home goods, and accessories at 20-60% below department store prices.",
        "business_lines": [
            ("TJ Maxx & Marshalls (Apparel)", 70, "Off-price fashion, accessories, home goods"),
            ("HomeGoods & TJX Home", 20, "Discounted home décor and furnishings"),
            ("International (TK Maxx, Winners)", 10, "European and Canadian off-price retail"),
        ],
        "mission": "To deliver great values to customers and strong returns to shareholders.",
        "competitive_advantage": "Proven off-price model with real estate flexibility, vendor relationships for inventory sourcing, operational efficiency, and value positioning.",
        "peer_group": ["TM", "COST", "RH"],
        "critical_factors": ["Consumer discretionary spending and traffic", "Real estate economics and lease renewals", "Brand vendor relationships and inventory sourcing"],
        "key_risks": ["Economic downturn reducing discretionary purchases", "Wage inflation pressuring margins", "Retail shift to e-commerce undermining foot traffic"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Real Estate Productivity Improvements", "Quarterly"),
            ("International Market Expansion", "2026+"),
            ("E-commerce Channel Growth", "Ongoing"),
        ],
    },
    "COST": {
        "description": "Costco is the world's second-largest retailer operating membership-based warehouse clubs. Model emphasizes low prices, bulk purchases, and high-margin private label (Kirkland Signature).",
        "business_lines": [
            ("Merchandise Sales", 95, "Bulk groceries, electronics, household items, and Kirkland Signature private label"),
            ("Membership Fees", 5, "Gold Star and Executive membership renewals"),
        ],
        "mission": "To continually provide members with quality goods and services at the lowest possible prices.",
        "competitive_advantage": "High customer loyalty (90%+ renewal rates), operational efficiency, private label penetration, and scale in purchasing.",
        "peer_group": ["WMT", "TM", "AMZN"],
        "critical_factors": ["Membership renewal rates and fee increases", "Private label penetration growth", "Same-store sales and inflation pass-through"],
        "key_risks": ["E-commerce competition reducing warehouse visits", "Wage inflation and competitive labor market", "Margin compression from deflationary pressures"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Membership Fee Increase (September)", "2026-2027"),
            ("International Expansion Progress", "Ongoing"),
            ("Same-Store Sales Acceleration", "Quarterly"),
        ],
    },
    "CVX": {
        "description": "Chevron is an integrated oil and gas company with upstream exploration, midstream pipelines, and downstream refining. Global operations span Africa, Southeast Asia, the Americas, and Australia.",
        "business_lines": [
            ("Upstream (Oil & Gas Exploration)", 60, "Crude oil, natural gas production worldwide"),
            ("Downstream (Refining & Retail)", 30, "Refining capacity, fuel retail, base oils"),
            ("Midstream & Other", 10, "Pipelines, chemicals, geothermal"),
        ],
        "mission": "To be the most trusted energy company for delivering reliable, affordable, and lower-carbon energy.",
        "competitive_advantage": "Large resource base, advanced technology, integrated value chain, and capital discipline.",
        "peer_group": ["XOM", "COP", "MPC"],
        "critical_factors": ["Oil and gas price realization", "Energy transition and renewable investments", "Capital discipline and shareholder returns"],
        "key_risks": ["Oil price volatility below breakeven", "Renewable energy transition reducing fossil demand", "Geopolitical disruption to supply"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Hydrogen and CCUS Investment Results", "2027+"),
            ("Oil Price Support from Supply Deficit", "Ongoing"),
            ("Dividend Growth Announcements", "Annually"),
        ],
    },
    "AON": {
        "description": "Aon is a global professional services company in insurance brokerage, risk management, and human capital consulting. Major segments include commercial risk solutions, health and benefits, and retirement solutions.",
        "business_lines": [
            ("Commercial Risk Solutions", 45, "Insurance brokerage, risk placement, management liability"),
            ("Health Solutions", 30, "Health and benefits consulting, employer insurance"),
            ("Retirement Solutions", 20, "Pension consulting, asset management, investment solutions"),
            ("Data and Analytic Services", 5, "Risk assessment and analytics platform"),
        ],
        "mission": "To shape the future of risk, retirement, and health through innovative technology and data insights.",
        "competitive_advantage": "Market leadership in advisory, global distribution network, data analytics capabilities, and integrated service offerings.",
        "peer_group": ["MMC", "AFSI", "WR"],
        "critical_factors": ["Insurance broker commissions and placement volumes", "Retention and organic growth in client base", "Technology and data platform investments ROI"],
        "key_risks": ["Economic downturn reducing insurance placement activity", "Competitive pricing pressure", "Technology transformation execution risk"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Insurance Placement Volumes Growth", "Quarterly"),
            ("Data Analytics Platform Adoption", "Ongoing"),
            ("M&A Opportunities", "Intermittent"),
        ],
    },
    "BAC": {
        "description": "Bank of America is the second-largest US bank with consumer banking, commercial banking, and wealth management divisions. Merrill Lynch is a major wealth management platform.",
        "business_lines": [
            ("Consumer Banking", 40, "Checking, savings, mortgages, auto loans"),
            ("Commercial Banking", 30, "Business loans, cash management, trade finance"),
            ("Wealth Management (Merrill Lynch)", 25, "Asset management, brokerage, financial advisory"),
            ("Investment Banking & Markets", 5, "Underwriting, trading, capital markets"),
        ],
        "mission": "To provide financial services that enable growth and economic progress.",
        "competitive_advantage": "Large deposit base, branch network, Merrill Lynch brand, and integrated service platform.",
        "peer_group": ["JPM", "WFC", "C"],
        "critical_factors": ["Net interest margin (NIM) and rate environment", "Wealth management asset growth", "Credit quality and loan loss provisions"],
        "key_risks": ["Interest rate cuts compressing NIM", "Economic recession increasing loan losses", "Regulatory capital and dividend restrictions"],
        "valuation_method": "P/B + P/E",
        "catalysts": [
            ("Interest Rate Cycle Inflection", "H2 2026+"),
            ("Merrill Lynch Organic Growth", "Quarterly"),
            ("Buyback Announcements", "Annually"),
        ],
    },
    "JPM": {
        "description": "JPMorgan Chase is the largest US bank with comprehensive consumer, commercial, and investment banking operations. Market leader in investment banking and capital markets.",
        "business_lines": [
            ("Consumer & Community Banking", 45, "Deposits, mortgages, credit cards, auto loans"),
            ("Corporate & Investment Bank", 35, "Underwriting, trading, advisory, capital markets"),
            ("Asset & Wealth Management", 20, "Investment advisory, asset management, private banking"),
        ],
        "mission": "To serve our clients and communities responsibly by supporting the financial security and economic progress.",
        "competitive_advantage": "Largest investment banking platform, premier trading capabilities, diversified revenue streams, and strong capital position.",
        "peer_group": ["BAC", "GS", "WFC"],
        "critical_factors": ["Investment banking deal volume and fees", "Trading revenue volatility", "NIM and deposit growth"],
        "key_risks": ["Economic slowdown reducing deal activity and loan growth", "Interest rate environment compression", "Regulatory capital constraints limiting buybacks"],
        "valuation_method": "P/B + P/E",
        "catalysts": [
            ("M&A Activity and IPO Rebound", "H2 2026+"),
            ("Capital Return Announcements", "Annually"),
            ("Rate Cut Cycle Impact", "Ongoing"),
        ],
    },
    "MA": {
        "description": "Mastercard is a global payment network operator facilitating digital commerce. Primary revenue from interchange fees and service fees on trillions of transaction volume.",
        "business_lines": [
            ("Service Revenues (Transaction Processing)", 50, "Processing fees on card transactions"),
            ("Data & Services", 25, "Analytics, fraud prevention, consulting services"),
            ("Network & Other Fees", 15, "Card issuance, gateway services"),
            ("International", 10, "Cross-border and emerging market growth"),
        ],
        "mission": "To connect the world and drive commerce forward by delivering exceptional value.",
        "competitive_advantage": "Global payment network with nearly 2.8B cards, pricing power from duopoly with Visa, high switching costs, and data analytics.",
        "peer_group": ["V", "AXP", "DFS"],
        "critical_factors": ["Payment volume growth and pricing", "Cross-border transaction growth", "Digital payment penetration (buy now pay later, etc.)"],
        "key_risks": ["Regulatory pressure on interchange fees", "Economic downturn reducing transaction volumes", "Fintech competition and disintermediation"],
        "valuation_method": "DCF + P/E",
        "catalysts": [
            ("Emerging Market Growth Acceleration", "Ongoing"),
            ("BNPL and Digital Wallet Adoption", "Quarterly"),
            ("Buyback Authorization and Execution", "Ongoing"),
        ],
    },
    "SPGI": {
        "description": "S&P Global is a leading provider of transparent and independent ratings, benchmarks, analytics, and data. Core segments include ratings (S&P Global Ratings), market intelligence, and indices.",
        "business_lines": [
            ("Ratings", 45, "Credit ratings on corporate, sovereign, municipal debt"),
            ("Market Intelligence", 35, "Data, analytics, intelligence for capital markets"),
            ("S&P Dow Jones Indices", 15, "Index calculation, licensing, and related services"),
            ("Platts & Other", 5, "Energy and commodity price benchmarks"),
        ],
        "mission": "To provide trusted intelligence that helps capital markets function more efficiently.",
        "competitive_advantage": "Market leadership in ratings with Moody's, essential index provider (S&P 500), switching costs in data subscriptions.",
        "peer_group": ["MCO", "IEX", "FactSet"],
        "critical_factors": ["Debt issuance volume (corporate, government bonds)", "AUM growth in passively managed index funds", "Regulatory oversight of ratings agencies"],
        "key_risks": ["Regulatory scrutiny on rating conflicts of interest", "Economic slowdown reducing debt issuance", "Competition from alternative data providers"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Debt Market Activity Rebound", "H2 2026+"),
            ("Index Fund Growth and Licensing", "Ongoing"),
            ("Market Intelligence Organic Growth", "Quarterly"),
        ],
    },
    "JNJ": {
        "description": "Johnson & Johnson is a diversified healthcare conglomerate with pharmaceuticals, medical devices, and consumer health divisions. 2023 spin-off separated consumer health (Kenvue).",
        "business_lines": [
            ("Pharmaceuticals", 50, "Prescription drugs: oncology, immunology, cardiovascular"),
            ("Medical Devices", 45, "Surgical instruments, orthopedics, diagnostics"),
            ("Consumer Health (Post-Spin)", 5, "Minor remaining consumer products"),
        ],
        "mission": "To foresee and fulfill needs, to apply our talents and resources to achieve it, for the lasting benefit of humanity.",
        "competitive_advantage": "Diversified pharma and medtech portfolios, global distribution, R&D capabilities, brand value, and pricing power.",
        "peer_group": ["PFE", "ABBV", "MRK"],
        "critical_factors": ["Blockbuster drug patent expirations and exclusivity", "New drug pipeline approvals and commercialization", "Medtech pricing and adoption"],
        "key_risks": ["Drug patent cliffs reducing revenue", "Regulatory price controls in pharma", "Litigation and product liability risks"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("New Drug Approvals (Oncology, Immunology)", "2026-2027"),
            ("Dividend Growth Announcements", "Annually"),
            ("M&A and Licensing Deals", "Intermittent"),
        ],
    },
    "SYK": {
        "description": "Stryker Corporation is a leading medical device company focused on orthopedic implants, surgical equipment, and neurotechnology. Growth driven by aging populations and procedural volume recovery.",
        "business_lines": [
            ("Orthopedics", 35, "Joint replacement implants, trauma, spine"),
            ("Surgical Instruments & Endoscopy", 40, "Surgical tools, endoscopes, OR equipment"),
            ("Neurotechnology & Spine", 15, "Spine, neurosurgery, brain-related devices"),
            ("Other", 10, "Patient safety, optimization platforms"),
        ],
        "mission": "To focus on customer needs by providing technology for medical applications and services.",
        "competitive_advantage": "Market leadership in orthopedics and surgical instruments, scale, innovation in robotics-assisted surgery (Mako), and consolidation strategy.",
        "peer_group": ["ISRG", "ZIMV", "NUVA"],
        "critical_factors": ["Orthopedic procedure volumes and pricing", "Spine and neuro growth", "Mako robotic platform adoption"],
        "key_risks": ["Healthcare pricing pressure and reimbursement reform", "Competition from smaller innovators", "Acquisition integration execution risk"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Mako Robotics Adoption Acceleration", "Quarterly"),
            ("Neurotech Pipeline Milestones", "2026-2027"),
            ("M&A and Consolidation Deals", "Intermittent"),
        ],
    },
    "UNH": {
        "description": "UnitedHealth Group is the largest health insurer and healthcare services provider in the US. Dual business model of insurance (UnitedHealthcare) and health services (Optum).",
        "business_lines": [
            ("UnitedHealthcare (Insurance)", 50, "Medical, dental, vision insurance coverage"),
            ("Optum (Health Services & Tech)", 45, "PBM, care delivery, health IT, data analytics"),
            ("Other", 5, "Investment and miscellaneous revenue"),
        ],
        "mission": "To help people live healthier lives and help make health care work better.",
        "competitive_advantage": "Largest integrated health insurance and services platform, Optum PBM dominance, data analytics, and scale economies.",
        "peer_group": ["HUM", "CI", "AEP"],
        "critical_factors": ["Medical loss ratio (MLR) and insurance margins", "Optum organic growth and PBM volumes", "Regulatory environment (antitrust, pricing)"],
        "key_risks": ["Antitrust scrutiny on vertical integration (Optum/UnitedHealthcare)", "Medical cost inflation", "Government payment rate pressure (Medicare, Medicaid)"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Optum Health Services Growth", "Quarterly"),
            ("PBM Pricing and Volume", "Ongoing"),
            ("Government Payment Updates", "Annually"),
        ],
    },
    "HON": {
        "description": "Honeywell International is a diversified conglomerate with aerospace, building technologies, and industrial automation divisions. Benefits from aerospace recovery and building energy efficiency trends.",
        "business_lines": [
            ("Aerospace Systems", 35, "Commercial and defense aviation equipment, space systems"),
            ("Building Solutions (HVAC, Controls)", 35, "Smart building technologies, fire safety, security"),
            ("Performance Materials", 20, "Advanced chemicals, specialty materials"),
            ("Other", 10, "Industrial automation, energy transition"),
        ],
        "mission": "To create technologies that address global megatrends and foster sustainable growth.",
        "competitive_advantage": "Aerospace OEM relationships, building automation software, diversification, and operational excellence.",
        "peer_group": ["UTX", "BA", "GE"],
        "critical_factors": ["Commercial aerospace production rates recovery", "Building energy efficiency demand", "Industrial margin expansion"],
        "key_risks": ["Aerospace supply chain delays", "Building technology adoption rate slowing", "Economic downturn reducing industrial demand"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Boeing Production Ramp", "H2 2026+"),
            ("Building Tech Software Adoption", "Quarterly"),
            ("Industrial Efficiency Drive", "Ongoing"),
        ],
    },
    "RTX": {
        "description": "RTX Corporation (formerly Raytheon Technologies) is a major aerospace and defense contractor post-merger. Owns Pratt & Whitney (engines), Collins Aerospace (systems), and Raytheon (defense missiles).",
        "business_lines": [
            ("Pratt & Whitney (Engines)", 25, "Commercial and military aircraft engines"),
            ("Collins Aerospace (Systems)", 40, "Avionics, interiors, mechanical systems, controls"),
            ("Raytheon Intelligence & Space", 20, "Missiles, space systems, sensors, defense electronics"),
            ("Other", 15, "Integrated defense electronics, cybersecurity"),
        ],
        "mission": "To protect the safety of the world and the people in it, while creating a sustainable future.",
        "competitive_advantage": "Dominant position in aerospace supply, integrated platform, customer relationships with US military and airlines.",
        "peer_group": ["BA", "LMT", "GD"],
        "critical_factors": ["Commercial aerospace recovery and build rates", "Defense budget growth", "Supply chain stability"],
        "key_risks": ["P&W engine reliability issues (production), costs, recalls", "Defense budget cycles and sequestration", "Commercial aircraft production delays"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("P&W Production Rate Increases", "2026-2027"),
            ("Defense Budget Growth", "Annually"),
            ("Supply Chain Normalization", "Ongoing"),
        ],
    },
    "UNP": {
        "description": "Union Pacific is the largest western US railroad transporting freight and intermodal cargo across western North America. Essential supply chain infrastructure for industrial economy.",
        "business_lines": [
            ("Freight (Bulk, Intermodal, Automotive)", 85, "Coal, grain, containers, automobiles, chemicals"),
            ("Passenger (Amtrak subsidies)", 10, "Long-distance and regional passenger service"),
            ("Logistics & Other", 5, "Final-mile delivery, logistics optimization"),
        ],
        "mission": "To safely and reliably deliver the freight and energy products that America depends on.",
        "competitive_advantage": "Largest western network, scale, operational efficiency, and critical supply chain role.",
        "peer_group": ["CSX", "KSU", "CNI"],
        "critical_factors": ["Freight volumes (coal declining, containers growing)", "Operating ratio and cost efficiency", "Fuel and labor costs"],
        "key_risks": ["Coal demand decline and volume shift", "Economic downturn reducing freight demand", "Labor cost inflation"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Intermodal and Automotive Volume Recovery", "Quarterly"),
            ("Operating Ratio Improvements", "Ongoing"),
            ("Technology Efficiency Gains", "Quarterly"),
        ],
    },
    "XYL": {
        "description": "Xylem is a water technology company providing pumping, treatment, and digital solutions for water and wastewater infrastructure. Benefits from aging infrastructure spending and climate resilience.",
        "business_lines": [
            ("Water Infrastructure (Pumps, Systems)", 60, "Centrifugal pumps, water treatment, mechanical solutions"),
            ("Applied Water (Residential, Commercial)", 25, "Faucets, showers, flow controls, treatment systems"),
            ("Sensus (Smart Metering, Digital)", 15, "Water meters, analytics, IoT solutions"),
        ],
        "mission": "To accelerate the global transition to a more sustainable world by solving critical water challenges.",
        "competitive_advantage": "Market leadership in water infrastructure, diversified product portfolio, digital transformation, and recurring revenue from software/services.",
        "peer_group": ["ITT", "AWK", "LNN"],
        "critical_factors": ["Government infrastructure spending (IIJA)", "Digital adoption (smart meters, analytics)", "Organic replacement and residential growth"],
        "key_risks": ["Delayed government infrastructure funding", "Competition from established infrastructure peers", "Supply chain costs for materials"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Infrastructure Bill Implementation", "2026-2027"),
            ("Digital Solutions Adoption", "Quarterly"),
            ("M&A Opportunities in Water Tech", "Intermittent"),
        ],
    },
    "APH": {
        "description": "Amphenol is a global leader in electronic connectors and sensors used in automotive, aerospace, telecom, and data center applications. High-frequency and harsh environment specialization.",
        "business_lines": [
            ("Automotive", 30, "Connectors and sensors for vehicle electrification"),
            ("Broadband Communications (Telecom, Data)", 35, "High-speed connectors, fiber optics, data center"),
            ("Industrial & Commercial", 20, "Sensors, power distribution, industrial controls"),
            ("Aerospace, Defense & Communications", 15, "Military, aerospace, and harsh environment connectors"),
        ],
        "mission": "To be the preferred global manufacturer and provider of high-quality interconnect solutions.",
        "competitive_advantage": "Scale, diversified end markets, automotive electrification exposure, data center growth, and manufacturing excellence.",
        "peer_group": ["TE", "FLR", "SLB"],
        "critical_factors": ["Automotive electrification adoption", "Data center capex cycle", "Telecom infrastructure investment"],
        "key_risks": ["Automotive demand cyclicality", "Geopolitical supply chain disruption", "Competition from lower-cost producers"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("EV Production Ramp", "Quarterly"),
            ("Data Center Connector Demand", "Ongoing"),
            ("Acquisition Integration", "Periodic"),
        ],
    },
    "AAPL": {
        "description": "Apple designs and sells premium consumer electronics: iPhone smartphones, Mac computers, wearables, and services. Services (App Store, iCloud, Apple Music) now represent 20%+ of revenue.",
        "business_lines": [
            ("iPhone", 50, "Smartphones (primary source of revenue and ecosystem lock-in)"),
            ("Services (App Store, iCloud, Music)", 22, "Digital services and recurring revenue"),
            ("Mac & iPad", 15, "Personal computers and tablets"),
            ("Wearables, Home & Accessories", 13, "Apple Watch, AirPods, HomePod, Apple TV"),
        ],
        "mission": "To create products that enrich lives and enable human potential.",
        "competitive_advantage": "Ecosystem lock-in, brand loyalty, vertical integration, retail presence, and services growth.",
        "peer_group": ["MSFT", "GOOG", "NVDA"],
        "critical_factors": ["iPhone unit sales and ASP (average selling price)", "Services growth and margins", "China revenue exposure"],
        "key_risks": ["iPhone replacement cycle slowdown", "Geopolitical risk (Taiwan manufacturing, China market)", "Antitrust scrutiny on App Store"],
        "valuation_method": "DCF + EV/Revenue",
        "catalysts": [
            ("New iPhone Releases (AI Features)", "September 2026"),
            ("Services Growth Acceleration", "Quarterly"),
            ("M&A in AI and Health Tech", "Intermittent"),
        ],
    },
    "AVGO": {
        "description": "Broadcom is a leading semiconductor and infrastructure software company. Primary focus on networking, broadband infrastructure, and switching for data centers and telecom.",
        "business_lines": [
            ("Infrastructure Software", 25, "VMware (cloud management), cybersecurity, automation"),
            ("Broadband & Connectivity", 35, "Ethernet switches, WiFi, 5G infrastructure"),
            ("Carrying Edge & Optical", 20, "High-speed optical interconnect for data centers"),
            ("Other Semiconductors", 20, "Processors, custom chips, security"),
        ],
        "mission": "To deliver innovative infrastructure software and semiconductor solutions that unlock value for data center, telecom, and enterprise customers.",
        "competitive_advantage": "Data center switching dominance, high-speed chip design, software platform integration post-VMware, and customer switching costs.",
        "peer_group": ["NVDA", "AMD", "QCOM"],
        "critical_factors": ["Data center AI accelerator switch adoption", "VMware integration and software revenue", "Telecom 5G infrastructure spending"],
        "key_risks": ["Data center capex slowdown", "VMware integration execution", "Competition from new entrants in AI chips"],
        "valuation_method": "DCF + EV/Revenue",
        "catalysts": [
            ("AI Data Center Switch Ramp", "Quarterly"),
            ("VMware Revenue Synergies", "2026-2027"),
            ("5G Infrastructure Buildout", "Ongoing"),
        ],
    },
    "MSFT": {
        "description": "Microsoft is a cloud and software giant with Azure cloud computing, Office 365 productivity software, Windows operating system, and gaming (Xbox). Major AI integrations through Copilot and OpenAI partnership.",
        "business_lines": [
            ("Intelligent Cloud (Azure, SQL, Dynamics)", 40, "Cloud infrastructure, databases, enterprise software"),
            ("Productivity & Business Processes (Office 365)", 35, "Productivity software, collaboration tools, CRM"),
            ("More Personal Computing (Windows, Gaming)", 25, "Windows OS, PC sales, Xbox, gaming content"),
        ],
        "mission": "To empower every person and every organization on the planet to achieve more.",
        "competitive_advantage": "Azure cloud dominance, Office 365 enterprise lock-in, Windows incumbency, OpenAI partnership, and AI/Copilot integration.",
        "peer_group": ["GOOG", "AMZN", "ORCL"],
        "critical_factors": ["Azure growth and pricing power", "Office 365 cloud transition", "AI Copilot monetization success"],
        "key_risks": ["Cloud competitive intensity from AWS, GCP", "Regulatory scrutiny on market dominance", "Enterprise software saturation"],
        "valuation_method": "DCF + EV/Revenue",
        "catalysts": [
            ("AI Copilot Adoption and Monetization", "Quarterly"),
            ("Azure AI Infrastructure Demand", "Quarterly"),
            ("Enterprise Software M&A", "Intermittent"),
        ],
    },
    "NVDA": {
        "description": "NVIDIA is the dominant GPU chip designer powering AI/ML workloads, data centers, and gaming. CUDA software ecosystem creates powerful switching costs and competitive moat.",
        "business_lines": [
            ("Data Center (AI/ML GPUs)", 90, "GPUs for training and inference, AI accelerators"),
            ("Gaming (Gaming GPUs)", 8, "GeForce gaming GPUs and gaming platforms"),
            ("Professional Visualization", 2, "Workstation GPUs for design and visualization"),
        ],
        "mission": "To accelerate AI computing and graphics for humanity.",
        "competitive_advantage": "AI GPU market dominance, CUDA software ecosystem lock-in, process technology leadership, and data center customer concentration.",
        "peer_group": ["AMD", "QCOM", "TSM"],
        "critical_factors": ["AI data center capex cycle sustainability", "GPU supply constraint resolution", "CUDA moat maintenance vs. new competitors"],
        "key_risks": ["AI capex cycle slowdown or plateau", "Competition from AMD, Intel, custom ASICs", "China export restrictions on advanced chips"],
        "valuation_method": "DCF + EV/Revenue",
        "catalysts": [
            ("Data Center GPU Supply Increases", "Quarterly"),
            ("New AI Model Architectures and Demand", "Ongoing"),
            ("Gaming & Professional Segment Growth", "Quarterly"),
        ],
    },
    "PANW": {
        "description": "Palo Alto Networks is a leading cloud security platform company providing endpoint protection, cloud security, threat intelligence, and security analytics to enterprises.",
        "business_lines": [
            ("Cloud Security (Prisma, Cortex)", 35, "Cloud-native security, workload protection"),
            ("Endpoint Security (Traps, Cortex XDR)", 30, "Endpoint detection and response (EDR), threat hunting"),
            ("Network Security (Firewalls, GigaVisions)", 20, "Next-gen firewalls, DDoS protection, secure access"),
            ("Security Services & Other", 15, "Threat intelligence, incident response, managed services"),
        ],
        "mission": "To protect every cloud, endpoint, and network in the world.",
        "competitive_advantage": "Integrated security platform, threat intelligence moat, customer lock-in, and rapid innovation in cloud/AI security.",
        "peer_group": ["CrowdStrike", "ZS", "NET"],
        "critical_factors": ["Cloud security adoption and platform consolidation", "Endpoint threat detection and XDR adoption", "Subscription revenue growth"],
        "key_risks": ["Customer churn from competitive pressure (CrowdStrike, Microsoft)", "Product consolidation slowing growth", "Valuation multiple compression"],
        "valuation_method": "DCF + EV/Revenue",
        "catalysts": [
            ("Cloud Security Platform Adoption", "Quarterly"),
            ("XDR Consolidation Progress", "Quarterly"),
            ("GenAI Integration in Security", "2026+"),
        ],
    },
    "NOW": {
        "description": "ServiceNow is an enterprise workflow and IT service management SaaS platform. Primary use cases: IT service management, ITSM, HRSD, customer service management (CSM), and enterprise applications.",
        "business_lines": [
            ("IT Workflows (ITSM, ITOM)", 45, "IT Service Management, IT Operations Management"),
            ("Enterprise Workflows (HRSD, CSM)", 35, "HR Service Delivery, Customer Service Management"),
            ("Creator & Other Applications", 15, "Low-code app development, industry-specific solutions"),
            ("Professional Services & Other", 5, "Consulting services revenue"),
        ],
        "mission": "To empower enterprises with the intelligent cloud to transform their business.",
        "competitive_advantage": "Market leadership in ITSM, broad workflow platform, customer relationships, and strong NPS with high switching costs.",
        "peer_group": ["CRWD", "ZS", "ADBE"],
        "critical_factors": ["Platform adoption and consolidation", "Remaining Performance Obligations (RPO) growth", "AI/GenAI integration success"],
        "key_risks": ["Customer churn from macro slowdown", "Platform adoption slowdown", "Competition from Salesforce, Microsoft"],
        "valuation_method": "DCF + EV/Revenue",
        "catalysts": [
            ("Now Platform Adoption Growth", "Quarterly"),
            ("RPO Growth and Upsell", "Quarterly"),
            ("AI Workflow Automation", "2026+"),
        ],
    },
    "ECL": {
        "description": "Ecolab is a global provider of water treatment, hygiene, and infection prevention solutions for industrial and commercial customers. Benefits from food safety, healthcare, and sustainability trends.",
        "business_lines": [
            ("Water, Hygiene & Energy (Industrial)", 60, "Industrial water treatment, hygiene products, cleaning"),
            ("Food & Beverage", 20, "Food safety, sanitation, process optimization"),
            ("Healthcare & Life Sciences", 15, "Infection prevention, sterilization, diagnostics"),
            ("Other", 5, "Pest elimination, product care"),
        ],
        "mission": "To protect people and vital resources with innovative and sustainable solutions.",
        "competitive_advantage": "Scale, customer relationships in food service and healthcare, technology in water treatment, and recurring revenue model.",
        "peer_group": ["ALB", "DD", "MMM"],
        "critical_factors": ["Foodservice and hospitality recovery", "Healthcare infection prevention spending", "Water treatment pricing and volumes"],
        "key_risks": ["Economic downturn reducing foodservice/hospitality volumes", "Commodity chemical price inflation", "Regulatory pressure on chemical use"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Foodservice Volume Recovery", "Quarterly"),
            ("Healthcare Hygiene Spending", "Ongoing"),
            ("Water Treatment Innovation", "Periodic"),
        ],
    },
    "NEE": {
        "description": "NextEra Energy is a utility and renewable energy company with Florida Power & Light (FPL utility) and NextEra Energy Resources (NEER renewables). Largest producer of wind and solar power in the US.",
        "business_lines": [
            ("Florida Power & Light (Utility)", 50, "Regulated electric utility serving Florida, rates and reliability focus"),
            ("NextEra Energy Resources (NEER)", 40, "Wind power, solar power, battery storage development"),
            ("Corporate & Other", 10, "Financing, corporate costs, other revenues"),
        ],
        "mission": "To create long-term shareholder value with a cleaner energy future.",
        "competitive_advantage": "Scale in renewable generation, FPL regulated utility cash flows, state-driven renewable requirements, and project development pipeline.",
        "peer_group": ["DUK", "SO", "EXC"],
        "critical_factors": ["Renewable energy build-out pace", "FPL rate case approvals and returns", "Energy storage adoption growth"],
        "key_risks": ["Interest rate impacts on renewables capex returns", "Regulatory headwinds on utility returns", "Battery storage technology cost/risk"],
        "valuation_method": "DCF + EV/EBITDA",
        "catalysts": [
            ("Renewable Energy Build-Out Progress", "Quarterly"),
            ("FPL Rate Case Approvals", "2026+"),
            ("Battery Storage Deployment", "Ongoing"),
        ],
    },

}


def get_profile(ticker: str) -> dict:
    """Return company profile or a default placeholder if not configured."""
    return COMPANY_PROFILES.get(ticker, {
        "description": f"Profile not yet configured for {ticker}.",
        "business_lines": [],
        "mission": "",
        "competitive_advantage": "",
        "peer_group": [],
        "critical_factors": [],
        "key_risks": [],
        "valuation_method": "DCF (default)",
        "catalysts": [],
    })

