"""
US Focus List -- 28 tickers.
Usage: python main.py --mandate us_focus
"""
from config.settings import PORTFOLIO_US
PORTFOLIO = PORTFOLIO_US

