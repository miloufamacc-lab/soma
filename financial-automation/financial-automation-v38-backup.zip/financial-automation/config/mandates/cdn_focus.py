"""
Canadian Focus List -- 28 tickers.
Usage: python main.py --mandate cdn_focus
"""
from config.settings import PORTFOLIO_CDN
PORTFOLIO = PORTFOLIO_CDN

