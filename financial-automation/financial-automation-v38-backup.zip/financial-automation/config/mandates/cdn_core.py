"""
Canadian Core Mandate -- default portfolio.
"""

PORTFOLIO = [
    ("DOLLARAMA",                  "DLMAF",  "D106280",  "Consumer Discretionary", "Medium"),
    ("ALIMENTATION COUCHE TARD",   "ANCTF",  "A059441",  "Consumer Staples",       "Medium"),
    ("LOBLAW COMPANIES LTD",       "LBLCF",  "L495002",  "Consumer Staples",       "Medium"),
    ("PEMBINA PIPELINE CORP",      "PBA",    "P026694",  "Energy",                 "Medium"),
    ("SUNCOR ENERGY INC",          "SU",     "S113614",  "Energy",                 "Medium"),
    ("TC ENERGY CORP",             "TRP",    "T039498",  "Energy",                 "Medium"),
    ("BANK OF MONTREAL",           "BMO",    "B090907",  "Financials",             "Medium"),
]

