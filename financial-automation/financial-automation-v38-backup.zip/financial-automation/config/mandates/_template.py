"""
Mandate Template -- copy this file and customize.
Filename becomes the mandate name (e.g., us_growth.py -> --mandate us_growth)
"""

PORTFOLIO = [
    # (Company Name, US Ticker, ADP Code, Sector, RBC Risk Rating)
    ("EXAMPLE CORP", "EXMP", "E000000", "Technology", "Medium"),
]

