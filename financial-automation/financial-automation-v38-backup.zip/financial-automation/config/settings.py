"""
Configuration settings for the Financial Data Automation System.
v3.4 -- 56 tickers (28 CDN + 28 US)
"""

# -- GuruFocus API --
GURUFOCUS_API_KEY = "1fffcdec3d409880b868e13e494f75da:ca8f3aa9e748cee652e3278188ea7538"
GURUFOCUS_BASE_URL = "https://api.gurufocus.com/public/user"

# -- Email Settings --
GMAIL_SENDER = "jacobo.pae@gmail.com"
GMAIL_APP_PASSWORD = "ywnrhicrruvkyfkt"

EMAIL_RECIPIENTS = [
    {"email": "jacobo.paez@rbc.com",   "attach_excel": True},
    {"email": "jacobo.pae@gmail.com",  "attach_excel": True},
]

SEND_TIME_ET = "07:30"

# -- Portfolio / Tickers --
# Format: (Company Name, US Ticker, ADP Code, Sector, RBC Risk Rating)

PORTFOLIO_CDN = [
    # Consumer Discretionary
    ("DOLLARAMA",                    "DLMAF",  "",  "Consumer Discretionary",  "Medium"),
    # Consumer Staples
    ("ALIMENTATION COUCHE-TARD",     "ANCTF",  "",  "Consumer Staples",        "Medium"),
    ("LOBLAW COMPANIES LTD",         "LBLCF",  "",  "Consumer Staples",        "Medium"),
    # Energy
    ("PEMBINA PIPELINE CORP",        "PBA",    "",  "Energy",                  "Medium"),
    ("SUNCOR ENERGY INC",            "SU",     "",  "Energy",                  "Medium"),
    ("TC ENERGY CORP",               "TRP",    "",  "Energy",                  "Medium"),
    # Financials
    ("BANK OF MONTREAL",             "BMO",    "",  "Financials",              "Medium"),
    ("BROOKFIELD CORP",              "BN",     "",  "Financials",              "Medium"),
    ("CANADIAN IMPERIAL BANK",       "CM",     "",  "Financials",              "Medium"),
    ("INTACT FINANCIAL",             "IFCZF",  "",  "Financials",              "Medium"),
    ("MANULIFE FINANCIAL",           "MFC",    "",  "Financials",              "Medium"),
    ("NATIONAL BANK OF CANADA",      "NTIOF",  "",  "Financials",              "Medium"),
    ("ROYAL BANK OF CANADA",         "RY",     "",  "Financials",              "Medium"),
    ("SUN LIFE FINANCIAL",           "SLF",    "",  "Financials",              "Medium"),
    ("TORONTO-DOMINION BANK",        "TD",     "",  "Financials",              "Medium"),
    # Industrials
    ("ATKINSREALIS GROUP",           "SNCAF",  "",  "Industrials",             "Medium"),
    ("BOMBARDIER CLASS B",           "BDRBF",  "",  "Industrials",             "Medium"),
    ("CANADIAN PACIFIC KANSAS CITY", "CP",     "",  "Industrials",             "Medium"),
    ("ELEMENT FLEET MANAGEMENT",     "ELEEF",  "",  "Industrials",             "Medium"),
    ("GFL ENVIRONMENTAL",            "GFL",    "",  "Industrials",             "Medium"),
    ("RB GLOBAL",                    "RBA",    "",  "Industrials",             "Medium"),
    ("TOROMONT INDUSTRIES",          "TMTNF",  "",  "Industrials",             "Medium"),
    ("WSP GLOBAL",                   "WSPOF",  "",  "Industrials",             "Medium"),
    # Information Technology
    ("CONSTELLATION SOFTWARE",       "CNSWF",  "",  "Information Technology",  "Medium"),
    ("SHOPIFY CLASS A",              "SHOP",   "",  "Information Technology",  "Medium"),
    # Materials
    ("CCL INDUSTRIES CLASS B",       "CCDBF",  "",  "Materials",               "Medium"),
    # Real Estate
    ("FIRST CAPITAL REIT",           "FCXXF",  "",  "Real Estate",             "Medium"),
    # Utilities
    ("BROOKFIELD INFRA. PARTNERS",   "BIP",    "",  "Utilities",               "Medium"),
]

PORTFOLIO_US = [
    # Communication Services
    ("ALPHABET CLASS C",             "GOOG",   "",  "Communication Services",  "Medium"),
    ("META PLATFORMS CLASS A",       "META",   "",  "Communication Services",  "Medium"),
    # Consumer Discretionary
    ("AMAZON.COM",                   "AMZN",   "",  "Consumer Discretionary",  "Medium"),
    ("HOME DEPOT",                   "HD",     "",  "Consumer Discretionary",  "Medium"),
    ("TJX COMPANIES",                "TJX",    "",  "Consumer Discretionary",  "Medium"),
    # Consumer Staples
    ("COSTCO WHOLESALE",             "COST",   "",  "Consumer Staples",        "Medium"),
    # Energy
    ("CHEVRON",                      "CVX",    "",  "Energy",                  "Medium"),
    # Financials
    ("AON CLASS A",                  "AON",    "",  "Financials",              "Medium"),
    ("BANK OF AMERICA",              "BAC",    "",  "Financials",              "Medium"),
    ("JPMORGAN CHASE & CO.",         "JPM",    "",  "Financials",              "Medium"),
    ("MASTERCARD CLASS A",           "MA",     "",  "Financials",              "Medium"),
    ("S&P GLOBAL",                   "SPGI",   "",  "Financials",              "Medium"),
    # Health Care
    ("JOHNSON & JOHNSON",            "JNJ",    "",  "Health Care",             "Medium"),
    ("STRYKER",                      "SYK",    "",  "Health Care",             "Medium"),
    ("UNITEDHEALTH GROUP",           "UNH",    "",  "Health Care",             "Medium"),
    # Industrials
    ("HONEYWELL INTERNATIONAL",      "HON",    "",  "Industrials",             "Medium"),
    ("RTX",                          "RTX",    "",  "Industrials",             "Medium"),
    ("UNION PACIFIC",                "UNP",    "",  "Industrials",             "Medium"),
    ("XYLEM",                        "XYL",    "",  "Industrials",             "Medium"),
    # Information Technology
    ("AMPHENOL CLASS A",             "APH",    "",  "Information Technology",  "Medium"),
    ("APPLE",                        "AAPL",   "",  "Information Technology",  "Medium"),
    ("BROADCOM",                     "AVGO",   "",  "Information Technology",  "Medium"),
    ("MICROSOFT",                    "MSFT",   "",  "Information Technology",  "Medium"),
    ("NVIDIA",                       "NVDA",   "",  "Information Technology",  "Medium"),
    ("PALO ALTO NETWORKS",           "PANW",   "",  "Information Technology",  "Medium"),
    ("SERVICENOW",                   "NOW",    "",  "Information Technology",  "Medium"),
    # Materials
    ("ECOLAB",                       "ECL",    "",  "Materials",               "Medium"),
    # Utilities
    ("NEXTERA ENERGY",               "NEE",    "",  "Utilities",               "Medium"),
]

# Default portfolio: combined CDN + US (56 tickers)
PORTFOLIO = PORTFOLIO_CDN + PORTFOLIO_US

# -- Financial Institution Tickers (Altman Z = 5.0 default) --
# Banks, insurers, and asset managers where Altman Z-Score is not applicable
BANK_TICKERS = {
    # Canadian banks
    "BMO", "CM", "RY", "TD", "NTIOF", "BNS", "NA", "CWB", "LB", "EQB",
    # Canadian insurers / asset managers
    "MFC", "SLF", "IFCZF", "BN",
    # US banks
    "BAC", "JPM",
}

# -- Sector-Specific Valuation Classifications --
# These determine which valuation method is used (DDM vs FCF DCF)

# Pure banks: use DDM (Dividend Discount Model) -- FCF is meaningless for banks
DDM_BANK_TICKERS = {
    "BMO", "CM", "RY", "TD", "NTIOF", "BNS", "NA", "CWB", "LB", "EQB",
    "BAC", "JPM",
}

# Insurers & asset managers: use DDM -- FCF distorted by float/AUM accounting
DDM_INSURER_TICKERS = {
    "MFC", "SLF", "IFCZF", "BN",
    "AON",    # insurance broker
}

# Payment networks & financial data: use standard DCF -- fee-based, FCF is clean
# MA, SPGI stay on standard DCF (they are not balance-sheet lenders)

# REITs: use DDM variant -- high payout ratios, FCF distorted by depreciation
REIT_TICKERS = {
    "FCXXF",  # First Capital REIT
}

# Combined set for quick "is this a DDM ticker?" check
DDM_TICKERS = DDM_BANK_TICKERS | DDM_INSURER_TICKERS | REIT_TICKERS

# -- Optionality Premium: Hyperscaler / Moonshot Tickers --
# These companies invest massively in AI, cloud, autonomous systems, and other
# ventures whose value is NOT captured in a standard FCF DCF.
# The system adds a qualitative "Optionality Premium" section to their valuation.
OPTIONALITY_TICKERS = {
    "META": {
        "label": "Meta Platforms",
        "ventures": [
            ("AI / LLM Infrastructure", "Building Llama open-source models, AI-powered ad targeting, AI agents",
             "High", "2025-2027"),
            ("Reality Labs / Metaverse", "Quest headsets, Horizon Worlds, AR glasses (Orion)",
             "Medium", "2026-2030"),
            ("Threads / Social Commerce", "Monetization of 275M+ MAU, creator economy, shops integration",
             "Medium", "2025-2026"),
        ],
        "capex_premium_pct": 0.10,  # 10% optionality premium on base DCF
    },
    "GOOG": {
        "label": "Alphabet",
        "ventures": [
            ("AI / Gemini Platform", "Gemini models, AI Overviews in Search, DeepMind breakthroughs",
             "High", "2025-2027"),
            ("Waymo (Autonomous Vehicles)", "Leading L4 robotaxi fleet, expanding to new cities",
             "High", "2026-2030"),
            ("Google Cloud + AI", "Vertex AI, TPU infrastructure, enterprise AI adoption",
             "High", "2025-2027"),
            ("Other Bets (Verily, Wing, Calico)", "Healthcare AI, drone delivery, longevity research",
             "Low", "2027+"),
        ],
        "capex_premium_pct": 0.12,
    },
    "AMZN": {
        "label": "Amazon",
        "ventures": [
            ("AWS + AI / Bedrock", "Custom chips (Trainium/Inferentia), Bedrock platform, enterprise AI",
             "High", "2025-2027"),
            ("Project Kuiper (Satellite)", "3,236-satellite constellation for global broadband",
             "Medium", "2026-2029"),
            ("Robotics / Automation", "Warehouse robots (Sparrow, Sequoia), delivery drones (Prime Air)",
             "Medium", "2025-2028"),
            ("Healthcare (One Medical, Pharmacy)", "Primary care + pharmacy disruption",
             "Medium", "2025-2027"),
        ],
        "capex_premium_pct": 0.10,
    },
    # TSLA will be added here when the user expands the portfolio
}

# -- Valuation Model Settings --
VALUATION_SCHEDULE = "weekly"
VALUATION_DAY = "Sunday"

# -- Output Paths --
import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# -- Conditional Formatting Thresholds --
ALTMAN_Z_CRITICAL = 1.81
ALTMAN_Z_WARNING = 2.99
PIOTROSKI_STRONG = 7

# ===================================================================
# v3.8 STRATEGY SECTION — append to bottom of config/settings.py
# ===================================================================

# -- v3.8: Strategy Tickers --
# High-conviction names across AI, crypto, commodities, and disruptive growth
# Format: (Company Name, Ticker, ADP Code, Sector, Risk)
STRATEGY_TICKERS = [
    # Pinned (always rows 1-2)
    ("TESLA",                        "TSLA",  "", "Consumer Discretionary",  "High"),
    ("MICROSTRATEGY",                "MSTR",  "", "Information Technology",  "High"),
    # AI / Semiconductors
    ("NVIDIA",                       "NVDA",  "", "Information Technology",  "Medium"),
    ("MICROSOFT",                    "MSFT",  "", "Information Technology",  "Medium"),
    ("BROADCOM",                     "AVGO",  "", "Information Technology",  "Medium"),
    ("ADVANCED MICRO DEVICES",       "AMD",   "", "Information Technology",  "Medium"),
    ("TAIWAN SEMICONDUCTOR",         "TSM",   "", "Information Technology",  "Medium"),
    ("DELL TECHNOLOGIES",            "DELL",  "", "Information Technology",  "Medium"),
    # AI Software / Cloud
    ("ALPHABET CLASS A",             "GOOGL", "", "Communication Services",  "Medium"),
    ("META PLATFORMS CLASS A",       "META",  "", "Communication Services",  "Medium"),
    ("AMAZON.COM",                   "AMZN",  "", "Consumer Discretionary",  "Medium"),
    ("ORACLE",                       "ORCL",  "", "Information Technology",  "Medium"),
    ("PALANTIR TECHNOLOGIES",        "PLTR",  "", "Information Technology",  "Medium"),
    ("CROWDSTRIKE HOLDINGS",         "CRWD",  "", "Information Technology",  "Medium"),
    ("NETFLIX",                      "NFLX",  "", "Communication Services",  "Medium"),
    # E-Commerce / Consumer
    ("SHOPIFY CLASS A",              "SHOP",  "", "Information Technology",  "Medium"),
    ("MERCADOLIBRE",                 "MELI",  "", "Consumer Discretionary",  "Medium"),
    ("COSTCO WHOLESALE",             "COST",  "", "Consumer Staples",        "Medium"),
    ("APPLE",                        "AAPL",  "", "Information Technology",  "Medium"),
    ("CELSIUS HOLDINGS",             "CELH",  "", "Consumer Staples",        "High"),
    # Healthcare / Robotics
    ("INTUITIVE SURGICAL",           "ISRG",  "", "Health Care",             "Medium"),
    # Energy / Utilities
    ("VISTRA CORP",                  "VST",   "", "Utilities",               "Medium"),
    ("FIRST SOLAR",                  "FSLR",  "", "Industrials",             "Medium"),
    # Financials / Crypto / Fintech
    ("COINBASE GLOBAL",              "COIN",  "", "Financials",              "High"),
    ("MASTERCARD CLASS A",           "MA",    "", "Financials",              "Medium"),
    ("SOFI TECHNOLOGIES",            "SOFI",  "", "Financials",              "High"),
    ("ROBINHOOD MARKETS",            "HOOD",  "", "Financials",              "High"),
    # Commodity ETFs (special handling — price/momentum only, no DCF)
    ("ISHARES GOLD TRUST",           "IAU",   "", "Commodity ETF",           "Low"),
    ("ISHARES COPPER & METALS ETF",  "ICOP",  "", "Commodity ETF",           "Low"),
    ("ENERGY SELECT SECTOR SPDR",    "XLE",   "", "Commodity ETF",           "Low"),
]

# Pinned tickers: always appear at top of Strategy section in this order
STRATEGY_PINNED = ["TSLA", "MSTR"]

# ETF tickers: special handling — no DCF valuation, price/momentum only
STRATEGY_ETF_TICKERS = {"IAU": "Gold", "ICOP": "Copper", "XLE": "Energy Sector"}

# API ticker remapping (display ticker -> API ticker)
STRATEGY_API_MAP = {"GOOGL": "GOOG"}

# Derived: fast-lookup set of all strategy ticker symbols
STRATEGY_TICKER_SET = {t[1] for t in STRATEGY_TICKERS}

# Tickers that appear in BOTH Strategy AND CDN/US portfolio
STRATEGY_OVERLAP = {
    "NVDA", "MSFT", "AVGO", "GOOG", "AMZN", "META", "MA", "COST", "AAPL", "SHOP",
}

# Add TSLA to optionality premium (was commented out in v3.4)
OPTIONALITY_TICKERS["TSLA"] = {
    "label": "Tesla",
    "ventures": [
        ("Full Self-Driving / Robotaxi", "L4 autonomy fleet, ride-hailing network",
         "High", "2025-2027"),
        ("Optimus Humanoid Robot", "General-purpose humanoid, factory deployment",
         "High", "2026-2030"),
        ("Energy Storage / Solar", "Megapack utility-scale, Powerwall residential, Solar Roof",
         "Medium", "2025-2028"),
        ("AI Training / Dojo", "In-house AI compute cluster, licensing potential",
         "Medium", "2026-2029"),
    ],
    "capex_premium_pct": 0.15,  # 15% optionality premium — highest conviction
}
