"""
Valuation Model Engine -- v3.6 (ARK Big Ideas + Performance)

Three valuation tracks based on company type:
  1. Standard FCF DCF -- industrials, tech, consumer, energy, materials, utilities, healthcare
  2. Dividend Discount Model (DDM) -- banks, insurers, asset managers
  3. DDM variant for REITs -- high payout ratios, FCF distorted by depreciation

Plus: sanity bounds on all methods to prevent absurd implied prices.
"""

import datetime, logging
from openpyxl.styles import Font, PatternFill
from market_tags import get_tag

logger = logging.getLogger(__name__)

# Import sector classifications
try:
    from config.settings import DDM_BANK_TICKERS, DDM_INSURER_TICKERS, REIT_TICKERS, DDM_TICKERS
except ImportError:
    DDM_BANK_TICKERS = set()
    DDM_INSURER_TICKERS = set()
    REIT_TICKERS = set()
    DDM_TICKERS = set()

try:
    from config.settings import OPTIONALITY_TICKERS
except ImportError:
    OPTIONALITY_TICKERS = {}


def _smart_cagr(realized, estimate, n):
    if not realized or not estimate or realized <= 0 or n <= 0 or estimate <= 0:
        return None
    try: return (estimate / realized) ** (1.0 / n) - 1
    except: return None


def _sanity_check(implied_price, current_price, method_name):
    """Return (clamped_price, is_meaningful) -- prevents absurd valuations."""
    if implied_price is None or current_price is None or current_price <= 0:
        return implied_price, True
    ratio = implied_price / current_price
    if ratio > 10.0 or ratio < 0.05:
        logger.warning(f"  {method_name}: implied ${implied_price:.2f} vs current ${current_price:.2f} "
                       f"(ratio {ratio:.1f}x) -- flagging as N/M (not meaningful)")
        return implied_price, False  # keep the number but flag it
    return implied_price, True


class ValuationModel:
    def __init__(self, ticker_data: dict):
        self.td = ticker_data
        self.ticker = ticker_data.get("ticker", "")
        self.company = ticker_data.get("company", "")
        self.price = ticker_data.get("price_usd")

    def _detect_method(self):
        """Determine which valuation method to use based on ticker classification."""
        t = self.ticker.upper()
        if t in DDM_BANK_TICKERS:
            return "DDM_BANK"
        elif t in DDM_INSURER_TICKERS:
            return "DDM_INSURER"
        elif t in REIT_TICKERS:
            return "DDM_REIT"
        else:
            return "FCF_DCF"

    # ========================================================================
    #  METHOD 1: STANDARD FCF DCF (unchanged from v3.4)
    # ========================================================================
    def build_dcf(self) -> dict:
        fcf = self.td.get("fcf_b") or self.td.get("cfo_b") or 1.0
        if fcf <= 0: fcf = 1.0
        n = self.td.get("est_horizon", 3) or 3

        rev_n = self.td.get("rev_est_horizon") or n
        rev_growth = _smart_cagr(self.td.get("rev_realized"), self.td.get("rev_estimate"), rev_n)
        if rev_growth is None:
            rev_growth = self.td.get("precomp_rev_growth") or 0.05

        tg = 0.025
        beta = self.td.get("beta", 1.0) or 1.0
        rf, erp = 0.042, 0.055
        coe = rf + beta * erp
        wacc = 0.70 * coe + 0.30 * 0.05 * 0.75

        projected = []
        cur = fcf
        for yr in range(1, 6):
            g = rev_growth - (rev_growth - tg) * (yr - 1) / 4
            cur *= (1 + g); projected.append(cur)

        tv = projected[-1] * (1 + tg) / (wacc - tg)
        pv_fcf = sum(f / (1 + wacc)**(i+1) for i, f in enumerate(projected))
        pv_tv = tv / (1 + wacc)**5
        ev = pv_fcf + pv_tv
        mc = self.td.get("mktcap_b", ev)
        ip = (ev / mc) * (self.price or 0) if mc and mc > 0 else None

        # Sanity check
        ip, meaningful = _sanity_check(ip, self.price, "FCF DCF")

        wr = [wacc-0.01, wacc, wacc+0.01]
        tr = [0.02, 0.025, 0.03]
        sens = {}
        for w in wr:
            for t in tr:
                if w > t:
                    v = projected[-1]*(1+t)/(w-t)
                    e = sum(f/(1+w)**(i+1) for i,f in enumerate(projected)) + v/(1+w)**5
                    s_ip = (e/mc)*(self.price or 0) if mc and mc>0 else None
                    sens[(w,t)] = s_ip

        return {"method": "FCF_DCF", "method_label": "FCF DCF",
                "starting_fcf": fcf, "revenue_growth": rev_growth, "terminal_growth": tg,
                "wacc": wacc, "cost_of_equity": coe, "beta": beta, "risk_free": rf,
                "equity_premium": erp, "projected_fcf": projected, "terminal_value": tv,
                "pv_fcf": pv_fcf, "pv_terminal": pv_tv, "enterprise_value": ev,
                "implied_price": ip, "meaningful": meaningful,
                "sensitivity": sens, "wacc_range": wr, "tg_range": tr,
                "est_horizon": n}

    # ========================================================================
    #  METHOD 2: DIVIDEND DISCOUNT MODEL (for banks, insurers, REITs)
    # ========================================================================
    def build_ddm(self) -> dict:
        """Multi-stage Dividend Discount Model.

        Stage 1 (years 1-5): Grow dividends at estimated growth rate
        Stage 2 (terminal): Gordon Growth Model at terminal growth rate
        Discount at cost of equity (NOT WACC -- equity-only model)

        For banks: DPS is the primary cash flow to shareholders
        For REITs: distributions ~ FFO, high payout ratios make DDM ideal
        For insurers: dividends + buybacks proxy for shareholder returns
        """
        method = self._detect_method()

        # ---- Inputs ----
        dps = self.td.get("div_realized")
        eps = self.td.get("eps_realized")
        price = self.price or 0

        # Determine starting dividend
        if dps and dps > 0:
            starting_dps = dps
        elif eps and eps > 0:
            # If no dividend, estimate from EPS with sector payout ratio
            if method == "DDM_REIT":
                starting_dps = eps * 0.85  # REITs pay ~85-95% of FFO
            elif method == "DDM_BANK":
                starting_dps = eps * 0.45  # Banks pay ~40-50% of earnings
            else:
                starting_dps = eps * 0.40  # Insurers ~35-45%
            logger.info(f"  DDM: No DPS for {self.ticker}, estimated from EPS: ${starting_dps:.2f}")
        else:
            # Last resort: price-based yield assumption
            if method == "DDM_REIT":
                starting_dps = price * 0.055  # ~5.5% yield
            elif method == "DDM_BANK":
                starting_dps = price * 0.04   # ~4% yield
            else:
                starting_dps = price * 0.035  # ~3.5% yield
            logger.warning(f"  DDM: No DPS/EPS for {self.ticker}, estimated from price yield: ${starting_dps:.2f}")

        # ---- Growth rate ----
        n = self.td.get("est_horizon", 3) or 3
        div_n = self.td.get("div_est_horizon") or n
        eps_n = self.td.get("eps_est_horizon") or n

        # Try dividend growth first, then EPS growth, then precomputed
        div_growth = _smart_cagr(self.td.get("div_realized"), self.td.get("div_estimate"), div_n)
        if div_growth is None:
            div_growth = _smart_cagr(self.td.get("eps_realized"), self.td.get("eps_estimate"), eps_n)
        if div_growth is None:
            div_growth = self.td.get("precomp_div_growth")
        if div_growth is None:
            div_growth = self.td.get("precomp_eps_growth")
        if div_growth is None:
            div_growth = 0.04  # conservative default

        # Cap growth rate to reasonable bounds
        div_growth = max(-0.05, min(div_growth, 0.15))

        # ---- Terminal growth ----
        if method == "DDM_REIT":
            tg = 0.020   # REITs: tied to inflation/rental growth
        elif method == "DDM_BANK":
            tg = 0.025   # Banks: nominal GDP growth proxy
        else:
            tg = 0.025   # Insurers: nominal GDP

        # ---- Cost of equity ----
        beta = self.td.get("beta", 1.0) or 1.0
        rf, erp = 0.042, 0.055
        coe = rf + beta * erp

        # Floor: cost of equity must exceed terminal growth
        if coe <= tg:
            coe = tg + 0.02
            logger.warning(f"  DDM: CoE ({coe:.1%}) floored above terminal growth ({tg:.1%})")

        # ---- Project dividends (5-year explicit period) ----
        projected_dps = []
        cur = starting_dps
        for yr in range(1, 6):
            # Linear fade from estimated growth to terminal growth
            g = div_growth - (div_growth - tg) * (yr - 1) / 4
            cur *= (1 + g)
            projected_dps.append(cur)

        # ---- Terminal value (Gordon Growth at year 5) ----
        tv = projected_dps[-1] * (1 + tg) / (coe - tg)

        # ---- Present values ----
        pv_divs = sum(d / (1 + coe)**(i+1) for i, d in enumerate(projected_dps))
        pv_tv = tv / (1 + coe)**5
        implied_price = pv_divs + pv_tv

        # Sanity check
        method_label = {"DDM_BANK": "DDM (Bank)", "DDM_INSURER": "DDM (Insurer)",
                        "DDM_REIT": "DDM (REIT)"}.get(method, "DDM")
        implied_price, meaningful = _sanity_check(implied_price, self.price, method_label)

        # ---- Sensitivity (CoE vs Terminal Growth) ----
        coe_range = [coe - 0.01, coe, coe + 0.01]
        tg_range = [tg - 0.005, tg, tg + 0.005]
        sens = {}
        for c in coe_range:
            for t in tg_range:
                if c > t:
                    s_tv = projected_dps[-1] * (1 + t) / (c - t)
                    s_pv = sum(d / (1 + c)**(i+1) for i, d in enumerate(projected_dps))
                    s_pvtv = s_tv / (1 + c)**5
                    sens[(c, t)] = s_pv + s_pvtv

        # ---- Dividend yield implied ----
        implied_yield = (starting_dps / implied_price) if implied_price and implied_price > 0 else None
        current_yield = (starting_dps / price) if price and price > 0 else None

        # ---- EPS-based cross-check (P/E sanity) ----
        pe_check = None
        if eps and eps > 0 and price > 0:
            current_pe = price / eps
            # Apply sector-average forward P/E
            if method == "DDM_BANK":
                target_pe = 11.0  # banks trade ~10-12x
            elif method == "DDM_REIT":
                target_pe = 16.0  # REITs trade ~14-18x
            else:
                target_pe = 12.0  # insurers ~10-14x
            pe_check = {"current_pe": current_pe, "target_pe": target_pe,
                        "pe_implied_price": eps * target_pe}

        return {"method": method, "method_label": method_label,
                "starting_dps": starting_dps, "dividend_growth": div_growth,
                "terminal_growth": tg, "cost_of_equity": coe, "beta": beta,
                "risk_free": rf, "equity_premium": erp,
                "projected_dps": projected_dps, "terminal_value": tv,
                "pv_dividends": pv_divs, "pv_terminal": pv_tv,
                "implied_price": implied_price, "meaningful": meaningful,
                "implied_yield": implied_yield, "current_yield": current_yield,
                "pe_crosscheck": pe_check,
                "sensitivity": sens, "wacc_range": coe_range, "tg_range": tg_range,
                "est_horizon": n,
                # Compatibility keys (so downstream code works uniformly)
                "starting_fcf": starting_dps, "revenue_growth": div_growth,
                "wacc": coe, "enterprise_value": implied_price,
                "pv_fcf": pv_divs, "projected_fcf": projected_dps}

    # ========================================================================
    #  UNIFIED ENTRY POINT
    # ========================================================================
    def build_valuation(self) -> dict:
        """Route to the appropriate valuation method based on ticker classification."""
        method = self._detect_method()
        if method in ("DDM_BANK", "DDM_INSURER", "DDM_REIT"):
            logger.info(f"  Valuation method for {self.ticker}: {method} (Dividend Discount Model)")
            return self.build_ddm()
        else:
            logger.info(f"  Valuation method for {self.ticker}: FCF_DCF (standard)")
            return self.build_dcf()

    def build_scenarios(self, dcf):
        ip = dcf.get("implied_price") or self.price or 0
        cp = self.price or 0
        meaningful = dcf.get("meaningful", True)
        method = dcf.get("method", "FCF_DCF")

        # Adjust scenario assumptions based on method
        if method in ("DDM_BANK", "DDM_INSURER", "DDM_REIT"):
            bull_mult, bear_mult = 1.15, 0.80
            bull_note = "Dividend growth accelerates, rates favorable"
            base_note = "Consensus dividend growth maintained"
            bear_note = "Dividend cuts, credit losses rise"
            if method == "DDM_REIT":
                bull_note = "Occupancy rises, cap rates compress"
                bear_note = "Vacancy increases, rates pressure cap rates"
        else:
            bull_mult, bear_mult = 1.20, 0.75
            bull_note = "Growth accelerates above consensus"
            base_note = "Consensus growth maintained"
            bear_note = "Growth slows, margins compress"

        return {
            "bull": {"price": ip * bull_mult,
                     "upside": (ip * bull_mult / cp - 1) if cp else None,
                     "assumption": bull_note},
            "base": {"price": ip,
                     "upside": (ip / cp - 1) if cp else None,
                     "assumption": base_note},
            "bear": {"price": ip * bear_mult,
                     "upside": (ip * bear_mult / cp - 1) if cp else None,
                     "assumption": bear_note},
        }

    def verdict(self, dcf, scenarios):
        bu = scenarios["base"].get("upside", 0) or 0
        meaningful = dcf.get("meaningful", True)

        if not meaningful:
            return {"rating": "N/M", "magnitude": "N/A", "confidence": "Low",
                    "key_variable": f"Valuation not meaningful ({dcf.get('method_label', 'Unknown')} produced extreme result)"}

        r = "Undervalued" if bu > 0.15 else "Overvalued" if bu < -0.10 else "Fairly Valued"

        method = dcf.get("method", "FCF_DCF")
        if method in ("DDM_BANK", "DDM_INSURER", "DDM_REIT"):
            # DDM-specific confidence signals
            signals = sum([
                (self.td.get("gf_score") or 0) >= 80,
                (self.td.get("piotroski") or 0) >= 7,
                bu > 0.15,
                # DDM extra: yield sanity -- implied yield between 1% and 10%
                (dcf.get("implied_yield") or 0) > 0.01 and (dcf.get("implied_yield") or 0) < 0.10,
            ])
            key_var = "Dividend growth trajectory and payout sustainability"
            if method == "DDM_REIT":
                key_var = "FFO/distribution growth and cap rate environment"
        else:
            signals = sum([
                (self.td.get("gf_score") or 0) >= 80,
                (self.td.get("piotroski") or 0) >= 7,
                (self.td.get("altman_z") or 0) > 3,
                bu > 0.15,
            ])
            key_var = "Revenue growth trajectory vs consensus"

        conf = "High" if signals >= 3 else "Low" if signals <= 1 else "Medium"
        return {"rating": r, "magnitude": f"{abs(bu):.0%}", "confidence": conf,
                "key_variable": key_var}

    def _build_optionality(self, dcf) -> dict:
        """Calculate optionality premium for hyperscalers with major moonshot investments."""
        t = self.ticker.upper()
        if t not in OPTIONALITY_TICKERS:
            return None

        config = OPTIONALITY_TICKERS[t]
        base_ip = dcf.get("implied_price") or self.price or 0
        premium_pct = config.get("capex_premium_pct", 0.10)
        premium_value = base_ip * premium_pct
        adjusted_price = base_ip + premium_value

        logger.info(f"  Optionality: {t} base=${base_ip:.2f} + {premium_pct:.0%} premium=${premium_value:.2f} -> ${adjusted_price:.2f}")

        return {
            "label": config["label"],
            "ventures": config["ventures"],
            "premium_pct": premium_pct,
            "premium_value": premium_value,
            "base_implied_price": base_ip,
            "adjusted_implied_price": adjusted_price,
        }

    def run_full_analysis(self):
        # v3.6: use unified entry point that routes to correct method
        dcf = self.build_valuation()
        sc = self.build_scenarios(dcf)
        vd = self.verdict(dcf, sc)

        # v3.6: optionality premium for hyperscalers
        optionality = self._build_optionality(dcf)
        if optionality:
            # Adjust the implied price and re-run scenarios/verdict with adjusted price
            adj_ip = optionality["adjusted_implied_price"]
            dcf["implied_price_pre_optionality"] = dcf.get("implied_price")
            dcf["implied_price"] = adj_ip
            dcf["optionality_premium_pct"] = optionality["premium_pct"]
            # Re-run scenarios and verdict with adjusted implied price
            sc = self.build_scenarios(dcf)
            vd = self.verdict(dcf, sc)

        return {"ticker": self.ticker, "company": self.company, "price": self.price,
                "dcf": dcf, "scenarios": sc, "verdict": vd,
                "valuation_method": dcf.get("method_label", "FCF DCF"),
                "optionality": optionality,
                "analyst_targets": {"median_target": self.td.get("price_target"),
                                    "current_price": self.price,
                                    "upside": ((self.td.get("price_target") or 0)/(self.price or 1)-1) if self.price else None},
                "timestamp": datetime.datetime.now().isoformat()}


# ============================================================================
#  HTML RENDERERS
# ============================================================================

def _render_optionality_html(optionality):
    """Render the optionality premium section for hyperscalers."""
    if not optionality:
        return ""
    ventures_rows = ""
    for name, desc, conviction, timing in optionality["ventures"]:
        conv_color = {"High": "#155724", "Medium": "#856404", "Low": "#636E72"}.get(conviction, "#636E72")
        conv_bg = {"High": "#D4EDDA", "Medium": "#FFF3CD", "Low": "#F8F9FA"}.get(conviction, "#F8F9FA")
        ventures_rows += f"""<tr>
          <td style="padding:6px 8px;font-weight:600;font-size:12px;">{name}</td>
          <td style="padding:6px 8px;font-size:11px;color:#636E72;">{desc}</td>
          <td style="padding:6px 8px;text-align:center;"><span style="background:{conv_bg};color:{conv_color};padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;">{conviction}</span></td>
          <td style="padding:6px 8px;text-align:center;font-size:11px;color:#636E72;">{timing}</td>
        </tr>"""

    return f"""
<h2 style="color:#1B2838;font-size:16px;border-bottom:2px solid #7C3AED;padding-bottom:6px;margin-top:24px;">
  Optionality Premium (+{optionality['premium_pct']:.0%})
</h2>
<p style="font-size:12px;color:#636E72;margin:4px 0 8px;">
  Base DCF: ${optionality['base_implied_price']:.2f} &rarr;
  <b>Adjusted: ${optionality['adjusted_implied_price']:.2f}</b>
  (premium: +${optionality['premium_value']:.2f})
</p>
<p style="font-size:12px;color:#2D3436;margin:4px 0 8px;">
  This company is investing aggressively in ventures whose value is not fully captured
  in a standard DCF. The optionality premium reflects embedded real options from AI,
  infrastructure, and moonshot investments.
</p>
<table style="width:100%;border-collapse:collapse;font-size:13px;margin:8px 0;">
  <tr style="background:#7C3AED;">
    <th style="padding:6px 8px;color:#FFF;text-align:left;font-size:11px;">Venture</th>
    <th style="padding:6px 8px;color:#FFF;text-align:left;font-size:11px;">Description</th>
    <th style="padding:6px 8px;color:#FFF;text-align:center;font-size:11px;">Conviction</th>
    <th style="padding:6px 8px;color:#FFF;text-align:center;font-size:11px;">Timing</th>
  </tr>
  {ventures_rows}
</table>"""


def render_valuation_html(a):
    dcf=a["dcf"]; sc=a["scenarios"]; vd=a["verdict"]; p=a.get("price",0) or 0
    n = dcf.get("est_horizon", 3)
    method = dcf.get("method", "FCF_DCF")
    method_label = dcf.get("method_label", "FCF DCF")
    optionality = a.get("optionality")
    bc={"Undervalued":("#155724","#D4EDDA"),"Overvalued":("#721C24","#F8D7DA"),
        "Fairly Valued":("#856404","#FFF3CD"), "N/M":("#636E72","#F8F9FA")}
    tc,bgc = bc.get(vd["rating"],("#2D3436","#F8F9FA"))
    ip = dcf.get("implied_price") or 0

    # Sensitivity table
    sr=""
    for w in dcf.get("wacc_range", []):
        c=""
        for tg in dcf.get("tg_range", []):
            v=dcf["sensitivity"].get((w,tg))
            st=""
            if v and p:
                if v>p*1.1: st="background:#D4EDDA;"
                elif v<p*0.9: st="background:#F8D7DA;"
            c += f'<td style="padding:8px;text-align:center;{st}">${v:.2f}</td>' if v else '<td style="padding:8px;text-align:center;">--</td>'
        sr+=f'<tr><td style="padding:8px;font-weight:600;">{w:.1%}</td>{c}</tr>'
    sh="".join(f'<th style="padding:8px;background:#2D4A5E;color:#FFF;">{t:.1%}</th>' for t in dcf.get("tg_range", []))

    # Sensitivity axis labels
    if method in ("DDM_BANK", "DDM_INSURER", "DDM_REIT"):
        sens_row_label = "CoE"
        sens_col_label = "Terminal Growth"
    else:
        sens_row_label = "WACC"
        sens_col_label = "Terminal Growth"

    def scr(nm,s,bg):
        u=s.get("upside"); us=f'{u:+.1%}' if u else "--"
        return f'<tr style="background:{bg};"><td style="padding:8px;font-weight:600;">{nm}</td><td style="padding:8px;text-align:right;">${s["price"]:.2f}</td><td style="padding:8px;text-align:right;">{us}</td><td style="padding:8px;font-size:12px;">{s["assumption"]}</td></tr>'

    # ---- Method-specific details section ----
    if method in ("DDM_BANK", "DDM_INSURER", "DDM_REIT"):
        details_html = f"""
<tr><td style="padding:6px 0;color:#636E72;">Starting DPS</td><td style="text-align:right;font-weight:600;">${dcf.get('starting_dps',0):.2f}</td></tr>
<tr><td style="padding:6px 0;color:#636E72;">Dividend Growth (t+{n})</td><td style="text-align:right;">{dcf.get('dividend_growth',0):.1%}</td></tr>
<tr><td style="padding:6px 0;color:#636E72;">Terminal Growth</td><td style="text-align:right;">{dcf.get('terminal_growth',0):.1%}</td></tr>
<tr><td style="padding:6px 0;color:#636E72;">Cost of Equity</td><td style="text-align:right;">{dcf.get('cost_of_equity',0):.1%}</td></tr>
<tr><td style="padding:6px 0;color:#636E72;">Current Yield</td><td style="text-align:right;">{(dcf.get('current_yield') or 0):.1%}</td></tr>
<tr><td style="padding:6px 0;color:#636E72;">Implied Yield</td><td style="text-align:right;">{(dcf.get('implied_yield') or 0):.1%}</td></tr>
<tr style="border-top:1px solid #DEE2E6;"><td style="padding:8px 0;font-weight:700;">DDM Implied Price</td><td style="text-align:right;font-weight:700;font-size:15px;">${ip:.2f}</td></tr>"""

        # P/E cross-check
        pe = dcf.get("pe_crosscheck")
        if pe:
            details_html += f"""
<tr><td colspan="2" style="padding:10px 0 4px;font-weight:600;color:#2D4A5E;border-top:1px solid #DEE2E6;">P/E Cross-Check</td></tr>
<tr><td style="padding:4px 0;color:#636E72;">Current P/E</td><td style="text-align:right;">{pe['current_pe']:.1f}x</td></tr>
<tr><td style="padding:4px 0;color:#636E72;">Sector Avg P/E</td><td style="text-align:right;">{pe['target_pe']:.1f}x</td></tr>
<tr><td style="padding:4px 0;color:#636E72;">P/E Implied Price</td><td style="text-align:right;font-weight:600;">${pe['pe_implied_price']:.2f}</td></tr>"""
    else:
        details_html = f"""
<tr><td style="padding:6px 0;color:#636E72;">Starting FCF</td><td style="text-align:right;font-weight:600;">${dcf.get('starting_fcf',0):.3f}B</td></tr>
<tr><td style="padding:6px 0;color:#636E72;">Rev Growth CAGR (t+{n})</td><td style="text-align:right;">{dcf.get('revenue_growth',0):.1%}</td></tr>
<tr><td style="padding:6px 0;color:#636E72;">Terminal Growth</td><td style="text-align:right;">{dcf.get('terminal_growth',0):.1%}</td></tr>
<tr><td style="padding:6px 0;color:#636E72;">WACC</td><td style="text-align:right;">{dcf.get('wacc',0):.1%}</td></tr>
<tr style="border-top:1px solid #DEE2E6;"><td style="padding:8px 0;font-weight:700;">DCF Implied Price</td><td style="text-align:right;font-weight:700;font-size:15px;">${ip:.2f}</td></tr>"""

    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"></head>
<body style="margin:0;padding:20px;font-family:Calibri,sans-serif;background:#F0F2F5;">
<div style="max-width:900px;margin:0 auto;background:#FFF;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
<div style="background:#1B2838;padding:18px 24px;">
<h1 style="margin:0;color:#FFF;font-size:20px;">{a['company']} ({a['ticker']}) -- Valuation</h1>
<p style="margin:4px 0 0;color:#ADB5BD;font-size:12px;">{datetime.date.today().strftime('%B %d, %Y')} | Price: ${p:.2f} | Method: {method_label} | Est. horizon: t+{n}</p></div>
<div style="padding:16px 24px;background:{bgc};border-bottom:2px solid {tc}40;">
<span style="font-size:20px;font-weight:700;color:{tc};">{vd['rating']}</span>
<span style="font-size:14px;color:{tc};margin-left:12px;">by {vd['magnitude']} | Confidence: {vd['confidence']}</span></div>
<div style="padding:24px;">
<h2 style="color:#1B2838;font-size:16px;border-bottom:2px solid #DEE2E6;padding-bottom:6px;">{method_label} Analysis</h2>
<table style="width:100%;border-collapse:collapse;font-size:13px;margin:12px 0;">
{details_html}
</table>
<h3 style="color:#2D4A5E;font-size:14px;">Sensitivity: {sens_row_label} vs {sens_col_label}</h3>
<table style="border-collapse:collapse;font-size:13px;margin:8px 0;">
<tr><th style="padding:8px;background:#1B2838;color:#FFF;">{sens_row_label} \\ Tg</th>{sh}</tr>{sr}</table>
<h2 style="color:#1B2838;font-size:16px;border-bottom:2px solid #DEE2E6;padding-bottom:6px;margin-top:24px;">Scenarios</h2>
<table style="width:100%;border-collapse:collapse;font-size:13px;margin:12px 0;">
<tr style="background:#2D4A5E;"><th style="padding:8px;color:#FFF;text-align:left;">Scenario</th><th style="padding:8px;color:#FFF;text-align:right;">Fair Value</th><th style="padding:8px;color:#FFF;text-align:right;">vs Current</th><th style="padding:8px;color:#FFF;text-align:left;">Assumptions</th></tr>
{scr("Bull",sc["bull"],"#D4EDDA")}{scr("Base",sc["base"],"#F8F9FA")}{scr("Bear",sc["bear"],"#F8D7DA")}
</table>
{_render_optionality_html(optionality)}
</div>
<div style="padding:12px 24px;background:#F8F9FA;border-top:1px solid #DEE2E6;">
<p style="margin:0;font-size:11px;color:#636E72;">Sources: GuruFocus API, analyst consensus. Method: {method_label}. Not investment advice.</p>
</div></div></body></html>"""


# ============================================================================
#  EXCEL VALUATION TAB
# ============================================================================

def add_valuation_sheet(wb, analysis):
    dcf=analysis["dcf"]; sc=analysis["scenarios"]; vd=analysis["verdict"]
    n = dcf.get("est_horizon", 3)
    method = dcf.get("method", "FCF_DCF")
    method_label = dcf.get("method_label", "FCF DCF")
    optionality = analysis.get("optionality")

    ws = wb.create_sheet(title=f"Val_{analysis['ticker']}"[:31])
    hf = PatternFill(start_color="1B2838",end_color="1B2838",fill_type="solid")
    hfont = Font(name="Calibri",bold=True,size=10,color="FFFFFF")
    lf = Font(name="Calibri",size=10,color="636E72")
    vf = Font(name="Calibri",size=10,color="2D3436",bold=True)

    r=1
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4)
    c=ws.cell(row=r,column=1,value=f"{analysis['company']} ({analysis['ticker']}) -- Valuation ({method_label})")
    c.font=Font(name="Calibri",bold=True,size=14,color="FFFFFF"); c.fill=hf; r+=2

    ws.cell(row=r,column=1,value="VERDICT:").font=Font(name="Calibri",bold=True,size=11)
    vc=ws.cell(row=r,column=2,value=f"{vd['rating']} by {vd['magnitude']} (Conf: {vd['confidence']})")
    vc.font=Font(name="Calibri",bold=True,size=11)
    if "Under" in vd["rating"]: vc.fill=PatternFill(start_color="D4EDDA",end_color="D4EDDA",fill_type="solid")
    elif "Over" in vd["rating"]: vc.fill=PatternFill(start_color="F8D7DA",end_color="F8D7DA",fill_type="solid")
    elif "N/M" in vd["rating"]: vc.fill=PatternFill(start_color="F8F9FA",end_color="F8F9FA",fill_type="solid")
    r+=2

    ws.cell(row=r,column=1,value="Method:").font=lf
    ws.cell(row=r,column=2,value=method_label).font=vf; r+=1

    ip = dcf.get("implied_price") or 0

    # Method-specific details
    if method in ("DDM_BANK", "DDM_INSURER", "DDM_REIT"):
        for label,val,fmt in [("Starting DPS",dcf.get("starting_dps"),"$#,##0.00"),
                               (f"Dividend Growth (t+{n})",dcf.get("dividend_growth"),"0.0%"),
                               ("Terminal Growth",dcf.get("terminal_growth"),"0.0%"),
                               ("Cost of Equity",dcf.get("cost_of_equity"),"0.0%"),
                               ("Current Yield",dcf.get("current_yield"),"0.0%"),
                               ("Implied Yield",dcf.get("implied_yield"),"0.0%"),
                               ("DDM Implied Price",ip,"$#,##0.00")]:
            ws.cell(row=r,column=1,value=label).font=lf
            c=ws.cell(row=r,column=2,value=val); c.font=vf; c.number_format=fmt; r+=1

        # P/E cross-check
        pe = dcf.get("pe_crosscheck")
        if pe:
            r += 1
            ws.cell(row=r,column=1,value="P/E Cross-Check").font=Font(name="Calibri",bold=True,size=10,color="2D4A5E"); r+=1
            for label,val,fmt in [("Current P/E",pe["current_pe"],"0.0"),
                                   ("Sector Avg P/E",pe["target_pe"],"0.0"),
                                   ("P/E Implied Price",pe["pe_implied_price"],"$#,##0.00")]:
                ws.cell(row=r,column=1,value=label).font=lf
                c=ws.cell(row=r,column=2,value=val); c.font=vf; c.number_format=fmt; r+=1
    else:
        for label,val,fmt in [("Starting FCF ($B)",dcf["starting_fcf"],"#,##0.000"),
                               (f"Rev Growth CAGR (t+{n})",dcf["revenue_growth"],"0.0%"),
                               ("Terminal Growth",dcf["terminal_growth"],"0.0%"),
                               ("WACC",dcf["wacc"],"0.0%"),
                               ("DCF Implied Price",ip,"$#,##0.00")]:
            ws.cell(row=r,column=1,value=label).font=lf
            c=ws.cell(row=r,column=2,value=val); c.font=vf; c.number_format=fmt; r+=1

    r+=1
    # Scenarios
    ws.cell(row=r,column=1,value="Scenario").font=hfont; ws.cell(row=r,column=1).fill=hf
    ws.cell(row=r,column=2,value="Fair Value").font=hfont; ws.cell(row=r,column=2).fill=hf
    ws.cell(row=r,column=3,value="vs Current").font=hfont; ws.cell(row=r,column=3).fill=hf
    ws.cell(row=r,column=4,value="Assumptions").font=hfont; ws.cell(row=r,column=4).fill=hf
    r+=1
    for nm, s, color in [("Bull",sc["bull"],"D4EDDA"),("Base",sc["base"],"F8F9FA"),("Bear",sc["bear"],"F8D7DA")]:
        fill = PatternFill(start_color=color,end_color=color,fill_type="solid")
        ws.cell(row=r,column=1,value=nm).fill=fill
        c=ws.cell(row=r,column=2,value=s["price"]); c.number_format="$#,##0.00"; c.fill=fill
        c=ws.cell(row=r,column=3,value=s.get("upside")); c.number_format="0.0%"; c.fill=fill
        ws.cell(row=r,column=4,value=s["assumption"]).fill=fill
        r+=1

    r+=1
    # Sensitivity
    sens_label = "CoE" if method in ("DDM_BANK", "DDM_INSURER", "DDM_REIT") else "WACC"
    ws.cell(row=r,column=1,value=f"{sens_label} \\ Tg").font=hfont; ws.cell(row=r,column=1).fill=hf
    for ci, t in enumerate(dcf.get("tg_range", []), 2):
        c=ws.cell(row=r,column=ci,value=t); c.number_format="0.0%"; c.font=hfont; c.fill=hf
    r+=1
    p = analysis.get("price", 0) or 0
    for w in dcf.get("wacc_range", []):
        c=ws.cell(row=r,column=1,value=w); c.number_format="0.0%"; c.font=vf
        for ci, t in enumerate(dcf.get("tg_range", []), 2):
            v=dcf["sensitivity"].get((w,t))
            if v:
                c=ws.cell(row=r,column=ci,value=v); c.number_format="$#,##0.00"
                if v > p * 1.1: c.fill=PatternFill(start_color="D4EDDA",end_color="D4EDDA",fill_type="solid")
                elif v < p * 0.9: c.fill=PatternFill(start_color="F8D7DA",end_color="F8D7DA",fill_type="solid")
        r+=1

    # Optionality Premium section (hyperscalers only)
    if optionality:
        r += 1
        opt_fill = PatternFill(start_color="7C3AED", end_color="7C3AED", fill_type="solid")
        opt_font = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=4)
        c = ws.cell(row=r, column=1, value=f"OPTIONALITY PREMIUM (+{optionality['premium_pct']:.0%})")
        c.font = opt_font; c.fill = opt_fill; r += 1

        ws.cell(row=r, column=1, value="Base DCF Price").font = lf
        c = ws.cell(row=r, column=2, value=optionality["base_implied_price"])
        c.number_format = "$#,##0.00"; c.font = vf; r += 1
        ws.cell(row=r, column=1, value="Premium Value").font = lf
        c = ws.cell(row=r, column=2, value=optionality["premium_value"])
        c.number_format = "$#,##0.00"; c.font = vf; r += 1
        ws.cell(row=r, column=1, value="Adjusted Price").font = Font(name="Calibri", bold=True, size=11, color="7C3AED")
        c = ws.cell(row=r, column=2, value=optionality["adjusted_implied_price"])
        c.number_format = "$#,##0.00"; c.font = Font(name="Calibri", bold=True, size=11, color="7C3AED"); r += 2

        # Ventures table
        for ci, h in enumerate(["Venture", "Description", "Conviction", "Timing"], 1):
            c = ws.cell(row=r, column=ci, value=h); c.font = opt_font; c.fill = opt_fill
        r += 1
        for name, desc, conviction, timing in optionality["ventures"]:
            ws.cell(row=r, column=1, value=name).font = vf
            ws.cell(row=r, column=2, value=desc).font = Font(name="Calibri", size=9, color="636E72")
            conv_cell = ws.cell(row=r, column=3, value=conviction)
            if conviction == "High":
                conv_cell.fill = PatternFill(start_color="D4EDDA", end_color="D4EDDA", fill_type="solid")
                conv_cell.font = Font(name="Calibri", size=10, color="155724", bold=True)
            elif conviction == "Medium":
                conv_cell.fill = PatternFill(start_color="FFF3CD", end_color="FFF3CD", fill_type="solid")
                conv_cell.font = Font(name="Calibri", size=10, color="856404")
            else:
                conv_cell.font = Font(name="Calibri", size=10, color="636E72")
            ws.cell(row=r, column=4, value=timing).font = lf
            r += 1

    ws.column_dimensions["A"].width=28; ws.column_dimensions["B"].width=16
    ws.column_dimensions["C"].width=14; ws.column_dimensions["D"].width=40

